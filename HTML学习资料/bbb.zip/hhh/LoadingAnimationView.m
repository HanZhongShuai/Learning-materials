//
//  LoadingAnimationView.m
//  DatingForDating
//
//  Created by MAXToooNG on 16/4/25.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import "LoadingAnimationView.h"

@interface LoadingAnimationView ()
{
    CALayer *_animationLayer;
}
@end

@implementation LoadingAnimationView

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
//        [self initAnimationView];
        self.layer.masksToBounds = YES;
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(resume) name:UIApplicationDidBecomeActiveNotification object:nil];
    }
    return self;
}

- (void)resume
{
    CALayer *animationLayer = _animationLayer;
    [animationLayer removeFromSuperlayer];
    [self setNeedsDisplay];
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

//- (void)initAnimationView{
//
//}

- (void)drawRect:(CGRect)rect
{
    if (_animationLayer.superlayer) {
        return;
    }
    UIColor *bkColor = colorWithHexString(@"#181818");
    [bkColor setFill];
//    colorWithHexString(@"#181818").setFill;
    UIRectFill(rect);
    int pulsingCount = 6;
    double animationDuration = 4;
    CALayer *animationLayer = [CALayer layer];
    for (int i = 0; i < pulsingCount; i ++) {
        CALayer *pulsingLayer = [CALayer layer];
        pulsingLayer.frame = CGRectMake(0, 0, rect.size.width, rect.size.height);
        pulsingLayer.borderColor = colorWithHexString(@"#fa5b3a").CGColor;
        pulsingLayer.borderWidth = 1;
        pulsingLayer.cornerRadius = rect.size.height / 2;
        CAMediaTimingFunction *defaultCurve =  [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionDefault];
        CAAnimationGroup *animationGroup = [[CAAnimationGroup alloc]init];
        animationGroup.fillMode = kCAFillModeBackwards;
        animationGroup.beginTime = CACurrentMediaTime() + (double)i * animationDuration / (double)pulsingCount;
        animationGroup.duration = animationDuration;
        animationGroup.repeatCount = HUGE;
        animationGroup.timingFunction = defaultCurve;
        CABasicAnimation *scaleAnimation = [CABasicAnimation animationWithKeyPath:@"transform.scale"];
        scaleAnimation.fromValue = @0.f;
        scaleAnimation.toValue = @1.5f;
        
        CAKeyframeAnimation *opacityAnimation = [CAKeyframeAnimation animationWithKeyPath:@"opacity"];
        opacityAnimation.values = @[@1.f,@0.7f,@0.f];
        animationGroup.animations = @[scaleAnimation,opacityAnimation];
        [pulsingLayer addAnimation:animationGroup forKey:@"pulsing"];
        [animationLayer addSublayer:pulsingLayer];
    }
    [self.layer addSublayer:animationLayer];
    _animationLayer = animationLayer;
}

- (void)didMoveToWindow
{
    [super didMoveToWindow];
    if (self.window !=nil) {
        [UIView animateWithDuration:1 animations:^{
            self.alpha = 1;
        }];
    }
}

- (void)removeFromSuperview
{
    [super removeFromSuperview];

//    [super removeFromSuperview];
//    UIView.beginAnimations("", context: nil)
//    UIView.setAnimationDuration(1)
//    self.alpha = 0
//    UIView.setAnimationDidStopSelector(Selector("callSuperRemoveFromSuperview"))
//    UIView.commitAnimations()
//    [UIView beginAnimations:@"" context:nil];
//    [UIView setAnimationDuration:1];
//    self.alpha = 0;
//    [UIView setAnimationDidStopSelector:@selector(callSuperRemoveFromSuperview)];
//    [UIView commitAnimations];
}

- (void)callSuperRemoveFromSuperview
{
    [super removeFromSuperview];
}

@end

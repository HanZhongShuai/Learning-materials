//
//  LocationGuideView.m
//  DatingForDating
//
//  Created by MAXToooNG on 16/4/25.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import "LocationGuideView.h"

@interface LocationGuideView ()
@property (nonatomic, strong) UIImageView *imageView;
@property (nonatomic, strong) UIButton *btn;
@end

@implementation LocationGuideView

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        [self initViews];
    }
    return self;
}

- (void)initViews
{
    self.imageView = [[UIImageView alloc] initWithFrame:self.bounds];
    [self addSubview:self.imageView];
    self.imageView.userInteractionEnabled = YES;
    self.imageView.image = [UIImage imageNamed:@"pic_location"];
    self.btn = [UIButton buttonWithType:UIButtonTypeSystem];
    [self.btn setFrame:CGRectMake(22, windowHeight() - 61, windowWidth() - 44, 44)];
    [self.btn addTarget:self action:@selector(removeSelf) forControlEvents:UIControlEventTouchUpInside];
    [self.btn setTitle:LocalizedString(@"ok", nil) forState:UIControlStateNormal];
    [self.btn setTitleColor:colorWithHexString(@"#fa5b3a") forState:UIControlStateNormal];
    [self.btn.layer setBorderColor:colorWithHexString(@"#fa5b3a").CGColor];
    [self.btn.layer setBorderWidth:1];
    [self.imageView addSubview:self.btn];
    [self addSubview:self.imageView];
}

- (void)removeSelf{
    [self removeFromSuperview];
}

@end

//
//  BannedView.m
//  DatingForDating
//
//  Created by MAXToooNG on 16/4/27.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import "BannedView.h"
#import "TermsViewController.h"

@implementation BannedView

- (instancetype)initWithFrame:(CGRect)frame
{
    CGRect f = CGRectMake(20, 100, windowWidth() - 40, windowHeight() - 200);
    if (self = [super initWithFrame: f]) {
        [self initViews];
    }
    return self;
}

- (void)initViews
{
    self.backgroundColor = colorWithHexString(@"fafafa");
    UITextView *textView1 = [[UITextView alloc] initWithFrame:CGRectMake(5, 40, self.frame.size.width - 10, 55)];
    textView1.textAlignment = NSTextAlignmentCenter;
    textView1.text = [NSString stringWithFormat:@"%@ %@",LocalizedString(@"oops",nil),LocalizedString(@"banned", nil)];
    textView1.textColor = colorWithHexString(@"#4a4a4a");
    textView1.font = fontWithSize(18);
    NSMutableAttributedString * mutStr = [textView1.attributedText mutableCopy];
    //颜色
    [mutStr addAttribute:NSForegroundColorAttributeName value:colorWithHexString(@"#fa5b3a") range:NSMakeRange(54, 11)];
    [mutStr addAttribute:NSLinkAttributeName value:@"terms://" range:NSMakeRange(54, 11)];
    NSDictionary *linkAttributes = @{NSForegroundColorAttributeName: colorWithHexString(@"#fa5b3a"),
                                     NSUnderlineColorAttributeName: colorWithHexString(@"#fa5b3a"),
                                     NSUnderlineStyleAttributeName: @(NSUnderlineStyleSingle)};
    textView1.linkTextAttributes = linkAttributes;
    textView1.delegate = self;
    textView1.editable = NO;
    textView1.attributedText = mutStr;
    
    UIImageView *backView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 132, 132)];
    backView.center = CGPointMake(self.frame.size.width  / 2, self.frame.size.height / 2 - 30);
    backView.image = [UIImage imageNamed:@"Clock"];
    [self addSubview:backView];
    [self addSubview:textView1];
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(10, self.frame.size.height / 2 - 60, self.frame.size.width - 20, 30)];
    label.font = fontWithSize(23);
    label.textColor = colorWithHexString(@"4a4a4a");
    label.text = LocalizedString(@"unlock", nil);
    label.textAlignment = NSTextAlignmentCenter;
    [self addSubview:label];
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeSystem];
    btn.frame = CGRectMake(10, self.frame.size.height - 35 - 50, self.frame.size.width - 20, 50);
    [btn setBackgroundColor:colorWithHexString(@"#fa5b3a")];
    [btn setTitle:LocalizedString(@"appeal", nil) forState:UIControlStateNormal];
    btn.titleLabel.font = fontWithSize(23);
    [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(appeal) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:btn];
    
    self.timeLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, self.frame.size.height / 2 - 20, self.frame.size.width - 20, 50)];
    self.timeLabel.textColor = colorWithHexString(@"#E00b0b");
    self.timeLabel.font = fontWithSize(50);
    self.timeLabel.text = @"36Hours";
    self.timeLabel.textAlignment = NSTextAlignmentCenter;
    [self addSubview:self.timeLabel];
}

- (void)appeal
{
    self.apperaClicked();
}

- (BOOL)textView:(UITextView *)textView shouldInteractWithURL:(NSURL *)URL inRange:(NSRange)characterRange
{
    if ([[URL scheme] isEqualToString:@"terms"]) {
        self.linkClicked();
        return NO;
    }
    return YES; // let the system open this URL
}

@end

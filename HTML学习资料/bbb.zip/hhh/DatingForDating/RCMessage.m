//
//  RCMessage.m
//  DatingForDating
//
//  Created by MAXToooNG on 16/4/19.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import "RCMessage.h"

@implementation RCMessage

- (instancetype)initWithMessage:(id<SINMessage>)message
{
    if (self = [super init]) {
        self.messageId = message.messageId;
        self.text = message.text;
        self.recipientIds = [NSArray arrayWithArray:message.recipientIds];
        self.senderId = message.senderId;
        self.headers = message.headers;
        self.timestamp = message.timestamp;
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder
{
    if(self = [super init])
    {
        self.requestId       = [aDecoder decodeObjectForKey:@"requestId"];
        self.messageId           = [aDecoder decodeObjectForKey:@"messageId"];
        self.recipientIds = [aDecoder decodeObjectForKey:@"recipientIds"];
        self.senderId = [aDecoder decodeObjectForKey:@"senderId"];
        self.text = [aDecoder decodeObjectForKey:@"text"];
        self.headers = [aDecoder decodeObjectForKey:@"headers"];
        self.timestamp = [aDecoder decodeObjectForKey:@"timestamp"];
    }
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{
    [aCoder encodeObject:self.requestId forKey:@"requestId"];
    [aCoder encodeObject:self.messageId forKey:@"messageId"];
    [aCoder encodeObject:self.recipientIds forKey:@"recipientIds"];
    [aCoder encodeObject:self.senderId forKey:@"senderId"];
    [aCoder encodeObject:self.text forKey:@"text"];
    [aCoder encodeObject:self.headers forKey:@"headers"];
    [aCoder encodeObject:self.timestamp forKey:@"timestamp"];
    
}
@end

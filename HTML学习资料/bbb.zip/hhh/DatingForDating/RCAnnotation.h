//
//  RCAnnotation.h
//  DatingForDating
//
//  Created by MAXToooNG on 16/3/31.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import <Foundation/Foundation.h>
@import MapKit;

@interface RCAnnotation : NSObject <MKAnnotation>
@property (nonatomic,readonly) CLLocationCoordinate2D coordinate;
- (void)setCoordinate:(CLLocationCoordinate2D)newCoordinate;
@end

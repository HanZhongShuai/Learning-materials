//
//  DetailInfoViewController.h
//  DatingForDating
//
//  Created by MAXToooNG on 16/3/30.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UserModel.h"

@interface DetailInfoViewController : UIViewController
@property (nonatomic, strong) UserModel *user;
@end

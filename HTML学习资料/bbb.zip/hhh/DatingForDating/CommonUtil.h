//
//  CommonUtil.h
//  DatingForDating
//
//  Created by MAXToooNG on 16/3/30.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Sinch/Sinch.h>
#import "UserModel.h"

@import MapKit;

@interface CommonUtil : NSObject

@property (nonatomic, strong) CLLocationManager *locationManager;
@property (nonatomic, strong) NSString *idfv;
@property (nonatomic, strong) NSString *userId;
@property (nonatomic, strong) NSNumber *requestId;
@property (nonatomic, strong) NSString *userToken;
@property (nonatomic, strong) NSArray *commArray;
@property (nonatomic, strong) NSNumber *isFee;
@property (nonatomic, strong) NSData *receiptData;
@property (nonatomic, assign) long fixTime;
@property (nonatomic, strong) id<SINClient> sinchClient;
@property (nonatomic, strong) id<SINManagedPush> push;
@property (nonatomic, assign) BOOL canShowMail;

+(CommonUtil *)defaultUtil;
- (NSString*)uuid;
- (void)getTotalDistanceWalkTimeSuccess:(void(^)(NSString *distance,NSString *walkTime))walk AndCarTime:(void(^)(NSString *carTime))car WithUser:(UserModel *)user;
@end

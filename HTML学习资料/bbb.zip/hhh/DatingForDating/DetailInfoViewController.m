//
//  DetailInfoViewController.m
//  DatingForDating
//
//  Created by MAXToooNG on 16/3/30.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import "DetailInfoViewController.h"
#import "MapViewController.h"
#import "LocationAnnotationViewController.h"
#import "UIImageView+WebCache.h"
#import "CommonUtil.h"
@import MapKit;

@interface DetailInfoViewController ()<MKMapViewDelegate>
@property (nonatomic, strong) UIImageView *photoView;
@property (nonatomic, strong) UIView *bottomView;
@property (nonatomic, strong) UILabel *distanceLabel;
@property (nonatomic, strong) UILabel *timeLabel;
@property (nonatomic, strong) UILabel *carTimeLabel;

@property (nonatomic, assign) CGFloat totalDistance;
@property (nonatomic, assign) NSTimeInterval walkingTime;
@property (nonatomic, assign) NSTimeInterval carTime;
@property (nonatomic, strong) UIButton *locationBtn;

@end

@implementation DetailInfoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self initViews];
}

- (void)initViews{
    self.photoView = [[UIImageView alloc] initWithFrame:self.view.bounds];
    [self.view addSubview:self.photoView];
    self.photoView.backgroundColor = [UIColor blackColor];
    self.photoView.contentMode = UIViewContentModeScaleAspectFit;
    [self.photoView sd_setImageWithURL:[NSURL URLWithString:self.user.headViewUrlString_L]];
    self.photoView.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissPhotoPage:)];
    [self.photoView addGestureRecognizer:tap];
    self.bottomView = [[UIView alloc] initWithFrame:CGRectMake(0, windowHeight() - setH(90), windowWidth(), setH(90))];
    self.bottomView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.4];
    [self.view addSubview:self.bottomView];
    
    self.locationBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    [self.locationBtn setImage:[UIImage imageNamed:@"title_ic_location_nor"] forState:UIControlStateNormal];
    [self.locationBtn setTitle:@"Check the Location" forState:UIControlStateNormal];
    self.locationBtn.frame = CGRectMake((windowWidth() - setW(212))/2, (setH(90) - setH(69)), setW(212), setH(29));
    [self.locationBtn setTintColor:colorWithHexString(@"#fa5b3a")];
    [self.locationBtn.layer setBorderColor:colorWithHexString(@"#fa5b3a").CGColor];
    [self.locationBtn.layer setBorderWidth:1];
    [self.locationBtn addTarget:self action:@selector(showMapView:) forControlEvents:UIControlEventTouchUpInside];
    [self.bottomView addSubview:self.locationBtn];
    
    UIView *distanceView = [[UIImageView alloc] initWithFrame:CGRectMake(0, self.bottomView.frame.size.height - setH(22), setW(54), setH(15))];
    distanceView.backgroundColor = [UIColor clearColor];
//    distanceImage.image = [UIImage imageNamed:@"card_ic_distance"];
    [self.bottomView addSubview:distanceView];
    UIImageView *distanceImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, setW(14), setH(14))];
    distanceImageView.image = [UIImage imageNamed:@"card_ic_distance"];
    [distanceView addSubview:distanceImageView];
    self.distanceLabel = [[UILabel alloc] initWithFrame:CGRectMake(setW(15), 0, setW(40), setH(15))];
    self.distanceLabel.text = @"10km";
    self.distanceLabel.textColor = [UIColor whiteColor];
    self.distanceLabel.font = [UIFont systemFontOfSize:10];
    [distanceView addSubview:self.distanceLabel];
    
    UIView *timeView = [[UIView alloc] initWithFrame:CGRectMake(0 + setW(54 + 13), self.bottomView.frame.size.height - setH(22), setW(54), setH(15))];
    UIImageView *timeImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, setW(14), setH(14))];
    timeImageView.image = [UIImage imageNamed:@"card_ic_foot"];
    [self.bottomView addSubview:timeView];
    [timeView addSubview:timeImageView];
    self.timeLabel = [[UILabel alloc] initWithFrame:CGRectMake(setW(15), 0, setW(40), setH(15))];
    self.timeLabel.text = @"10 min";
    self.timeLabel.textColor = [UIColor whiteColor];
    self.timeLabel.font = [UIFont systemFontOfSize:10];
    [timeView addSubview:self.timeLabel];
    
    UIView *carTimeView = [[UIView alloc] initWithFrame:CGRectMake(0 + setW(54 + 13 + 54 + 13), self.bottomView.frame.size.height - setH(22), setW(54), setH(15))];
    UIImageView *carImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, setW(14), setH(14))];
    carImageView.image = [UIImage imageNamed:@"card_ic_taxi"];
    [self.bottomView addSubview:carTimeView];
    [carTimeView addSubview:carImageView];
    
    self.carTimeLabel = [[UILabel alloc] initWithFrame:CGRectMake(setW(15), 0, setW(40), setH(15))];
    self.carTimeLabel.text = @"10 min";
    self.carTimeLabel.textColor = [UIColor whiteColor];
    self.carTimeLabel.font = [UIFont systemFontOfSize:10];
    [carTimeView addSubview:self.carTimeLabel];
//    [self.bottomView addSubview:self.timeLabel];
//    [self.bottomView addSubview:self.distanceLabel];
//    [self.bottomView addSubview: self.carTimeLabel];
    
    UITapGestureRecognizer *showMapTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(showMapView:)];
    [self.bottomView addGestureRecognizer:showMapTap];
    
    [self requestData];
}

- (void)requestData
{
    [[CommonUtil defaultUtil] getTotalDistanceWalkTimeSuccess:^(NSString *distance, NSString *walkTime) {
        self.distanceLabel.text = distance;
        self.timeLabel.text = walkTime;
    } AndCarTime:^(NSString *carTime) {
        self.carTimeLabel.text = carTime;
    } WithUser:self.user];
    
//    NSLog(@"longitude = %f, latitude = %f",self.user.lat.doubleValue,self.user.lon.doubleValue);
//    CLLocationCoordinate2D coordinateSource = CLLocationCoordinate2DMake(((NSNumber *)[userdefault objectForKey:kLatitude]).doubleValue, ((NSNumber *)[userdefault objectForKey:kLongitude]).doubleValue);
//    
//    MKDirectionsRequest *request = [[MKDirectionsRequest alloc] init];
//    request.transportType = MKDirectionsTransportTypeWalking;
//    MKPlacemark *sourceMark = [[MKPlacemark alloc] initWithCoordinate:coordinateSource addressDictionary:nil];
//    request.source = [[MKMapItem alloc] initWithPlacemark:sourceMark];
//    CLLocationCoordinate2D coordinate = CLLocationCoordinate2DMake(self.user.lat.doubleValue, self.user.lon.doubleValue);
//    MKPlacemark *mark = [[MKPlacemark alloc] initWithCoordinate:coordinate addressDictionary:nil];
//    request.destination = [[MKMapItem alloc] initWithPlacemark:mark];
//    
//    request.requestsAlternateRoutes = YES;
//    MKDirections *direction = [[MKDirections alloc] initWithRequest:request];
//    [direction calculateDirectionsWithCompletionHandler:^(MKDirectionsResponse * _Nullable response, NSError * _Nullable error) {
//        NSLog(@"gei Info Success ");
//        NSArray *array = response.routes;
//        NSTimeInterval totalTime = 0;
//        NSInteger times = 0;
//        double distance = 0;
//        for (MKRoute *route in array) {
//            totalTime += route.expectedTravelTime;
//            distance += route.distance;
//            times += 1;
//        }
//        NSLog(@"times = %ld",times);
//        NSLog(@"totalTime = %f",totalTime);
//        NSLog(@"total distance = %f",distance);
//        self.walkingTime = totalTime;
//        self.totalDistance = distance;
//        self.distanceLabel.text = [NSString stringWithFormat:@"%.1f km",self.totalDistance /1000];
//        self.timeLabel.text = [NSString stringWithFormat:@"%dh%.0fmin",(int)(self.walkingTime / 3600) ,((int)totalTime%3600 / 60.f)];
//        self.timeLabel.text = [NSString stringWithFormat:@"%.0fmin",(self.walkingTime / 60.f)];
//    }];
//
//        MKDirectionsRequest *carRequest = [[MKDirectionsRequest alloc] init];
//    carRequest.transportType = MKDirectionsTransportTypeAutomobile;
//    carRequest.source = [[MKMapItem alloc] initWithPlacemark:sourceMark];
//
//    carRequest.destination = [[MKMapItem alloc] initWithPlacemark:mark];
//    
//    carRequest.requestsAlternateRoutes = YES;
//    MKDirections *direction2 = [[MKDirections alloc] initWithRequest:carRequest];
//    [direction2 calculateDirectionsWithCompletionHandler:^(MKDirectionsResponse * _Nullable response, NSError * _Nullable error) {
//        NSLog(@"gei Info Success ");
//        NSArray *array = response.routes;
//        NSTimeInterval totalTime = 0;
//        NSInteger times = 0;
//        double distance = 0;
//        for (MKRoute *route in array) {
//            totalTime += route.expectedTravelTime;
//            distance += route.distance;
//            times += 1;
//        }
//        NSLog(@"times = %ld",times);
//        NSLog(@"totalTime = %f",totalTime);
//        NSLog(@"total distance = %f",distance);
//        self.carTime = totalTime;
////        self.totalDistance = distance;
////        self.distanceLabel.text = [NSString stringWithFormat:@"%.1f km",self.totalDistance /1000];
////        self.carTimeLabel.text = [NSString stringWithFormat:@"%dh%.0fmin",(int)(self.carTime / 3600) ,((int)totalTime%3600 / 60.f)];
//        self.carTimeLabel.text = [NSString stringWithFormat:@"%.0fmin",self.carTime / 60.f];
//    }];

}

- (void)dismissPhotoPage:(UITapGestureRecognizer *)tap
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)showMapView:(UITapGestureRecognizer *)tap
{
//    LocationAnnotationViewController *locationAVC = [[LocationAnnotationViewController alloc] init];
//    [self presentViewController:locationAVC animated:YES completion:nil];
    MapViewController *mapVC = [[MapViewController alloc] init];
    mapVC.user = self.user;
    mapVC.distance = self.distanceLabel.text;
    mapVC.walkTime = self.timeLabel.text;
    mapVC.carTime = self.carTimeLabel.text;
    [self presentViewController:mapVC animated:YES completion:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

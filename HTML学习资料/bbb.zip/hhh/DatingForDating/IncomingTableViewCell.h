//
//  IncomingTableViewCell.h
//  DatingForDating
//
//  Created by MAXToooNG on 16/4/13.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSUInteger, CellType) {
    CellTypeText,
    CellTypeImage,
    CellTypeGps,
    CellTypeLeave,
    CellTypeTimeOut
};
@interface IncomingTableViewCell : UITableViewCell <UITextViewDelegate>
@property (nonatomic, assign) CellType cellType;
@property (nonatomic, strong) UIImageView *headView;
@property (nonatomic, strong) UIImageView *photoView;
@property (nonatomic, strong) UITextView *textView;
@property (nonatomic, strong) UIImageView *textViewBackgroundView;
- (void)initView;
@end

//
//  NotiTableViewCell.m
//  DatingForDating
//
//  Created by MAXToooNG on 16/4/17.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import "NotiTableViewCell.h"

@implementation NotiTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self initViews];
    }
    return self;
}

- (void)initViews
{
    self.headerView = [[UIImageView alloc] initWithFrame:CGRectMake(setW(12), setH(10), setW(40), setH(40))];
    self.headerView.layer.cornerRadius = setW(20);
    self.headerView.layer.masksToBounds = YES;
    [self.contentView addSubview:self.headerView];
    
    self.messageLabel = [[UILabel alloc] initWithFrame:CGRectMake(setW(12+12+40), setH(8), windowWidth() - setW(63 + 60), setH(42))];
    self.messageLabel.font = fontWithSize(18);
    self.messageLabel.textColor = colorWithHexString(@"#c2c2c2");
    self.messageLabel.minimumScaleFactor = 0.8;
    self.messageLabel.adjustsFontSizeToFitWidth = YES;
    self.messageLabel.numberOfLines = 2;
    self.messageLabel.textAlignment = NSTextAlignmentLeft;
    [self.contentView addSubview:self.messageLabel];
    
    self.timeLabel = [[UILabel alloc] initWithFrame:CGRectMake(windowWidth() - setW(60), setH(12), setW(60), setH(38))];
    self.timeLabel.font =  fontWithSize(18);
    self.timeLabel.textColor = colorWithHexString(@"#666666");
    self.timeLabel.textAlignment = NSTextAlignmentLeft;
    [self.contentView addSubview:self.timeLabel];
    self.contentView.backgroundColor = colorWithHexString(@"#181818");
    self.backgroundColor = colorWithHexString(@"#181818");
    self.lineView = [[UIView alloc] initWithFrame:CGRectMake(0, setH(60) - 1, windowWidth(), 1)];
    self.lineView.backgroundColor = colorWithHexString(@"#666666");
    [self.contentView addSubview:self.lineView];
}

@end

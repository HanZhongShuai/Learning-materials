//
//  ShowGpsInfoViewController.h
//  DatingForDating
//
//  Created by MAXToooNG on 16/4/27.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShowGpsInfoViewController : UIViewController

@property (nonatomic, strong) UserModel *user;

@end

//
//  MapViewController.m
//  DatingForDating
//
//  Created by MAXToooNG on 16/3/30.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import "MapViewController.h"
#import "RCAnnotation.h"
@import MapKit;

@interface MapViewController () <MKMapViewDelegate>
@property (nonatomic, strong) MKMapView *mapView;
@property (nonatomic, strong) UIView *bottomView;
@property (nonatomic, strong) UILabel *distanceLabel;
@property (nonatomic, strong) UILabel *timeLabel;
@property (nonatomic, strong) UILabel *carTimeLabel;
@end

@implementation MapViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initViews];
}

- (void)initViews{
    self.mapView = [[MKMapView alloc] initWithFrame:self.view.bounds];
    self.mapView.delegate = self;
    [self.view addSubview:self.mapView];
    self.mapView.showsUserLocation = YES;
    self.bottomView = [[UIView alloc] initWithFrame:CGRectMake(0, windowHeight() - setH(25), windowWidth(), setH(25))];
    self.bottomView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.6];
    [self.view addSubview:self.bottomView];
    UIView *distanceView = [[UIImageView alloc] initWithFrame:CGRectMake(0, setH(5), setW(54), setH(15))];
    distanceView.backgroundColor = [UIColor clearColor];
    //    distanceImage.image = [UIImage imageNamed:@"card_ic_distance"];
    [self.bottomView addSubview:distanceView];
    UIImageView *distanceImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, setW(14), setH(14))];
    distanceImageView.image = [UIImage imageNamed:@"card_ic_distance"];
    [distanceView addSubview:distanceImageView];
    self.distanceLabel = [[UILabel alloc] initWithFrame:CGRectMake(setW(15), 0, setW(40), setH(15))];
    self.distanceLabel.text = self.distance;
    self.distanceLabel.textColor = [UIColor whiteColor];
    self.distanceLabel.font = [UIFont systemFontOfSize:10];
    [distanceView addSubview:self.distanceLabel];
    
    UIView *timeView = [[UIView alloc] initWithFrame:CGRectMake(0 + setW(54 + 13), setH(5), setW(54), setH(15))];
    UIImageView *timeImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, setW(14), setH(14))];
    timeImageView.image = [UIImage imageNamed:@"card_ic_foot"];
    [self.bottomView addSubview:timeView];
    [timeView addSubview:timeImageView];
    self.timeLabel = [[UILabel alloc] initWithFrame:CGRectMake(setW(15), 0, setW(40), setH(15))];
    self.timeLabel.text = self.walkTime;
    self.timeLabel.textColor = [UIColor whiteColor];
    self.timeLabel.font = [UIFont systemFontOfSize:10];
    [timeView addSubview:self.timeLabel];
    
    UIView *carTimeView = [[UIView alloc] initWithFrame:CGRectMake(0 + setW(54 + 13 + 54 + 13), setH(5), setW(54), setH(15))];
    UIImageView *carImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, setW(14), setH(14))];
    carImageView.image = [UIImage imageNamed:@"card_ic_taxi"];
    [self.bottomView addSubview:carTimeView];
    [carTimeView addSubview:carImageView];
    
    self.carTimeLabel = [[UILabel alloc] initWithFrame:CGRectMake(setW(15), 0, setW(40), setH(15))];
    self.carTimeLabel.text = self.carTime;
    self.carTimeLabel.textColor = [UIColor whiteColor];
    self.carTimeLabel.font = [UIFont systemFontOfSize:10];
    [carTimeView addSubview:self.carTimeLabel];
    
    UIButton *cancelButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [cancelButton setImage:[UIImage imageNamed:@"ic_closed_nor"] forState:UIControlStateNormal];
    [cancelButton setImage:[UIImage imageNamed:@"ic_closed_pre"] forState:UIControlStateHighlighted];
    cancelButton.frame = CGRectMake(windowWidth() - 13 - 22, 2, 22, 22);
    [cancelButton addTarget:self action:@selector(dismissVC:) forControlEvents:UIControlEventTouchUpInside];
    [self.bottomView addSubview:cancelButton];
    
    CLLocationDegrees lat = self.user.lat.doubleValue;
    CLLocationDegrees lon = self.user.lon.doubleValue;
    
    CLLocationCoordinate2D coordinate = CLLocationCoordinate2DMake(lat, lon);
    NSLog(@"coordinate = %f  ,  %f",lat,lon);
    MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance(coordinate, 1000, 1000);
    MKCoordinateRegion adjustedRegion = [self.mapView regionThatFits:region];
    [self.mapView setRegion:adjustedRegion animated:YES];
    RCAnnotation *annotation = [[RCAnnotation alloc] init];
    [annotation setCoordinate:coordinate];
    [self.mapView addAnnotation:annotation];
}

- (void)dismissVC:(UIButton *)btn
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id<MKAnnotation>)annotation
{
    NSLog(@"annotation = %@",annotation);
    MKPinAnnotationView *pinView = [[MKPinAnnotationView alloc] init];
    pinView.pinColor = MKPinAnnotationColorRed;
    pinView.draggable = YES;
    
    MKAnnotationView *annotationView = [[MKAnnotationView alloc] init];
    annotationView.image = [UIImage imageNamed:@"chat_ic_map"];
    if ([annotation isKindOfClass:[RCAnnotation class]]) {
        return annotationView;
        
    }
    return nil;
    
}

- (void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation
{
    
//    route.transportType = MKDirectionsTransportTypeWalking;
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc
{
    NSLog(@"dealloc");
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

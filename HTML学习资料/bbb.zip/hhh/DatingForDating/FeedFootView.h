//
//  FeedFootView.h
//  DatingForDating
//
//  Created by MAXToooNG on 16/4/18.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FeedFootView : UIView

@property (nonatomic, strong) UIButton *deleteBtn;
@property (nonatomic, strong) UILabel *timeLabel;
- (instancetype)initWithFrame:(CGRect)frame;
@end

//
//  RequestViewController.m
//  DatingForDating
//
//  Created by MAXToooNG on 16/3/15.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import "RequestViewController.h"
#import "StoreManager.h"
#import "StoreObserver.h"
#import <AFNetworking/AFHTTPSessionManager.h>
#import "DESCrypt.h"
#import "Utility.h"
#import <ReactiveCocoa/ReactiveCocoa.h>
#import "DetailInfoViewController.h"
#import "CommonUtil.h"
#import <Sinch/Sinch.h>
#import "UserModel.h"
#import "UIImageView+WebCache.h"
#import "RequestFeedCell.h"
#import "UIImage+Utility.h"
#import "NetworkingManager.h"
#import "NotiTableViewCell.h"
#import "CommunicationViewController.h"
#import "FeedFootView.h"
#import "FeedDeleteView.h"
#import "RCMessage.h"
#import "WinkScrollView.h"
#import "SettingTableCell.h"
#import "THCircularProgressView.h"
#import "LoadingAnimationView.h"
#import "LocationGuideView.h"
#import "AdView.h"
#import "ProductView.h"
#import "FreeOneMonthView.h"
#import "MyModel.h"
#import "RestoreViewController.h"
#import "TermsViewController.h"
#import <MessageUI/MFMailComposeViewController.h>

@interface RequestViewController () <UIActionSheetDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UIAlertViewDelegate, UITableViewDelegate, UITableViewDataSource, SINClientDelegate, SINMessageClientDelegate,MFMailComposeViewControllerDelegate>
@property (nonatomic, strong) UIImageView *uploadImageView;
// add photo and request
@property (nonatomic, strong) UIView *mainRequestView;
@property (nonatomic, strong) UIView *requestLoadingView;
@property (nonatomic, strong) UIView *rightView;
@property (nonatomic, strong) UIImagePickerController *imagePicker;
@property (nonatomic, strong) UIActionSheet *actionSheet;
@property (nonatomic, strong) UIButton *submitButton;
@property (nonatomic, strong) UIView *deleteButtonView;
@property (nonatomic, strong) NSArray *settingIconArray;
@property (weak, nonatomic) IBOutlet WinkScrollView *mainScrollView;
//setting View
@property (nonatomic, strong) UITableView *leftTableView;
// request feed view
@property (nonatomic, strong) UITableView *mainTableView;
//communicate view
@property (nonatomic, strong) UITableView *rightTableView;

@property (nonatomic, assign) BOOL isRequesting;
@property (nonatomic, strong) NSMutableArray *settingArray;
@property (nonatomic, strong) NSMutableArray *communicationArray;
@property (nonatomic, strong) NSMutableArray *notiArray;
@property (nonatomic, strong) NSMutableArray *feedDataArray;
@property (nonatomic, strong) NSArray *rightDataArray;
@property (nonatomic, strong) id<SINClient> sinClient;
@property (nonatomic, strong) id<SINMessageClient> messageClient;
@property (nonatomic, strong) NSData *uploadData;
@property (nonatomic, strong) UIAlertView *deleteAlert;
@property (nonatomic, strong) UITextView *tipsView;
@property (nonatomic, strong) UISegmentedControl *segment;
@property (nonatomic, strong) UIButton *notiBtn;
@property (nonatomic, strong) UIButton *commBtn;
@property (nonatomic, strong) UserModel *reportUser;

@property (nonatomic, strong) UIAlertView *reportAlert;
@property (nonatomic, strong) UIAlertView *reportUserAlert;
@property (nonatomic, assign) NSInteger deleteIndex;

@property (nonatomic, strong) FeedFootView *fView;
@property (nonatomic, strong) FeedDeleteView *fDv;
@property (nonatomic, assign) BOOL timerStart;
@property (nonatomic, strong) NSTimer *requestTimer;
@property (nonatomic, strong) UIView *notiView;
@property (nonatomic, strong) UIImageView *notiHeaderView;
@property (nonatomic, strong) UILabel *tipsLabel;
@property (nonatomic, strong) THCircularProgressView *progressView;
@property (nonatomic ,strong) LoadingAnimationView *animationView;
@property (nonatomic, strong) UIImageView *uploadLoadingView;
@property (nonatomic, strong) UIImageView *tips;
@property (nonatomic, strong) UIAlertView *deleteTipsAlert;
@property (nonatomic, strong) UIBarButtonItem *rightItem;
@property (nonatomic, strong) UILabel *loadingTipsLabel;
@property (nonatomic, strong) AdView *adView;
@property (nonatomic, strong) ProductView *productView;
@property (nonatomic, strong) LocationGuideView *locationGuideView;
@property (nonatomic, strong) FreeOneMonthView *freeOneMonthView;
@property (nonatomic, assign) BOOL submitFlag;
@property (nonatomic, strong) UIButton *settingBtn;
@property (nonatomic, strong) UIButton *notiTitleBtn;
@property (nonatomic, strong) UIButton *feedBtnLeft;
@property (nonatomic, strong) UIButton *feedBtnRight;
@property (nonatomic, strong) UILabel *winkLabel;
@property (nonatomic, strong) UILabel *messageLabel;
@property (nonatomic, strong) UILabel *settingLabel;

@end

@implementation RequestViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _submitFlag = NO;
    _timerStart = YES;
    [[SKPaymentQueue defaultQueue] addTransactionObserver:[StoreObserver sharedInstance]];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(handleProductRequestNotification:)
                                                 name:IAPProductRequestNotification
                                               object:[StoreManager sharedInstance]];
//
//    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(handlePurchasesNotification:)
                                                 name:@"IAPPurchaseNotification"
                                               object:[StoreObserver sharedInstance]];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(canceled:)
                                                 name:@"canceled"
                                               object:[StoreObserver sharedInstance]];
    
//
//    
//    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(selectPhoto:)];
//    [self.uploadImageView addGestureRecognizer:tap];
//    self.uploadImageView.userInteractionEnabled = YES;
    [self fetchProductInformation];
//
//    [self configAFNetworking];
    [self initData];
    [self initViews];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshAllInfo) name:kRefreshFeedList object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(startFire) name:@"changeTime" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self  selector:@selector(stopFire) name:UIApplicationDidEnterBackgroundNotification object:nil];
    
//    [self testNotiData];
//    [self test];
    [self setNavigationAnimation];
}

- (void)setNavigationAnimation
{
    RACSignal *scrollSignal = RACObserve(self.mainScrollView, contentOffset);
    [scrollSignal subscribeNext:^(id x) {
        NSLog(@"x = %@",[x class]);
        NSValue *value = x;
        CGPoint point = value.CGPointValue;
        CGFloat offsetX = point.x;
        if (offsetX <= 0) {
            self.feedBtnLeft.alpha = 0;
            self.settingBtn.alpha = 0;
            self.feedBtnLeft.hidden = YES;
            self.settingBtn.hidden = YES;
            
            self.feedBtnRight.hidden = NO;
            self.feedBtnRight.alpha = 1;
            self.notiTitleBtn.hidden = YES;
            self.notiTitleBtn.alpha = 0;
            
            self.settingLabel.alpha = 1;
            self.messageLabel.alpha = 0;
            self.winkLabel.alpha = 0;
        }else if (offsetX > 0 && offsetX<windowWidth()){
            self.feedBtnLeft.hidden = YES;
            self.settingBtn.hidden = NO;
            self.settingBtn.alpha = 1 - ((windowWidth() - offsetX) / windowWidth());
            self.feedBtnLeft.alpha = 0;
            
            self.feedBtnRight.hidden = NO;
            self.notiTitleBtn.hidden = NO;
            self.notiTitleBtn.alpha = 1 - ((windowWidth() - offsetX) / windowWidth());
            self.feedBtnRight.alpha = (windowWidth() - offsetX) / windowWidth();
            
            self.settingLabel.alpha = (windowWidth() - offsetX) / windowWidth();
            self.messageLabel.alpha = 0;
            self.winkLabel.alpha = 1 - ((windowWidth() - offsetX) / windowWidth());
        }else if (offsetX >= windowWidth() && offsetX < windowWidth()*2){
            self.feedBtnLeft.hidden = NO;
            self.settingBtn.hidden = NO;
            self.settingBtn.alpha = (windowWidth() * 2 - offsetX) / windowWidth();
            self.feedBtnLeft.alpha = 1 - (windowWidth() * 2 - offsetX) / windowWidth();
            
            self.feedBtnRight.hidden = YES;
            self.notiTitleBtn.hidden = NO;
            self.notiTitleBtn.alpha = (windowWidth() * 2 - offsetX) / windowWidth();
            self.feedBtnRight.alpha = 0;
            
            self.settingLabel.alpha = 0;
            self.messageLabel.alpha = 1 - (windowWidth() * 2 - offsetX) / windowWidth();
            self.winkLabel.alpha = (windowWidth() * 2 - offsetX) / windowWidth();
        }else{
            self.feedBtnLeft.hidden = NO;
            self.settingBtn.hidden = YES;
            self.settingBtn.alpha = 0;
            
            self.feedBtnRight.alpha = 0;
            self.notiTitleBtn.alpha = 0;
            self.feedBtnRight.hidden = YES;
            self.notiTitleBtn.hidden = YES;
            
            self.settingLabel.alpha = 0;
            self.messageLabel.alpha = 1;
            self.winkLabel.alpha = 0;
        }
        //        CGPoint offsetX = x;
        //        CGFloat offsetXf = offsetX.floatValue;
        NSLog(@"offsetx = %f",offsetX);
    } error:^(NSError *error) {
        
    }];

}

- (void)stopFire
{
    [self.requestTimer invalidate];
    [self.animationView resume];
}

-(void)startFire
{
    if (self.isRequesting) {
        [self.requestTimer invalidate];
        self.requestTimer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(timerFireMethod:) userInfo:nil repeats:YES];
    }
}

- (void)refreshAllInfo
{
    if (self.isRequesting) {
        [self getFeedList];
        [self requeryNotiList];
    }
}

- (void)testNotiData
{
    [self.mainRequestView removeFromSuperview];
    [self initCommunicateView];
    UserModel *user = [[UserModel alloc] init];
    user.notiString = @"ssssssss";
    [self.communicationArray addObject:user];
    self.rightDataArray = self.notiArray;
    [self.rightTableView reloadData];
}

- (void)initData
{
    self.feedDataArray = [[NSMutableArray alloc] init];
    self.notiArray = [[NSMutableArray alloc] init];
    self.communicationArray = [[NSMutableArray alloc] init];
    if ([CommonUtil defaultUtil].commArray) {
        self.communicationArray = [[NSMutableArray alloc] initWithArray:[CommonUtil defaultUtil].commArray];
    }
    self.rightDataArray = [[NSMutableArray alloc] init];
}

- (void)test{
    SINOutgoingMessage *message = [SINOutgoingMessage messageWithRecipient:@"3"text:@"Hi there!"];
    self.messageClient = [self.sinClient messageClient];
    self.messageClient.delegate = self;
    [self.messageClient sendMessage:message];
   
}

- (void)messageSent:(id<SINMessage>)message recipientId:(NSString *)recipientId
{
    NSString *type = [message.headers objectForKey:@"type"];
    MessageType messageType = type.integerValue;
    if (messageType == MessageText || messageType == MessageGPS || messageType == MessageImage || messageType == MessageLeave || messageType == MessageTimeOut) {
     [[NSNotificationCenter defaultCenter] postNotificationName:kMessageCommunication object:message];
        [self setSaveDataWithMessage:message];
    }
    NSLog(@"recipientid = %@",recipientId);
}

- (void)messageFailed:(id<SINMessage>)message info:(id<SINMessageFailureInfo>)messageFailureInfo
{
    NSLog(@"failed toID = %@ error= %@",messageFailureInfo.recipientId,messageFailureInfo.error.localizedDescription);
}

- (void)messageDelivered:(id<SINMessageDeliveryInfo>)info
{
    NSLog(@"messageInfo = %@,%@",info.messageId, info.recipientId);
}

- (void)message:(id<SINMessage>)message shouldSendPushNotifications:(NSArray *)pushPairs
{
    NSLog(@"pushPairs = %@",pushPairs);
}

- (void)messageClient:(id<SINMessageClient>)messageClient didReceiveIncomingMessage:(id<SINMessage>)message
{
    NSLog(@"MESSAGE INFO sender ID = %@, recipientId = %@ text = %@ , headers = %@",message.senderId , message.recipientIds, message.text,message.headers);
    NSString *type = [message.headers objectForKey:@"type"];
    MessageType messageType = type.integerValue;
    if (messageType == MessageText || messageType == MessageGPS || messageType == MessageImage || messageType == MessageLeave || messageType == MessageTimeOut) {
//        for (UserModel *user in self.communicationArray) {
//            if (user.requestId.intValue == message.senderId.intValue) {
//                RCMessage *mess = message;
//                [user.communiDataArray addObject:message];
////                NSArray *commDataArray = [NSArray arrayWithArray:user.communiDataArray];
//                NSData *data = [NSKeyedArchiver archivedDataWithRootObject:mess];
//                NSArray *oldArray = [userdefault objectForKey:[NSString stringWithFormat:@"%ld",user.requestId.integerValue]];
//                if (oldArray) {
//                    NSMutableArray *dataArray = [NSMutableArray arrayWithArray:oldArray];
//                    [dataArray addObject:data];
//                    NSArray *saveArray = [NSArray arrayWithArray:dataArray];
//                    [userdefault setObject:saveArray forKey:[NSString stringWithFormat:@"%ld",user.requestId.integerValue]];
//                }
//            }
//        }
        
        [self setSaveDataWithMessage:message];
        [[NSNotificationCenter defaultCenter] postNotificationName:kMessageCommunication object:message];
    }
    switch (messageType) {
        case MessageText:
        {
            //Text
            [[NSNotificationCenter defaultCenter] postNotificationName:kMessageText object:message];
        }
            break;
        case MessageImage:
        {
            //Image
            [[NSNotificationCenter defaultCenter] postNotificationName:kMessageImage object:message];
            
        }
            break;
        case MessageGPS:
        {
            //GPS
            [[NSNotificationCenter defaultCenter] postNotificationName:kMessageGPS object:message];
        }
            break;
        case MessageLike:
        {
            [[NSNotificationCenter defaultCenter] postNotificationName:kMessageLike object:message];
            [self getFeedList];
            [self setNotiData:message];
        }
            break;
        case MessageMatch:
        {
            [[NSNotificationCenter defaultCenter] postNotificationName:kMessageMatch object:message];
            [self setNotiData:message];
        }
            break;
        case MessageWhoLikeU:
        {
            [[NSNotificationCenter defaultCenter] postNotificationName:kMessageWhoLikeU object:message];
        }
            break;
        case MessageLeave:
        {
            [[NSNotificationCenter defaultCenter] postNotificationName:kMessageLeave object:message];
        }
            break;
        case MessageTimeOut:
        {
            [[NSNotificationCenter defaultCenter] postNotificationName:kMessageTimeOut object:message];
        }
            break;
        default:
            break;
    }
}

- (void)setSaveDataWithMessage:(id<SINMessage>)message
{
    for (UserModel *user in self.communicationArray) {
        if (user.requestId.intValue == message.senderId.intValue || [message.recipientIds containsObject:[NSString stringWithFormat:@"%d",user.requestId.intValue]]) {
            self.tips.hidden = NO;
            RCMessage *mess = [[RCMessage alloc] initWithMessage:message];
            [user.communiDataArray addObject:mess];
            [self.rightTableView reloadData];
            //                NSArray *commDataArray = [NSArray arrayWithArray:user.communiDataArray];
            NSData *data = [NSKeyedArchiver archivedDataWithRootObject:mess];
            NSArray *oldArray = [userdefault objectForKey:[NSString stringWithFormat:@"%@_%@",((NSNumber *)[userdefault objectForKey:kRequestId]).stringValue,user.requestId.stringValue]];
            if (oldArray) {
                NSMutableArray *dataArray = [NSMutableArray arrayWithArray:oldArray];
                [dataArray addObject:data];
                NSArray *saveArray = [NSArray arrayWithArray:dataArray];
                [userdefault setObject:saveArray forKey:[NSString stringWithFormat:@"%@_%@",((NSNumber *)[userdefault objectForKey:kRequestId]).stringValue,user.requestId.stringValue]];
                [userdefault synchronize];
            }else{
                 NSMutableArray *dataArray = [[NSMutableArray alloc] init];
                [dataArray addObject:data];
                NSArray *saveArray = [NSArray arrayWithArray:dataArray];
                [userdefault setObject:saveArray forKey:[NSString stringWithFormat:@"%@_%@",((NSNumber *)[userdefault objectForKey:kRequestId]).stringValue,user.requestId.stringValue]];
                [userdefault synchronize];
            }
        }
    }

}

- (void)initIMSDKWithRequestId:(NSNumber *)requestId
{
    [self.sinClient stop];
    [self.sinClient terminate];
    if (requestId) {
        self.sinClient = [Sinch clientWithApplicationKey:@"c1166977-4492-4f52-a54a-26ec65f87b7e" applicationSecret:@"uY3LjtMsRU6WufeHL9tKCw==" environmentHost:@"clientapi.sinch.com" userId:requestId.stringValue];
        NSLog(@"initSDK userId = %@",requestId.stringValue);
        [CommonUtil defaultUtil].sinchClient = self.sinClient;
        [self.sinClient setSupportMessaging:YES];
        [self.sinClient setSupportPushNotifications:YES];
        [self.sinClient enableManagedPushNotifications];
        self.sinClient.delegate = self;
        [self.sinClient start];
        [self.sinClient startListeningOnActiveConnection];
        self.messageClient = [self.sinClient messageClient];
        self.messageClient.delegate = self;

    }else{
        NSLog(@"warning!!!!!!!!!\nwarnin\nwarni\n!!!!!!!!!!!!!!!");
    }
}

- (void)setNotiData:(id<SINMessage>)message
{ 
    if (!self.notiArray) {
        self.notiArray = [[NSMutableArray alloc] init];
    }
    NSString *type = [message.headers objectForKey:@"type"];
    MessageType messageType = type.integerValue;
    NSNumber *requestId = [NSNumber numberWithInteger:message.text.integerValue];
    self.tips.hidden = NO;
    if (messageType == MessageLike) {
        [self queryLikeRequestInfoWithRequestId:requestId];
        
    }else if (messageType == MessageMatch){
        [self queryMatchRequestInfoWithRequestId:requestId];
//        [self requeryNotiList];

    }
    NSLog(@"receive Message.text = %@",message.text);
}

- (void)queryLikeRequestInfoWithRequestId:(NSNumber *)requestId
{
    NetworkingManager *manager = [NetworkingManager manager];
    [manager queryRequestInfoWithRequestId:requestId success:^(NSURLSessionDataTask *task, id responseObject) {
        NSDictionary *result = (NSDictionary *)responseObject;
        NSLog(@"queryRequestInfo = %@",result);
        NSNumber *stateNumber = [result objectForKey:@"state"];
        if (stateNumber.integerValue == 10000) {
            NSLog(@"querySuccess");
            NSDictionary *userDic = [result objectForKey:@"user_request"];
            if (![userDic isKindOfClass:[NSNull class]]) {
                UserModel *user = [[UserModel alloc] init];
                user.userId = [userDic objectForKey:@"userid"];
                user.beginTime = [userDic objectForKey:@"b_time"];
                user.endTime = [userDic objectForKey:@"e_time"];
                user.lon = [userDic objectForKey:@"lon"];
                user.lat = [userDic objectForKey:@"lat"];
                user.headViewUrlString_L = [userDic objectForKey:@"url_big"];
                user.headViewUrlString_S = [userDic objectForKey:@"url_small"];
                //            user.gender = [userDic objectForKey:@"gender"];
                //                user.dateTime = [userDic objectForKey:@"date_time"];
                user.requestId = [userDic objectForKey:@"requestid"];
                user.status = [userDic objectForKey:@"status"];

                if (self.isRequesting) {
                    [self showLikeNotiWithUser:user string:LocalizedString(@"like_you", nil)];
                    user.likeTag = YES;
                    //                [self refreshFeedViewWithUser:user];
                    [self requeryNotiList];
                }
            }
           
        }
    } error:^(NSError *err) {
        NSLog(@"queryError = %@",err.localizedDescription);
    }];
}

- (void)showLikeNotiWithUser:(UserModel *)user string:(NSString *)string;
{
    if (!self.notiView) {
        self.notiView = [[UIView alloc] initWithFrame:CGRectMake(windowWidth(), -51, windowWidth(), 51)];
        self.notiView.backgroundColor = colorWithHexString(@"#e64f30");
        self.notiHeaderView = [[UIImageView alloc] initWithFrame:CGRectMake(9, 4, 46, 46)];
        self.notiHeaderView.layer.cornerRadius = 23;
        self.notiHeaderView.layer.masksToBounds = YES;
        [self.notiView addSubview:self.notiHeaderView];
        self.tipsLabel = [[UILabel alloc] initWithFrame:CGRectMake(9 + 46 + 4, 4, windowWidth() - 9-46-4-4, 46)];
        self.tipsLabel.textColor = [UIColor whiteColor];
        self.tipsLabel.textAlignment = NSTextAlignmentLeft;
        [self.notiView addSubview:self.tipsLabel];
        self.notiView.alpha = 0;
    }
    [self.mainScrollView addSubview:self.notiView];
    [self.notiHeaderView sd_setImageWithURL:[NSURL URLWithString:user.headViewUrlString_S]];
    NSLog(@"---------------------------%ld",user.status.integerValue);
        [self.tipsLabel setText:string];

    self.notiView.alpha = 0;
    [UIView animateWithDuration:1.5 animations:^{
        self.notiView.alpha = 1;
        CGRect frame = CGRectMake(self.notiView.frame.origin.x, 0, self.notiView.frame.size.width, self.notiView.frame.size.height);
        self.notiView.frame = frame;
    } completion:^(BOOL finished) {
       [UIView animateWithDuration:1.5 animations:^{
           self.notiView.alpha = 0;
           CGRect frame = CGRectMake(self.notiView.frame.origin.x, -51, self.notiView.frame.size.width, self.notiView.frame.size.height);
           self.notiView.frame = frame;
       } completion:^(BOOL finished) {
            [self.notiView removeFromSuperview];
       }];
    }];
    
    
}

//
//
- (void)queryMatchRequestInfoWithRequestId:(NSNumber *)requestId
{
    NetworkingManager *manager = [NetworkingManager manager];
    [manager queryRequestInfoWithRequestId:requestId success:^(NSURLSessionDataTask *task, id responseObject) {
        NSDictionary *result = (NSDictionary *)responseObject;
        NSLog(@"queryRequestInfo = %@",result);
        NSNumber *stateNumber = [result objectForKey:@"state"];
        if (stateNumber.integerValue == 10000) {
            NSLog(@"querySuccess");
            NSDictionary *userDic = [result objectForKey:@"user_request"];
            UserModel *user = [[UserModel alloc] init];
            user.userId = [userDic objectForKey:@"userid"];
            user.beginTime = [userDic objectForKey:@"b_time"];
            user.endTime = [userDic objectForKey:@"e_time"];
            user.lon = [userDic objectForKey:@"lon"];
            user.lat = [userDic objectForKey:@"lat"];
            user.headViewUrlString_L = [userDic objectForKey:@"url_big"];
            user.headViewUrlString_S = [userDic objectForKey:@"url_small"];
            //            user.gender = [userDic objectForKey:@"gender"];
            //                user.dateTime = [userDic objectForKey:@"date_time"];
            user.requestId = [userDic objectForKey:@"requestid"];
            user.status = [userDic objectForKey:@"status"];
            user.notiString = @"match";
            if (self.isRequesting) {
                [self showLikeNotiWithUser:user string:LocalizedString(@"new_match", nil)];
                user.likeTag = YES;
                //                [self refreshFeedViewWithUser:user];
                [self requeryNotiList];
            }
        }
    } error:^(NSError *err) {
        NSLog(@"queryError = %@",err.localizedDescription);
    }];
}

- (void)requeryNotiList
{
    NetworkingManager *manager = [NetworkingManager manager];
    [manager getAllLikedUsUserInfoWithRequestId:[userdefault objectForKey:kRequestId] success:^(NSURLSessionDataTask *task, id responseObject) {
        NSDictionary *result = (NSDictionary *)responseObject;
        NSLog(@"getLike List result = %@",result);
        NSNumber *stateNum = [result objectForKey:@"state"];
        if (stateNum.intValue == 10000) {
            [self.notiArray removeAllObjects];
            NSLog(@"get LIke list Success");
            NSArray *userArray = [result objectForKey:@"list"];
            for (NSDictionary *userDic in userArray) {
                UserModel *user = [[UserModel alloc] init];
                user.requestId = [userDic objectForKey:@"requestid1"];
                user.userId = [userDic objectForKey:@"userid1"];
                user.gender = [userDic objectForKey:@"gender1"];
                user.likedTime = [userDic objectForKey:@"l_time"];
                user.status = [userDic objectForKey:@"status"];
                user.headViewUrlString_L = [userDic objectForKey:@"url_big1"];
                user.headViewUrlString_S = [userDic objectForKey:@"url_small1"];
                if (user.status.intValue == 3) {
                    if(user.gender.intValue == 0){
                        user.notiString = [NSString stringWithFormat:@"%@ %@",LocalizedString(@"she", nil),LocalizedString(@"like_you", nil)];
                    }else{
                        user.notiString = [NSString stringWithFormat:@"%@ %@",LocalizedString(@"he", nil),LocalizedString(@"like_you", nil)];
                    }
                }else if (user.status.intValue == 5){
                    user.notiString = LocalizedString(@"new_match", nil);
                }
            
                [self.notiArray addObject:user];
                [self.rightTableView reloadData];
            }
        }else{
         [self.notiArray removeAllObjects];
            [self.rightTableView reloadData];

        }
    } error:^(NSError *err) {
        NSLog(@"get like list Error = %@",err.localizedDescription);
    }];
    
    [manager queryMatchingRequestsSuccess:^(NSURLSessionDataTask *task, id responseObject) {
        NSDictionary *result = (NSDictionary *)responseObject;
        NSLog(@"get match result = %@",result);
        NSNumber *stateNum = [result objectForKey:@"state"];
        if (stateNum.intValue == 10000) {
//            [self.communicationArray removeAllObjects];
            NSArray *array = [CommonUtil defaultUtil].commArray;
            NSMutableArray *newArray = [[NSMutableArray alloc] init];
            NSLog(@"get match list Success");
            NSArray *userArray = [result objectForKey:@"list"];
            for (NSDictionary *userDic in userArray) {
                UserModel *user = [[UserModel alloc] init];
                NSNumber *requestId = [userDic objectForKey:@"requestid1"];
                if (requestId.intValue != ((NSNumber *)[userdefault objectForKey:kRequestId]).intValue) {
                    user.requestId = requestId;
                    user.headViewUrlString_S = [userDic objectForKey:@"url_small1"];
                    user.headViewUrlString_L = [userDic objectForKey:@"url_big1"];
                }else{
                    user.requestId = [userDic objectForKey:@"requestid2"];
                    user.headViewUrlString_S = [userDic objectForKey:@"url_small2"];
                    user.headViewUrlString_L = [userDic objectForKey:@"url_big2"];
                }
                user.commId = [userDic objectForKey:@"id"];
                NSNumber *userId = [userDic objectForKey:@"userid1"];
                if (userId.intValue != ((NSNumber *)[userdefault objectForKey:kUserId]).intValue) {
                    user.userId = userId;
                }else{
                    user.userId = [userDic objectForKey:@"userid2"];
                }
                NSNumber *gender = [NSNumber numberWithInt:(1 - ((NSNumber *) [userdefault objectForKey:kGender]).intValue)];
                user.gender = gender;
                user.beginTime = [userDic objectForKey:@"b_time"];
                user.endTime = [userDic objectForKey:@"e_time"];
               
                NSNumber *status = [userDic objectForKey:@"status"];
                if (status.intValue == 0) {
                    [newArray addObject:user];
//                    [self.communicationArray addObject:user];
                    [self.rightTableView reloadData];
                }
            }
            if (!array || array.count <= 0) {
                self.communicationArray = [newArray mutableCopy];
            }else{
                self.communicationArray = [array mutableCopy];
                for (int i = 0; i < newArray.count; i++) {
                    UserModel *user = newArray[i];
                    for (int j = 0; j < array.count; j++) {
                        UserModel *oriUser = array[j];
                        if (oriUser.commId.intValue == user.commId.intValue) {
                            break;
                        }else{
                            if (j == array.count - 1) {
                                [self.communicationArray addObject:user];
                            }
                        }
                        
                    }
                }
                for (UserModel *user in self.communicationArray) {
                    [self setCommuniDataWithUser:user];
                }
            }
            [self saveMatchListData];
        }

    } error:^(NSError *err) {
        NSLog(@"get match info Error = %@",err.localizedDescription);
    }];
    
}

- (void)saveMatchListData
{
    [CommonUtil defaultUtil].commArray = [self.communicationArray copy];
    NSMutableArray *saveArray = [[NSMutableArray alloc] init];
    for (UserModel *user in self.communicationArray) {
        NSData *data = [NSKeyedArchiver archivedDataWithRootObject:user];
        [saveArray addObject:data];
    }
    [userdefault setObject:[NSArray arrayWithArray:saveArray] forKey:kCommArray];
    [userdefault synchronize];

}

- (void)setCommuniDataWithUser:(UserModel *)user
{
    NSArray *oldDataArray = [userdefault objectForKey:[NSString stringWithFormat:@"%@_%@",((NSNumber *)[userdefault objectForKey:kRequestId]).stringValue,user.requestId.stringValue]];
    user.communiDataArray = [[NSMutableArray alloc] init];
    if (oldDataArray) {
        for (NSData *data in oldDataArray) {
            RCMessage *message = [NSKeyedUnarchiver unarchiveObjectWithData:data];
            NSLog(@"message = %@ %@ %@",message.senderId,message.recipientIds,message.text);
            [user.communiDataArray addObject:message];
        }
    }
}

- (void)refreshFeedViewWithUser:(UserModel *)newUser
{
    BOOL isRepeat = NO;
    for (UserModel *user in self.feedDataArray) {
        if (user.userId.integerValue == newUser.userId.integerValue) {
            user.likeTag = YES;
            isRepeat = YES;
        }
    }
    if (!isRepeat) {
        [self.feedDataArray addObject:newUser];
    }
    if (self.feedDataArray.count >0) {
        [self.requestLoadingView removeFromSuperview];
        self.mainTableView.tableFooterView = self.fView;
    }else{
        self.mainTableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    }
    [self.mainTableView reloadData];
}

- (void)sendMatchMessageWithUser:(UserModel *)user;
{
    [self.communicationArray addObject:user];
    [self.rightTableView reloadData];
       NSString *requestString = user.requestId.stringValue;
    NSString *requestId = [NSString stringWithFormat:@"%ld",user.requestId.integerValue];
    SINOutgoingMessage *message = [SINOutgoingMessage messageWithRecipient:requestId text:requestString];
    [message addHeaderWithValue:[NSString stringWithFormat:@"%lu",MessageMatch] key:@"type"];
    self.messageClient = [self.sinClient messageClient];
    self.messageClient.delegate = self;
    [self.messageClient sendMessage:message];
}

- (void)like:(UIButton *)btn
{
    UserModel *user = [self.feedDataArray objectAtIndex:btn.tag];
    [self doLikeWithUser:user likeOrNot:0];
}

- (void)pass:(UIButton *)btn
{
    UserModel *user = [self.feedDataArray objectAtIndex:btn.tag - 10000];
    [self doLikeWithUser:user likeOrNot:1];
}

- (void)reportPhoto:(UIButton *)btn
{
    UserModel *user = [self.feedDataArray objectAtIndex:btn.tag - 20000];
    self.reportUser = user;
    self.reportAlert = [[UIAlertView alloc] initWithTitle:@"Tips" message:@"report" delegate:self cancelButtonTitle:@"YES" otherButtonTitles:@"NO", nil];
    [self.reportAlert show];
}

- (void)doLikeWithUser:(UserModel *)user likeOrNot:(NSInteger)likeOrNot
{
    NSNumber *userId = [NSNumber numberWithInteger:user.userId.integerValue];
    NetworkingManager *manager = [NetworkingManager manager];
    NSNumber *requestId = [userdefault objectForKey:kRequestId];
    [manager doLikeWithFromRequestId:requestId toUserId:userId toRequestid:user.requestId likeOrNot:likeOrNot success:^(NSURLSessionDataTask *task, id responseObject) {
        NSDictionary *result = (NSDictionary *)responseObject;
        NSNumber *stateNumber = [result objectForKey:@"state"];
        NSLog(@"like or pass = %@",result);
        if (stateNumber.integerValue == 10000) {
            NSLog(@"Like or Pass Success");
            NSNumber *statusNum = [result objectForKey:@"status"];
            switch (statusNum.integerValue) {
                case 0:
                {
                    // 你 like 了对方
                    NSNumber *requestId = [userdefault objectForKey:kRequestId];
                    NSString *text = user.requestId.stringValue;
                    NSString *requestString = requestId.stringValue;
                    SINOutgoingMessage *message = [SINOutgoingMessage messageWithRecipient:text text:requestString];
                    [message addHeaderWithValue:[NSString stringWithFormat:@"%lu",MessageLike] key:@"type"];
                    [self.messageClient sendMessage:message];
                    [self requeryNotiList];
                }
                    break;
                case 1:
                {
                    //对方拒绝了你
                }
                    break;
                case 2:
                {
                    //双方 like
                    NSNumber *requestId = [userdefault objectForKey:kRequestId];
                    NSString *requestString = requestId.stringValue;
                    NSString *text = user.requestId.stringValue;

                    SINOutgoingMessage *message = [SINOutgoingMessage messageWithRecipient:text text:requestString];
                    [message addHeaderWithValue:[NSString stringWithFormat:@"%lu",MessageMatch] key:@"type"];
//                    [self refreshNotiArray:user];
                    [self.rightTableView reloadData];
                    [self.messageClient sendMessage:message];
                     [self requeryNotiList];
                }
                    break;
                case 3:
                {
                    //你拒绝了对方
                }
                    break;
                default:
                    break;
            }
            [self.feedDataArray removeObject:user];
            if (self.feedDataArray.count <= 0) {
                [self setRequestViewAndAnimation];
            }
            [self.mainTableView reloadData];
        }
    } error:^(NSError *err) {
        NSLog(@"do like error = %@",err.localizedDescription);
    }];
}

//- (void)refreshNotiArray:(UserModel *)user
//{
//    BOOL isRepeat = NO;
//    user.notiString = @"match";
//    for (UserModel *notiUser in self.notiArray) {
//        if (user.userId.intValue == notiUser.userId.intValue) {
//            isRepeat = YES;
//            notiUser.notiString = @"match";
//        }
//    }
//    if (!isRepeat) {
//        [self.notiArray addObject:user];
//    }
//    
//}

#pragma mark - sinch client delegate

- (void)clientDidStart:(id<SINClient>)client
{
    NSLog(@"didstart");
}

- (void)clientDidFail:(id<SINClient>)client error:(NSError *)error
{
    NSLog(@"client Failed with Error = %@",error.localizedDescription);
}

- (void)initViews
{
    self.mainScrollView.delegate = self;
    self.tipsView = [[UITextView alloc] initWithFrame:CGRectMake(20, self.view.bounds.size.height - 44 - 130, windowWidth() - 40, 80)];
    self.tipsView.textAlignment = NSTextAlignmentCenter;
    self.tipsView.userInteractionEnabled = NO;
    self.tipsView.text = @"We'll show you people nearby and ready to meet during 60 minutes.";
    self.tipsView.font =  fontWithSize(18);
//    self.tipsView.font = [UIFont systemFontOfSize:25];
    self.tipsView.textColor = [UIColor whiteColor];
    self.tipsView.backgroundColor = [UIColor clearColor];
    
    NSMutableAttributedString * mutStr = [self.tipsView.attributedText mutableCopy];
    //颜色
    [mutStr addAttribute:NSForegroundColorAttributeName value:colorWithHexString(@"#e7e02d") range:NSMakeRange(53, 11)];
    //字体
    [mutStr addAttribute:NSFontAttributeName value:fontWithSize(24) range:NSMakeRange(53, 11)];
    self.tipsView.attributedText = [mutStr copy];
    
    [self initRequestFeedView];
    [self.mainRequestView addSubview:self.tipsView];
    [self initSettingView];
    NSNumber * requesting = [userdefault objectForKey:kIsRequesting];
    if (requesting.boolValue) {
        self.isRequesting = YES;
    }else{
        self.isRequesting = NO;
    }
    
    if (self.isRequesting) {
        
        [self initCommunicateView];
        [self resetCurrentView];
        [self.mainRequestView removeFromSuperview];
        [self setRequestViewAndAnimation];
        [self getFeedList];
        self.isRequesting = YES;
        NSNumber *isRequest = [NSNumber numberWithBool:self.isRequesting];
        [userdefault setObject:isRequest forKey:kIsRequesting];
        [userdefault synchronize];
        self.requestTimer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(timerFireMethod:) userInfo:nil repeats:YES];
        [self requeryNotiList];
        [self initIMSDKWithRequestId:[userdefault objectForKey:kRequestId]];
    }else{
        [self initRequestView];
    }

}

- (void)initRequestView
{

}

- (void)initRequestFeedView
{
    self.mainTableView = [[UITableView alloc] initWithFrame:CGRectMake(windowWidth(), 0, windowWidth(), windowHeight() - 44 - 20)];
    self.mainTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.mainTableView.delegate = self;
    self.mainTableView.dataSource = self;
    self.mainTableView.backgroundColor = colorWithHexString(@"#181818");
    [self.mainTableView registerClass:[RequestFeedCell class] forCellReuseIdentifier:@"Feed"];
    [self.mainScrollView addSubview:self.mainTableView];
    self.fView = [[FeedFootView alloc] initWithFrame:CGRectMake(0, 0, windowWidth(), 188)];
    [self.fView.deleteBtn addTarget:self action:@selector(showDeleteDialog) forControlEvents:UIControlEventTouchUpInside];
//    self.mainTableView.backgroundColor = [UIColor yellowColor];
    if (self.mainRequestView == nil) {
        self.mainRequestView = [[UIView alloc] initWithFrame:CGRectMake(windowWidth(), 0, windowWidth(), windowHeight() - 44 - 20)];
        self.mainRequestView.backgroundColor = colorWithHexString(@"#181818");
        [self.mainScrollView addSubview: self.mainRequestView];
        [self.mainScrollView bringSubviewToFront:self.mainRequestView];
        self.uploadImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, windowWidth()/ 2, windowWidth() / 2)];
        self.uploadImageView.contentMode = UIViewContentModeScaleAspectFill;
        self.uploadImageView.userInteractionEnabled = YES;
        [self.uploadImageView.layer setCornerRadius:self.uploadImageView.frame.size.width /2];
        [self.uploadImageView.layer setBorderWidth:0];
        self.uploadImageView.layer.masksToBounds = YES;
        self.uploadImageView.backgroundColor = [UIColor clearColor];
       
        [self.mainRequestView addSubview:self.uploadImageView];
        self.uploadImageView.center = CGPointMake(self.mainRequestView.frame.size.width /2, self.mainRequestView.frame.size.height / 2 - 100);
        
        NSData *imageData = [userdefault objectForKey:kHeaderImage];
        if (imageData) {
            UIImage *image = [UIImage imageWithData:imageData];
            self.uploadImageView.image = image;
            self.uploadData = imageData;
        }
        
        UIView *uploadBackView = [[UIView alloc] initWithFrame:self.uploadImageView.frame];
        [uploadBackView.layer setCornerRadius:self.uploadImageView.layer.cornerRadius];
        uploadBackView.layer.masksToBounds = YES;
        uploadBackView.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.1];
        [self.mainRequestView insertSubview:uploadBackView belowSubview:self.uploadImageView];
        UIImageView *plusView =  [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 27, 27)];
        plusView.image = [UIImage imageNamed:@"newrequest_ic_add"];
        plusView.center = CGPointMake(uploadBackView.frame.size.width / 2, uploadBackView.frame.size.height / 2 - 13 - 8);
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, uploadBackView.frame.size.width / 2, 50)];
        label.text = LocalizedString(@"add_selfie", nil);
        label.font = fontWithSize(14);
        label.adjustsFontSizeToFitWidth = YES;
        label.textColor = colorWithHexString(@"#fa5b3a");
        label.textAlignment = NSTextAlignmentCenter;
        label.font = [UIFont fontWithName:@"Myriad Pro-Regular" size:18];
        label.center = CGPointMake(uploadBackView.frame.size.width / 2, uploadBackView.frame.size.height / 2 + 18);
        [uploadBackView addSubview:plusView];
        [uploadBackView addSubview:label];
        
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(selectPhoto:)];
        [self.uploadImageView addGestureRecognizer:tap];
        
        self.submitButton = [UIButton buttonWithType:UIButtonTypeSystem];
        self.submitButton.frame = CGRectMake(0, 0, windowWidth() - 50, 50);
        self.submitButton.center = CGPointMake(self.uploadImageView.center.x, self.mainRequestView.frame.size.height - 50);
        self.submitButton.titleLabel.font = [UIFont systemFontOfSize:20];
        [self.submitButton setTitleColor:colorWithHexString(@"#fa5b3a") forState:UIControlStateNormal];
        self.submitButton.layer.borderColor = colorWithHexString(@"#fa5b3a").CGColor;
        self.submitButton.layer.borderWidth = 1;
        [self.submitButton setTitle:@"Submit" forState:UIControlStateNormal];
        [self.submitButton addTarget:self action:@selector(submitPhoto:) forControlEvents:UIControlEventTouchUpInside];
        [self.mainRequestView addSubview:self.submitButton];
      [RACObserve(self.uploadImageView, image) subscribeNext:^(id x) {
          UIImage *image = (UIImage *)x;
          if (image) {
              self.tipsView.hidden = YES;
              self.submitButton.hidden = NO;
          }else{
              self.tipsView.hidden = NO;
              self.submitButton.hidden = YES;
          }
      }];
    }
    if (!self.requestLoadingView) {
        self.requestLoadingView = [[UIView alloc] initWithFrame:CGRectMake(windowWidth(), 0, windowWidth(), windowHeight() - 44 - 20)];
        self.requestLoadingView.backgroundColor = colorWithHexString(@"#181818");
        self.fDv = [[FeedDeleteView alloc] initWithFrame:CGRectMake(0, windowHeight() - setH(137) - 44 - 20, windowWidth(), setH(137))];
        [self.fDv.deleteBtn addTarget:self action:@selector(showDeleteDialog) forControlEvents:UIControlEventTouchUpInside];
        if (!self.animationView) {
            self.animationView = [[LoadingAnimationView alloc] initWithFrame:CGRectMake(0, 0, windowWidth(), windowWidth())];
        }
        [self.requestLoadingView addSubview:self.animationView];
        
        self.uploadLoadingView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, windowWidth()/ 2, windowWidth() / 2)];
        self.uploadLoadingView.contentMode = UIViewContentModeScaleAspectFill;
        self.uploadLoadingView.userInteractionEnabled = YES;
        [self.uploadLoadingView.layer setCornerRadius:self.uploadImageView.frame.size.width /2];
        [self.uploadLoadingView.layer setBorderWidth:0];
        self.uploadLoadingView.layer.masksToBounds = YES;
        self.uploadLoadingView.backgroundColor = [UIColor clearColor];
        self.uploadLoadingView.image = self.uploadImageView.image;
        self.uploadLoadingView.center = CGPointMake(self.mainRequestView.frame.size.width /2, self.mainRequestView.frame.size.height / 2 - 100);
        self.animationView.center = self.uploadLoadingView.center;
        
        self.loadingTipsLabel = [[UILabel alloc] initWithFrame:CGRectMake(40, 0, windowWidth() - 80, 80)];
        self.loadingTipsLabel.center = CGPointMake(self.mainRequestView.frame.size.width /2, self.mainRequestView.frame.size.height / 2 + 20);
        self.loadingTipsLabel.numberOfLines = 0;
        self.loadingTipsLabel.textAlignment = NSTextAlignmentCenter;
        self.loadingTipsLabel.font = fontWithSize(14);
        self.loadingTipsLabel.textColor = [UIColor whiteColor];
        self.loadingTipsLabel.text = LocalizedString(@"looking_people", nil);
        [self.requestLoadingView addSubview:self.loadingTipsLabel];
        
        [self.requestLoadingView addSubview:self.uploadLoadingView];
        [self.requestLoadingView addSubview:self.fDv];
    }
}

- (void)deleteDatingRequest:(UIButton *)btn
{
    [self showDeleteDialog];
}

- (void)showDeleteDialog
{
    if (self.isRequesting) {
        self.deleteAlert = [[UIAlertView alloc] initWithTitle:@"Tips" message:@"删删删删" delegate: self cancelButtonTitle:@"删除" otherButtonTitles:@"取消", nil];
        [self.deleteAlert show];
    }else{
        
    }
}

- (void)deleteRequest
{
    NetworkingManager *manager = [NetworkingManager manager];
    NSNumber *requestId = [userdefault objectForKey:kRequestId];
    [manager deleteDatingRequestWithRequestId:requestId success:^(NSURLSessionDataTask *task, id responseObject) {
        NSLog(@"Delete!!!!!!");
        NSDictionary *result = (NSDictionary *)responseObject;
        NSNumber *stateNumber = [result objectForKey:@"state"];
        if (stateNumber.intValue == 10000) {
            NSLog(@"deleteSuccess");
            self.isRequesting = NO;
            [userdefault setObject:[NSNumber numberWithBool:self.isRequesting] forKey:kIsRequesting];
            [userdefault synchronize];
            [self leaveAllCommunications];
            [self resetUploadView];
            [self.requestTimer invalidate];
            _timerStart = YES;
            NSArray *array = [[NSArray alloc] init];
            [userdefault setObject:array forKey:kCommArray];
            [CommonUtil defaultUtil].commArray = [array copy];
            [userdefault synchronize];
//            [self.sinClient stop];
//            [self.sinClient terminate];
        }else{
            NSLog(@"delete Failed = %d",stateNumber.intValue);
        }
    } error:^(NSError *err) {
        NSLog(@"error = %@",err.localizedDescription);
    }];
}

- (void)leaveAllCommunications
{
    for (UserModel *user in self.communicationArray) {
        NSNumber *gender = [userdefault objectForKey:kGender];
        NSString *string = nil;
        if (gender.intValue == 0) {
            string = LocalizedString(@"left_conversation_female",nil);
        }
        if (gender.intValue == 1) {
            string = LocalizedString(@"left_conversation_male",nil);
        }
        NSLog(@"string = %@",string);
        [userdefault setObject:[NSArray new] forKey:user.requestId.stringValue];
        SINOutgoingMessage *message = [SINOutgoingMessage messageWithRecipient:[NSString stringWithFormat:@"%d",user.requestId.intValue] text:string];
        [message addHeaderWithValue:[NSString stringWithFormat:@"%lu",MessageLeave] key:@"type"];
        [self.messageClient sendMessage:message];
    }
}

- (void)resetUploadView
{
    self.navigationItem.rightBarButtonItems = @[fixBarButtonItem()];
    [self.feedDataArray removeAllObjects];
    [self.mainTableView reloadData];
    self.mainTableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    [self.notiArray removeAllObjects];
//    self.communicationArray = nil;
    [self.communicationArray removeAllObjects];
    [self.rightTableView reloadData];
    [self.requestLoadingView removeFromSuperview];
    [self.mainScrollView addSubview:self.mainRequestView];
    [self.rightView removeFromSuperview];
    [self.fDv.timeLabel setText:@"     minutes left"];
    self.mainScrollView.contentSize = CGSizeMake(2 * windowWidth(), 0);
    self.mainScrollView.contentOffset = CGPointMake(windowWidth(), - (44 + 20));
}

- (void)submitPhoto:(UIButton *)btn
{
#warning todo
    //submit Successed
    NSNumber *gender = [userdefault objectForKey:kGender];
//    NSString *data = [userdefault objectForKey:kReceiptData];
    NSNumber *isfIrstIap = [userdefault objectForKey:kIsFirstIap];
    BOOL isfirst = isfIrstIap.boolValue;
    NSNumber *fee = [CommonUtil defaultUtil].isFee;
    __weak RequestViewController *weakSelf = self;
    if (gender.intValue == 1 && fee.boolValue == 0) {
        if (isfirst) {
            if (!self.adView) {
                self.adView = [[AdView alloc] initWithFrame:CGRectMake(windowWidth(), 0, windowWidth(), windowHeight() - 44 - 20)];
            }
            
            self.adView.buy = ^(void){
                [weakSelf buyWithProductName:@"1month_vip"];
            };
            [self.mainScrollView addSubview:self.adView];
        }else{
            if (!self.productView) {
                self.productView = [[ProductView alloc] initWithFrame:CGRectMake(windowWidth(), 0, windowWidth(), windowHeight() - 44 - 20)];
                self.productView.buySevenDay = ^(void){
                    NSLog(@"Seven Day");
                    [weakSelf buyWithProductName:@"7day_vip"];
                };
                
                self.productView.buyOneMonth = ^(void){
                    NSLog(@"One Montn");
                    [weakSelf buyWithProductName:@"1month_vip"];
                };
                self.productView.buySixMonth = ^(void){
                    [weakSelf buyWithProductName:@"6month_vip"];
                };
            }
            [self.mainScrollView addSubview:self.productView];
        }
//        else if(gender.intValue == 1 && fee.boolValue == 0 ){
//            
//        }
    }else{
        self.isRequesting = YES;
        [self uploadImage];
    }
//    [self testData];
//    DetailInfoViewController *detailInfoVC = [[DetailInfoViewController alloc] init];
//    [self presentViewController:detailInfoVC animated:YES completion:nil];
}

- (void)buyWithProductName:(NSString *)productName
{
    _submitFlag = YES;
    StoreObserver *observer = [StoreObserver sharedInstance];
    StoreManager *manager = [StoreManager sharedInstance];
    [observer hasPurchasedProducts];
    if (manager.availableProducts.count > 0) {
        showMBProgressHUD(nil,YES);
        NSLog(@"manager.availableProducts = %@",manager.availableProducts);
        for (SKProduct * product in manager.availableProducts) {
            //        if ([product.productIdentifier isEqualToString:@"Oldphoto_1960"]) {
            //            [observer buy:product];
            //        }
            if ([product.productIdentifier isEqualToString:productName]) {
                [observer buy:product];
            }
            NSLog(@" product = %@",product.productIdentifier);
        }
    }
   
    NSLog(@"buy");

}

- (void)reportPhotoWithUser:(UserModel *)user
{
    NetworkingManager *manager = [NetworkingManager manager];
    NSNumber *requestId = [userdefault objectForKey:kRequestId];
    [manager reportUserFromRequestId:requestId toUserId:user.userId success:^(NSURLSessionDataTask *task, id responseObject) {
        NSDictionary *result = (NSDictionary *)responseObject;
        [self.feedDataArray removeObject:user];
        if (self.feedDataArray.count <= 0) {
            [self setRequestViewAndAnimation];
        }
        [self.mainTableView reloadData];
        NSLog(@"report result = %@",result);
    } error:^(NSError *err) {
        
    }];
}

- (void)uploadImage
{
    self.loadingTipsLabel.text = LocalizedString(@"looking_people", nil);
    if([CLLocationManager authorizationStatus]==kCLAuthorizationStatusDenied){
        [self.locationGuideView removeFromSuperview];
        if (!self.locationGuideView) {
            self.locationGuideView = [[LocationGuideView alloc] initWithFrame:self.view.bounds];
        }
        UIWindow *window = [[[UIApplication sharedApplication] delegate] window];
        [window addSubview:self.locationGuideView];
            self.isRequesting = NO;
        return;
    }
    if (![userdefault objectForKey:kLongitude]) {
        [[[UIAlertView alloc] initWithTitle:LocalizedString(@"oops", nil) message:LocalizedString(@"tips_no_location", nil) delegate:nil cancelButtonTitle:LocalizedString(@"ok", nil) otherButtonTitles:nil, nil]show];
        self.isRequesting = NO;
        return;
    }

    self.submitButton.hidden = YES;
    NetworkingManager *manage = [NetworkingManager manager];
    if (!self.progressView) {
        self.progressView = [[THCircularProgressView alloc] initWithCenter:self.uploadImageView.center radius:self.uploadImageView.frame.size.width / 2 + 12 lineWidth:6 progressMode:THProgressModeFill progressColor:[UIColor yellowColor] progressBackgroundMode:THProgressBackgroundModeCircle progressBackgroundColor:colorWithHexString(@"#181818") percentage:0];
        self.submitButton.hidden = YES;
        self.progressView.clockwise = YES;
    }
    [self.mainRequestView insertSubview:self.progressView belowSubview:self.uploadImageView];
    self.uploadLoadingView.image = self.uploadImageView.image;
    [manage uploadImageWithData:self.uploadData progress:^(NSProgress *progress) {
        dispatch_async(dispatch_get_main_queue(), ^{
                self.progressView.percentage = progress.fractionCompleted;
        });
      NSLog(@"upload at %f", progress.fractionCompleted);
    } success:^(NSURLSessionDataTask *task, id responseObject) {
        NSDictionary *result = (NSDictionary *)responseObject;
        NSLog(@"Upload res = %@",(NSDictionary *)responseObject);
        NSNumber *stateCode = [result objectForKey:@"state"];
        if (stateCode.intValue == 10000 || stateCode
            .intValue == 10004) {
            
            NSNumber *requestId = [result objectForKey:@"requestid"];
            NSString *urlSmall = [result objectForKey:@"url_small"];
            NSString *urlBig = [result objectForKey:@"url_big"];
            NSNumber *beginTime = [result objectForKey:@"b_time"];
            NSNumber *endTime = [result objectForKey:@"e_time"];
            [userdefault setObject:requestId forKey:kRequestId];
            [userdefault setObject:urlSmall forKey:kHeaderViewSmall];
            [userdefault setObject:urlBig forKey:kHeaderViewBig];
            [userdefault setObject:beginTime forKey:kBeginTime];
            NSLog(@"eeeeeeeend time = %ld",endTime.integerValue);
            [userdefault setObject:endTime forKey:kEndTime];
            [userdefault synchronize];
            [self initIMSDKWithRequestId:requestId];
            [self resetCurrentView];
            [self.mainRequestView removeFromSuperview];
            [self setRequestViewAndAnimation];
            [self getFeedList];
            self.isRequesting = YES;
            NSNumber *isRequest = [NSNumber numberWithBool:self.isRequesting];
            [userdefault setObject:isRequest forKey:kIsRequesting];
            [userdefault synchronize];
            self.requestTimer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(timerFireMethod:) userInfo:nil repeats:YES];
        }else if (stateCode.intValue == 20000){
            NSLog(@"server ERROR");
            self.submitButton.hidden = NO;
            [self.progressView removeFromSuperview];
            self.progressView.percentage = 0;
        }
    } error:^(NSError *e) {
        self.submitButton.hidden = NO;
        [self.progressView removeFromSuperview];
        self.progressView.percentage = 0;
        NSLog(@"error = %@",e.localizedDescription);
    }];
}

- (void)setRequestViewAndAnimation
{
    NSLog(@"setRequestViewAndAnimation");
    [self.mainScrollView addSubview:self.requestLoadingView];
    [self.animationView removeFromSuperview];
    [self.requestLoadingView addSubview:self.animationView];
    [self.requestLoadingView sendSubviewToBack:self.animationView];
    [self.animationView resume];
}

- (void)getFeedList
{
    NetworkingManager *manage = [NetworkingManager manager];
    [manage getDatingListSuccess:^(NSURLSessionDataTask *task, id responseObject) {
        NSDictionary *result = (NSDictionary *)responseObject;
        NSLog(@"getDatingList result = %@",(NSDictionary *)responseObject);
        NSNumber *stateNumber = [result objectForKey:@"state"];
        if (stateNumber.intValue == 10000 ) {
            NSLog(@"getDatingList Success");
            [self.feedDataArray removeAllObjects];
            NSArray *userArray = [result objectForKey:@"list"];
            for (NSDictionary *userDic in userArray) {
                UserModel *user = [[UserModel alloc] init];
                user.userId = [userDic objectForKey:@"userid"];
                user.beginTime = [userDic objectForKey:@"b_time"];
                user.endTime = [userDic objectForKey:@"e_time"];
                user.lon = [userDic objectForKey:@"lon"];
                user.lat = [userDic objectForKey:@"lat"];
                user.gender = [userDic objectForKey:@"gender"];
//                user.dateTime = [userDic objectForKey:@"date_time"];
                user.requestId = [userDic objectForKey:@"requestid"];
                user.status = [userDic objectForKey:@"status"];
                user.headViewUrlString_L = [userDic objectForKey:@"url_big"];
                user.headViewUrlString_S = [userDic objectForKey:@"url_small"];
                if (user.status.intValue == 3) {
                    user.likeTag = YES;
                }
                [self.feedDataArray addObject:user];
            }
            if (self.feedDataArray.count > 0) {
                self.mainTableView.tableFooterView = self.fView;
                [self.requestLoadingView removeFromSuperview];
            }else{
                self.mainTableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
                if (self.requestLoadingView.superview != nil) {
                    [self setRequestViewAndAnimation];
                }
            }
            [self.mainTableView reloadData];
            [self.progressView removeFromSuperview];
            self.progressView.percentage = 0;
            self.submitButton.hidden = NO;
        }else{
            [self.feedDataArray removeAllObjects];
            self.mainTableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
            if (self.requestLoadingView.superview != nil) {
                [self setRequestViewAndAnimation];
            }
            [self.mainTableView reloadData];
            [self.progressView removeFromSuperview];
            self.progressView.percentage = 0;
            self.submitButton.hidden = NO;

        }
        
    } error:^(NSError *e) {
        self.submitButton.hidden = NO;
        [self.progressView removeFromSuperview];
        self.progressView.percentage = 0;
        NSLog(@"getDatingList Error = %@",e.localizedDescription);
    }];
}

- (void)resetCurrentView{
    NSLog(@"resetCurrentView");
//    dispatch_async(dispatch_get_main_queue(), ^{
        [self initCommunicateView];
//    });
}

- (void)initSettingView
{
    self.leftTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, windowWidth(), windowHeight() - 44 - 20)];
    self.leftTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.leftTableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    if ([self.leftTableView respondsToSelector:@selector(setSeparatorInset:)]) {
        [self.leftTableView setSeparatorInset:UIEdgeInsetsMake(0, -10, 0, 0)];
    }
    self.leftTableView.backgroundColor = colorWithHexString(@"#181818");
//    self.leftTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
//    self.leftTableView.backgroundColor = [UIColor greenColor];
    [self.mainScrollView addSubview:self.leftTableView];
    self.mainScrollView.contentSize = CGSizeMake(2 * windowWidth(), windowHeight() - 44- 20);
    self.mainScrollView.pagingEnabled = YES;
    self.mainScrollView.alwaysBounceHorizontal = NO;
    self.mainScrollView.alwaysBounceVertical = NO;
    self.mainScrollView.bounces = NO;
    self.mainScrollView.contentOffset = CGPointMake(windowWidth(), 0);
    if (!self.settingArray) {
        self.settingArray = [[NSMutableArray alloc] initWithObjects:@"Restore",@"Feedback",@"Terms of use", nil];
        self.settingIconArray = [[NSArray alloc] initWithObjects:[UIImage imageNamed:@"set_ic_restore"],[UIImage imageNamed:@"set_ic_feedback"],[UIImage imageNamed:@"set_ic_terms"], nil];
        self.leftTableView.delegate = self;
        self.leftTableView.dataSource = self;
        self.leftTableView.backgroundColor = colorWithHexString(@"#181818");
    }
}

- (void)initCommunicateView
{
    if (self.rightItem) {
        self.navigationItem.rightBarButtonItems = @[fixBarButtonItem(),self.rightItem];
    }
    [self.rightView removeFromSuperview];
    if (self.rightView == nil) {
        self.rightView = [[UIView alloc] initWithFrame:CGRectMake(windowWidth() * 2, 0, windowWidth(), windowHeight() - 44 - 20)];
        self.rightView.backgroundColor = colorWithHexString(@"#181818");
    }
    [self.mainScrollView addSubview:self.rightView];
    [self.rightTableView removeFromSuperview];
    if (self.rightTableView == nil) {
        self.rightTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 44, windowWidth(), windowHeight() - 44 - 20 - 44)];
        self.rightTableView.backgroundColor = colorWithHexString(@"#181818");
        self.rightTableView.delegate = self;
        self.rightTableView.dataSource = self;
        self.rightTableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
        self.rightTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    }
    [self.rightView addSubview: self.rightTableView];
    self.mainScrollView.contentSize = CGSizeMake(3 * windowWidth(), 0);
//    self.mainScrollView.contentOffset = CGPointMake(windowWidth(), 0);
    [self.notiBtn removeFromSuperview];
    [self.commBtn removeFromSuperview];
    self.notiBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.notiBtn setImage:[UIImage imageNamed:@"bt_notice_nor"] forState:UIControlStateNormal];
    [self.notiBtn setImage:[UIImage imageNamed:@"bt_notice_pre"] forState:UIControlStateSelected];
    self.commBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.commBtn setImage:[UIImage imageNamed:@"bt_chat_nor"] forState:UIControlStateNormal];
    [self.commBtn setImage:[UIImage imageNamed:@"bt_chat_pre"] forState:UIControlStateSelected];
    [self.notiBtn setFrame:CGRectMake((windowWidth() - 215)/2, 6, 107, 28)];
    [self.commBtn setFrame:CGRectMake((windowWidth() - 215)/2 + 107, 6, 107, 28)];
    [self.rightView addSubview:self.notiBtn];
    [self.rightView addSubview:self.commBtn];
    [self.notiBtn addTarget:self action:@selector(notiBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
    [self.commBtn addTarget:self action:@selector(commBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
    self.notiBtn.selected = YES;
    
//     self.rightTableView.editing = NO;
//    [self.segment removeFromSuperview];
//    self.segment = [[UISegmentedControl alloc] initWithItems:@[@"Notification",@"Communication"]];
//    self.segment.frame = CGRectMake((windowWidth() - 200) / 2, 10, 200, 20);
//    self.segment.selectedSegmentIndex = 0;
//    [self.segment addTarget:self action:@selector(segmentOnClicked:) forControlEvents:UIControlEventValueChanged];
//    [self.rightView addSubview:self.segment];
    self.rightDataArray = self.notiArray;
}

- (void)notiBtnClicked:(UIButton *)btn
{
//    self.rightTableView.editing = NO;
    btn.selected = YES;
    self.commBtn.selected = NO;
    self.rightDataArray = self.notiArray;
    [self.rightTableView reloadData];
    
}

- (void)commBtnClicked:(UIButton *)btn
{
//    self.rightTableView.editing = YES;
    btn.selected = YES;
    self.notiBtn.selected = NO;
    self.rightDataArray = self.communicationArray;
    [self.rightTableView reloadData];
}

- (void)testData
{
    UserModel *testUser = [[UserModel alloc] init];
    [testUser getTestModel];
    self.isRequesting = YES;
    NSNumber *isRequest = [NSNumber numberWithBool:self.isRequesting];
    [userdefault setObject:testUser.headViewUrlString_L forKey:kHeaderViewBig];
    [userdefault setObject:testUser.headViewUrlString_S forKey:kHeaderViewSmall];
    [userdefault setObject:isRequest forKey:kIsRequesting];
    [self.mainRequestView removeFromSuperview];
    [self.feedDataArray addObject:testUser];
    [self.mainTableView reloadData];
}

- (void)segmentOnClicked:(UISegmentedControl *)seg
{
    switch (seg.selectedSegmentIndex) {
        case 0:
            //通知
        {
            self.rightDataArray = self.notiArray;
        }
            break;
        case 1:
            //聊天
        {
            self.rightDataArray = self.communicationArray;
        }
            break;
        default:
            break;
    }
    [self.rightTableView reloadData];
}

- (void)viewWillAppear:(BOOL)animated
{
    [self.animationView resume];
    [self.rightTableView reloadData];
    [self.sinClient setPushNotificationDisplayName:@"!"];
    self.settingBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.settingBtn setFrame: CGRectMake(0, 0, 44, 44)];
    [self.settingBtn setImage:[UIImage imageNamed:@"title_ic_setting_nor"] forState:UIControlStateNormal];
    [self.settingBtn setImage:[UIImage imageNamed:@"title_ic_setting_pre"] forState:UIControlStateHighlighted];
    [self.settingBtn addTarget:self action:@selector(intentToSettingVC) forControlEvents:UIControlEventTouchUpInside];
    
    self.feedBtnLeft = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.feedBtnLeft setFrame:CGRectMake(0, 0, 44, 44)];
    [self.feedBtnLeft setImage:[UIImage imageNamed:@"title_ic_wink_nor"] forState:UIControlStateNormal];
    [self.feedBtnLeft setImage:[UIImage imageNamed:@"title_ic_wink_pre"] forState:UIControlStateHighlighted];
    [self.feedBtnLeft addTarget:self action:@selector(intentToFeedVC) forControlEvents:UIControlEventTouchUpInside];
    self.feedBtnLeft.alpha = 0;
    self.feedBtnLeft.hidden = YES;
    UIView *leftview = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 44, 44)];
    [leftview addSubview:self.settingBtn];
    [leftview addSubview:self.feedBtnLeft];
    
    
    self.notiTitleBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.notiTitleBtn setFrame:CGRectMake(0, 0, 44, 44)];
    [self.notiTitleBtn setImage:[UIImage imageNamed:@"title_ic_message_nor"] forState:UIControlStateNormal];
    [self.notiTitleBtn setImage:[UIImage imageNamed:@"title_ic_message_pre"] forState:UIControlStateHighlighted];
    [self.notiTitleBtn addTarget:self action:@selector(intentToNotiVC) forControlEvents:UIControlEventTouchUpInside];
    self.tips = [[UIImageView alloc] initWithFrame:CGRectMake(44-16, 16, 5, 5)];
    self.tips.image = [UIImage imageNamed:@"tips"];
    [self.notiTitleBtn addSubview:self.tips];
    self.tips.hidden = YES;
    
    self.feedBtnRight = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.feedBtnRight setFrame:CGRectMake(0, 0, 44, 44)];
    [self.feedBtnRight setImage:[UIImage imageNamed:@"title_ic_wink_nor"] forState:UIControlStateNormal];
    [self.feedBtnRight setImage:[UIImage imageNamed:@"title_ic_wink_pre"] forState:UIControlStateHighlighted];
    [self.feedBtnRight addTarget:self action:@selector(intentToFeedVC) forControlEvents:UIControlEventTouchUpInside];
    UIView *rightView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 44, 44)];
    [rightView addSubview:self.feedBtnRight];
    [rightView addSubview:self.notiTitleBtn];
    
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc] initWithCustomView:leftview];
    self.navigationItem.leftBarButtonItems = @[fixBarButtonItem(),leftItem];
    self.rightItem = [[UIBarButtonItem alloc] initWithCustomView:rightView];
    if (self.isRequesting) {
        self.navigationItem.rightBarButtonItems = @[fixBarButtonItem(),self.rightItem];
    }

    UIView *titleView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 200, 44)];
    
    self.winkLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 200, 44)];
    self.winkLabel.text = @"Wink";
    self.winkLabel.textColor = colorWithHexString(@"#ffffff");
    self.winkLabel.font = fontWithSize(23);
    self.winkLabel.textAlignment = NSTextAlignmentCenter;
    self.messageLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 200, 44)];
    self.messageLabel.text = LocalizedString(@"message_title", nil);
    self.messageLabel.textColor = colorWithHexString(@"#ffffff");
    self.messageLabel.font = fontWithSize(23);
    self.messageLabel.textAlignment = NSTextAlignmentCenter;
    self.settingLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 200, 44)];
    self.settingLabel.text = LocalizedString(@"setting_title", nil);
    self.settingLabel.textColor = colorWithHexString(@"#ffffff");
    self.settingLabel.font = fontWithSize(23);
    self.settingLabel.textAlignment = NSTextAlignmentCenter;
    [titleView addSubview:self.messageLabel];
    [titleView addSubview:self.settingLabel];
    [titleView addSubview:self.winkLabel];
    
    self.navigationItem.titleView = titleView;
    
    
    
}

- (void)intentToFeedVC
{
    [UIView animateWithDuration:0.3 animations:^{
        
        [self.mainScrollView setContentOffset:CGPointMake(windowWidth(), -(44 + 20)) animated:YES];
        
    }];
}

- (void)intentToSettingVC
{
    [UIView animateWithDuration:0.3 animations:^{

        [self.mainScrollView setContentOffset:CGPointMake(0, -(44 + 20)) animated:YES];
        
    }];
}

- (void)intentToNotiVC
{
    [UIView animateWithDuration:0.3 animations:^{
        
        [self.mainScrollView setContentOffset:CGPointMake(windowWidth() * 2, -(44 + 20)) animated:YES];
        
    }];
}

#pragma mark Fetch product information

// Retrieve product information from the App Store
-(void)fetchProductInformation
{
    // Query the App Store for product information if the user is is allowed to make purchases.
    // Display an alert, otherwise.
    if([SKPaymentQueue canMakePayments])
    {
        // Load the product identifiers fron ProductIds.plist
        NSURL *plistURL = [[NSBundle mainBundle] URLForResource:@"ProductIds" withExtension:@"plist"];
        NSArray *productIds = [NSArray arrayWithContentsOfURL:plistURL];
        
        [[StoreManager sharedInstance] fetchProductInformationForIds:productIds];
    }
    else
    {
        //         Warn the user that they are not allowed to make purchases.
        NSLog(@"Purchases are disabled on this device.");
        //        [self alertWithTitle:@"Warning" message:@"Purchases are disabled on this device."];
    }
}

#pragma mark Handle product request notification

// Update the UI according to the product request notification result
- (void)handleProductRequestNotification:(NSNotification *)notification
{
    StoreManager *productRequestNotification = (StoreManager*)notification.object;
    IAPProductRequestStatus result = (IAPProductRequestStatus)productRequestNotification.status;
    
    if (result == IAPProductRequestResponse)
    {
        // Switch to the iOSProductsList view controller and display its view
        //        [self cycleFromViewController:self.currentViewController toViewController:self.productsList];
        
        // Set the data source for the Products view
        //        [self.productsList reloadUIWithData:productRequestNotification.productRequestResponse];
        NSLog(@"productRequestNotification.productRequestResponse = %@",((MyModel*)productRequestNotification.productRequestResponse.firstObject).elements);
    }
}


#pragma mark Handle purchase request notification

// Update the UI according to the purchase request notification result
-(void)handlePurchasesNotification:(NSNotification *)notification
{
    StoreObserver *purchasesNotification = (StoreObserver *)notification.object;
    IAPPurchaseNotificationStatus status = (IAPPurchaseNotificationStatus)purchasesNotification.status;
    
    switch (status)
    {
        case IAPPurchaseSucceeded:
        {
             hideMBProgressHUD();
            [self.productView removeFromSuperview];
            [CommonUtil defaultUtil].isFee = @YES;
            [userdefault setObject:@NO forKey:kIsFirstIap];
            [userdefault setObject:[CommonUtil defaultUtil].isFee forKey:kIsFee];
            [userdefault synchronize];

            self.isRequesting = YES;
            if (_submitFlag) {
                [self uploadImage];
            }
            NSLog(@"IAPPurchaseSucceeded");
        }
            break;
        case IAPPurchaseFailed:
            NSLog(@"IAPPurachaseFailed");
            hideMBProgressHUD();
            //            [self alertWithTitle:@"Purchase Status" message:purchasesNotification.message];
            break;
            // Switch to the iOSPurchasesList view controller when receiving a successful restore notification
        case IAPRestoredSucceeded:
        {
//            [CommonUtil defaultUtil].isFee = @YES;
//            [userdefault setObject:[CommonUtil defaultUtil].isFee forKey:kIsFee];
//            self.isRequesting = YES;
//            [self uploadImage];
            hideMBProgressHUD();
            NSLog(@"IAPRestoredSucceeded");
        }
            break;
        case IAPRestoredFailed:
            NSLog(@"IAPRestoredFailed");
            hideMBProgressHUD();
            //            [self alertWithTitle:@"Purchase Status" message:purchasesNotification.message];
            break;
            // Notify the user that downloading is about to start when receiving a download started notification
        case IAPDownloadStarted:
        {
            //            self.hasDownloadContent = YES;
            //            [self.view addSubview:self.statusMessage];
        }
            break;
            // Display a status message showing the download progress
        case IAPDownloadInProgress:
        {
            //            self.hasDownloadContent = YES;
            //            NSString *title = [[StoreManager sharedInstance] titleMatchingProductIdentifier:purchasesNotification.purchasedID];
            //            NSString *displayedTitle = (title.length > 0) ? title : purchasesNotification.purchasedID;
            //            self.statusMessage.text = [NSString stringWithFormat:@" Downloading %@   %.2f%%",displayedTitle, purchasesNotification.downloadProgress];
        }
            break;
            // Downloading is done, remove the status message
        case IAPDownloadSucceeded:
        {
            //            self.hasDownloadContent = NO;
            //            self.statusMessage.text = @"Download complete: 100%";
            
            // Remove the message after 2 seconds
            //            [self performSelector:@selector(hideStatusMessage) withObject:nil afterDelay:2];
        }
            break;
        default:
            break;
    }
    _submitFlag = NO;
}

-(void)canceled:(NSNotification *)notification
{

    NSLog(@"canceled");
    hideMBProgressHUD();
    NSNumber *isfirst = [userdefault objectForKey:kIsFirstIap];
     __weak RequestViewController *weakSelf = self;
    if (isfirst.boolValue) {
        if (!self.freeOneMonthView) {
            self.freeOneMonthView = [[FreeOneMonthView alloc] initWithFrame:CGRectMake(windowWidth(), 0, windowWidth(), windowHeight() )];
            self.freeOneMonthView.buyOneMonth = ^(void){
                [weakSelf buyWithProductName:@"1month_vip"];
            };
            self.freeOneMonthView.cancelBuy = ^(void){
                if ([CommonUtil defaultUtil].canShowMail) {
                    [weakSelf showRateMail];
                }
                [weakSelf.adView removeFromSuperview];
            };
        }
        [self.mainScrollView addSubview:self.freeOneMonthView];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)selectPhoto:(UITapGestureRecognizer *)tap
{
    self.actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"cancel" destructiveButtonTitle:nil otherButtonTitles:LocalizedString(@"camera", nil),LocalizedString(@"Photo Library", nil), nil];
    [self.actionSheet showInView:self.view];
    
}

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    NSLog(@"clicked : %ld", buttonIndex);
    switch (buttonIndex) {
        case 0:
        {
            if([[[UIDevice
                  currentDevice] systemVersion] floatValue]>=8.0) {
                
                self.modalPresentationStyle=UIModalPresentationOverCurrentContext;
                
            }
            [self getImageWithImagePickerType:UIImagePickerControllerSourceTypeCamera];
        }
            break;
        case 1:
        {
            [self getImageWithImagePickerType:UIImagePickerControllerSourceTypePhotoLibrary];
        }
            break;
        default:
            break;
    }
    
}

- (void)getImageWithImagePickerType:(UIImagePickerControllerSourceType)sourceType
{
    if (!self.imagePicker) {
        self.imagePicker = [[UIImagePickerController alloc] init];
        self.imagePicker.delegate = self;
    }
    self.imagePicker.sourceType = sourceType;
    [self presentViewController:self.imagePicker animated:YES completion:nil];
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [picker dismissViewControllerAnimated:YES completion:nil];
    
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info
{
    //    if (picker.sourceType == UIImagePickerControllerSourceTypeCamera) {
    
    //    }
    UIImage *image = [info objectForKey:UIImagePickerControllerOriginalImage];
    UIImage *finalImage = [[image setMaxResolution:1024.f imageOri:image.imageOrientation]compressImage];
    self.uploadData = UIImageJPEGRepresentation(finalImage, 1);
    
    [userdefault setObject:self.uploadData forKey:kHeaderImage];
    [userdefault synchronize];
    [[iCloud sharedCloud] saveAndCloseDocumentWithName:@"image.ext" withContent:self.uploadData completion:^(UIDocument *cloudDocument, NSData *documentData, NSError *error) {
        NSLog(@"error = %@",error.localizedDescription);
        if (error == nil) {
            // Code here to use the UIDocument or NSData objects which have been passed with the completion handler
        }
    }];
    self.uploadImageView.image = finalImage;
    [picker dismissViewControllerAnimated:YES completion:nil];
    
}
- (IBAction)requestMatch:(id)sender
{
    NSLog(@"Request more macth");
    [[[UIAlertView alloc] initWithTitle:@"缴费通知" message:@"通通付款, 648一个月, 不能取消, 自动续订" delegate: self cancelButtonTitle:@"不!我要买328一个月的!" otherButtonTitles:@"好的", nil] show];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView == self.deleteAlert) {
        switch (buttonIndex) {
            case 0:
            {
                //删除请求
                [self deleteRequest];
            }
                break;
            case 1:
            {
                                //取消
            }
                break;
            default:
                break;
        }
    }else if(alertView == self.reportAlert){
        switch (buttonIndex) {
            case 0:
            {
                //queding
                [self reportPhotoWithUser:self.reportUser];
            }
                break;
            case 1:
            {
                //取消
            }
                break;
            default:
                break;
        }

    }else if(alertView == self.reportUserAlert){
        switch (buttonIndex) {
            case 0:
            {
                UserModel *user = [self.communicationArray objectAtIndex:self.deleteIndex];
                
                NSNumber *gender = [userdefault objectForKey:kGender];
                NSString *string = nil;
                if (gender.intValue == 0) {
                    string = LocalizedString(@"left_conversation_female",nil);
                }
                if (gender.intValue == 1) {
                    string = LocalizedString(@"left_conversation_male",nil);
                }
                NSLog(@"string = %@",string);
                [userdefault setObject:[NSArray new] forKey:user.requestId.stringValue];
                SINOutgoingMessage *message = [SINOutgoingMessage messageWithRecipient:[NSString stringWithFormat:@"%d",user.requestId.intValue] text:string];
                [message addHeaderWithValue:[NSString stringWithFormat:@"%lu",MessageLeave] key:@"type"];
                [self.messageClient sendMessage:message];
                
                [[NetworkingManager manager] cancelMatchWithMatchId:user.commId success:^(NSURLSessionDataTask *task, id responseObject) {
                    NSLog(@"Delete matching Info Success");
                } error:^(NSError *err) {
                    
                }];
                [userdefault setObject:[NSArray new] forKey:user.requestId.stringValue];
                [userdefault synchronize];
                [self.communicationArray removeObjectAtIndex:self.deleteIndex];
                [self.rightTableView reloadData];
                [self saveMatchListData];
                [self reportUser:self.reportUser];

            }
                break;
            case 1:
            {
                //取消
            }
                break;
            default:
                break;
        }

    }else if(alertView == self.deleteTipsAlert){
        switch (buttonIndex) {
            case 0:
            {
                UserModel *user = [self.communicationArray objectAtIndex:self.deleteIndex];
                NSNumber *gender = [userdefault objectForKey:kGender];
                NSString *string = nil;
                if (gender.intValue == 0) {
                    string = LocalizedString(@"left_conversation_female",nil);
                }
                if (gender.intValue == 1) {
                    string = LocalizedString(@"left_conversation_male",nil);
                }
                NSLog(@"string = %@",string);
                [userdefault setObject:[NSArray new] forKey:user.requestId.stringValue];
                SINOutgoingMessage *message = [SINOutgoingMessage messageWithRecipient:[NSString stringWithFormat:@"%d",user.requestId.intValue] text:string];
                [message addHeaderWithValue:[NSString stringWithFormat:@"%lu",MessageLeave] key:@"type"];
                [self.messageClient sendMessage:message];
                
                [[NetworkingManager manager] cancelMatchWithMatchId:user.commId success:^(NSURLSessionDataTask *task, id responseObject) {
                    NSLog(@"Delete matching Info Success");
                } error:^(NSError *err) {
                    
                }];
                [userdefault setObject:[NSArray new] forKey:user.requestId.stringValue];
                [userdefault synchronize];
                [self.communicationArray removeObjectAtIndex:self.deleteIndex];
                [self.rightTableView reloadData];
                 [self saveMatchListData];
            }
                break;
            case 1:
            {
                //取消
            }
                break;
            default:
                break;
        }

    }else{
        
    }
    
   
}

#pragma mark - UITableView delegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView == self.leftTableView) {
        return 58;
    }else if(tableView == self.mainTableView){
        return setH(292.f);
    }else if (tableView == self.rightTableView){
        return setH(58);
    }
    return 150;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView == self.leftTableView) {
        [tableView deselectRowAtIndexPath:indexPath animated:YES];
        switch (indexPath.row) {
            case 0:
                //恢复购买
            {
                RestoreViewController *restore = [[RestoreViewController alloc] init];
                [self.navigationController pushViewController:restore animated:YES];
            }
                break;
            case 1:
                //feedback
            {
//                [self showFindBody];
                //本地语言
//                NSString *language = [[NSLocale preferredLanguages] firstObject];
                //直接发邮件
                MFMailComposeViewController *picker = [[MFMailComposeViewController alloc] init];
                if(!picker) break;
                picker.mailComposeDelegate =self;
                [picker setTitle:LocalizedString(@"feedback", nil)];
                NSString *content = [NSString stringWithFormat:@"%@%@",LocalizedString(@"feedback_content", nil),mailFooterInfo() ];
                [picker setSubject:LocalizedString(@"feedback", nil)];
                [picker setToRecipients:@[kFeedbackEmail]];
                [picker setMessageBody:content isHTML:NO];
                [self presentViewController:picker animated:YES completion:nil];
            }
                break;
            case 2:
                //使用条款
            {
                TermsViewController *terms = [[TermsViewController alloc] init];
                [self.navigationController pushViewController:terms animated:YES];
            }
                break;
            default:
                break;
        }
    }else if (tableView == self.rightTableView){
        if (self.notiBtn.selected) {
            [tableView deselectRowAtIndexPath:indexPath animated:YES];
            UserModel *user = [self.notiArray objectAtIndex:indexPath.row];
            if (user.status.intValue == 3) {
                //like
                [UIView animateWithDuration:0.3 animations:^{
                    [self.mainScrollView setContentOffset:CGPointMake(windowWidth(), -(44 + 20)) animated:YES];
                }];
                int index = -1;
                for (int i = 0; i < self.feedDataArray.count; i++) {
                    UserModel *feedUser = self.feedDataArray[i];
                    if (feedUser.requestId.intValue == user.requestId.intValue) {
                        index = i;
                        break;
                    }
                }
                if (index >= 0) {
                    [self.mainTableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:index inSection:0] atScrollPosition:UITableViewScrollPositionTop animated:YES];
                }
            }else if(user.status.intValue == 5){
                //doubleLike
                for (UserModel *commUser in self.communicationArray) {
                    if (commUser.requestId.intValue == user.requestId.intValue) {
                        CommunicationViewController *cvc = [[CommunicationViewController alloc] init];
                        cvc.userModel = commUser;
                        cvc.messageClient = self.messageClient;
                        [self.navigationController pushViewController:cvc animated:YES];
                        break;
                    }
                }
            }
            
            NSLog(@"notification");
        }else if (self.commBtn.selected){
            [tableView deselectRowAtIndexPath:indexPath animated:YES];
            NSLog(@"Communication");
            UserModel *user = [self.communicationArray objectAtIndex:indexPath.row];
            CommunicationViewController *cvc = [[CommunicationViewController alloc] init];
            cvc.userModel = user;
            cvc.messageClient = self.messageClient;
            [self.navigationController pushViewController:cvc animated:YES];
        }
    
    }

}

- (void)showRateMail
{
    //本地语言
    //                NSString *language = [[NSLocale preferredLanguages] firstObject];
    //直接发邮件
    MFMailComposeViewController *picker = [[MFMailComposeViewController alloc] init];
    if(!picker){
        return;
    }
    picker.mailComposeDelegate =self;
    [picker setTitle:LocalizedString(@"feedback_trail", nil)];
    NSString *content = [NSString stringWithFormat:@"%@%@",LocalizedString(@"feedback_vip", nil),mailFooterInfo() ];
    [picker setSubject:LocalizedString(@"feedback_trail", nil)];
    [picker setToRecipients:@[kFeedbackEmail]];
    [picker setMessageBody:content isHTML:NO];
    [self presentViewController:picker animated:YES completion:nil];
}

- (void)showFindBody
{
    MFMailComposeViewController *picker = [[MFMailComposeViewController alloc] init];
    if(!picker){
        return;
    }
    picker.mailComposeDelegate =self;
    [picker setTitle:LocalizedString(@"feedback_nobody", nil)];
    NSString *content = [NSString stringWithFormat:@"%@%@",LocalizedString(@"feedback_nobody_content", nil),mailFooterInfo() ];
    [picker setSubject:LocalizedString(@"feedback_nobody", nil)];
    [picker setToRecipients:@[kFeedbackEmail]];
    [picker setMessageBody:content isHTML:NO];
    [self presentViewController:picker animated:YES completion:nil];

}

//
//- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
//{
//    if (tableView == self.mainTableView) {
//        if (self.feedDataArray.count >0) {
//            return 162;
//        }
//        
//    }else{
//        return 0;
//    }
//    return 0;
//}

//- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
//{
//    return  self.fView;
//}

#pragma mark - UITableView DataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView == self.leftTableView) {
        return self.settingArray.count;
    }else if (tableView == self.rightTableView){
        return self.rightDataArray.count;
    }else if(tableView == self.mainTableView){
        if (self.feedDataArray.count >0) {
            
        }else{
            [self.fView removeFromSuperview];
//            self.mainTableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
        }
        return self.feedDataArray.count;
    }
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView == self.leftTableView) {
        static NSString *settingCellIde = @"settingIde";
        SettingTableCell *cell = [tableView dequeueReusableCellWithIdentifier:settingCellIde];
        if (!cell) {
            cell = [[SettingTableCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:settingCellIde];
        }
        cell.backgroundColor = colorWithHexString(@"#181818");
        cell.detailLabel.textColor = colorWithHexString(@"#909090");
        cell.detailLabel.text = [self.settingArray objectAtIndex:indexPath.row];
        cell.imageView.image = [self.settingIconArray objectAtIndex:indexPath.row];
        UIImageView *arrView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 25, 25)];
        arrView.image = [UIImage imageNamed:@"set_ic_next"];
        
        cell.accessoryView = arrView;
        [cell bringSubviewToFront:cell.lineView];
//        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }else if (tableView == self.mainTableView){
//        self.mainTableView.tableFooterView = self.fView;
        static NSString *mainCellIde = @"FeedCell";
        RequestFeedCell *cell = [tableView dequeueReusableCellWithIdentifier:mainCellIde];
        if (!cell) {
            cell = [[NSBundle mainBundle] loadNibNamed:@"RequestFeedCell" owner:nil options:nil].firstObject;
            NSLog(@"cell = %@",cell);
        }
        UserModel *user = [self.feedDataArray objectAtIndex:indexPath.row];
        NSURL *url = [NSURL URLWithString:user.headViewUrlString_L];
        NSLog(@"user.headURL = %@",user.headViewUrlString_L);
        [cell.headerView sd_setImageWithURL:url];
        if (user.likeTag) {
            cell.likedLabel.hidden = NO;
        }else{
            cell.likedLabel.hidden = YES;
        }
        
        cell.userId = user.userId;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.likeButton.tag = indexPath.row;
        cell.passButton.tag = indexPath.row + 10000;
        cell.reportButton.tag = indexPath.row + 20000;
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(getDetailInfo:)];
        
        for (UIGestureRecognizer *ges in cell.headerView.gestureRecognizers) {
            [cell.headerView removeGestureRecognizer:ges];
        }
        cell.headerView.tag = indexPath.row;
        [cell.headerView addGestureRecognizer:tap];
        [cell.likeButton removeTarget:self action:@selector(like:) forControlEvents:UIControlEventTouchUpInside];
        [cell.likeButton addTarget:self action:@selector(like:) forControlEvents:UIControlEventTouchUpInside];
        [cell.passButton removeTarget:self action:@selector(pass:) forControlEvents:UIControlEventTouchUpInside];
        [cell.passButton addTarget:self action:@selector(pass:) forControlEvents:UIControlEventTouchUpInside];
        [cell.reportButton removeTarget:self action:@selector(reportPhoto:) forControlEvents:UIControlEventTouchUpInside];
        [cell.reportButton addTarget:self action:@selector(reportPhoto:) forControlEvents:UIControlEventTouchUpInside];
        return cell;
    }else if (tableView == self.rightTableView){
        static NSString *rightCellIde = @"notiCellIde";
        NotiTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:rightCellIde];
        if (!cell) {
            cell = [[NotiTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:rightCellIde];
        }
        
        UserModel *user = [self.rightDataArray objectAtIndex:indexPath.row];
        NSString *urlString = user.headViewUrlString_S;
        [cell.headerView sd_setImageWithURL:[NSURL URLWithString:urlString]];
        NSLog(@"urlString = %@",urlString);
      
        if (user.notiString) {
            //实例化一个NSDateFormatter对象
            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
            //设定时间格式,这里可以设置成自己需要的格式
            [dateFormatter setDateFormat:@"HH:mm"];
            NSTimeZone* localzone = [NSTimeZone localTimeZone];
            [dateFormatter setTimeZone:localzone];
            NSDate *date = [NSDate dateWithTimeIntervalSince1970:user.likedTime.unsignedLongLongValue / 1000.f];
            NSString *currentDateStr = [dateFormatter stringFromDate:date];
            NSLog(@"currentDateStr = %@",currentDateStr);
            cell.timeLabel.text = currentDateStr;
            cell.messageLabel.text = user.notiString;
        }else{
            NSLog(@"userModel.count = %ld",user.communiDataArray.count);
            NSString *string = ((RCMessage *)user.communiDataArray.lastObject).text;
            if (string) {
                NSDate *date = ((RCMessage *)user.communiDataArray.lastObject).timestamp;
                NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
                //设定时间格式,这里可以设置成自己需要的格式
                [dateFormatter setDateFormat:@"HH:mm"];
                NSTimeZone* localzone = [NSTimeZone localTimeZone];
                [dateFormatter setTimeZone:localzone];
                NSString *currentDateStr = [dateFormatter stringFromDate:date];
                cell.timeLabel.text = currentDateStr;
                cell.messageLabel.text = string;
            }else{
                cell.messageLabel.text  = LocalizedString(@"chat_start", nil);
               
            }
            //check time
            NSDate *date = [NSDate date];
            NSTimeInterval interval = [date timeIntervalSince1970];
            if ((interval + [CommonUtil defaultUtil].fixTime/1000.f) > user.endTime.doubleValue / 1000.f) {
                //timeOUt
                 cell.messageLabel.text  = LocalizedString(@"time_up", nil);
            }
        }
        
        return cell;
    }
    return nil;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView == self.rightTableView) {
        editingStyle = UITableViewCellEditingStyleDelete;//此处的EditingStyle可等于任意UITableViewCellEditingStyle，该行代码只在iOS8.0以前版本有作用，也可以不实现。
    }else{
        editingStyle = UITableViewCellEditingStyleNone;
    }
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView == self.rightTableView && self.commBtn.selected) {
        return YES;
    }
    return NO;
    
}

#pragma mark 设置编辑的样式

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath

{
    
    return UITableViewCellEditingStyleDelete;
    
}

#pragma mark - MFMailComposeViewControllerDelegate
- (void)mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error{
    [controller dismissViewControllerAnimated:YES completion:^{
        if(MFMailComposeResultSent == result){
            showMBProgressHUD(@"success", NO);
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                hideMBProgressHUD();
            });
        }
    }];
}


- (NSArray *)tableView:(UITableView *)tableView editActionsForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView == self.rightTableView && self.commBtn.selected) {
        UITableViewRowAction *deleteRoWAction = [UITableViewRowAction rowActionWithStyle:UITableViewRowActionStyleDestructive title:@"Delete" handler:^(UITableViewRowAction *action, NSIndexPath *indexPath) {//title可自已定义
            NSLog(@"点击删除");
            self.deleteIndex = indexPath.row;
            self.deleteTipsAlert = [[UIAlertView alloc] initWithTitle:@"Tips" message:@"Delete?" delegate:self cancelButtonTitle:LocalizedString(@"ok", nil) otherButtonTitles:nil, nil];
            [self.deleteTipsAlert show];
        }];//此处是iOS8.0以后苹果最新推出的api，UITableViewRowAction，Style是划出的标签颜色等状态的定义，这里也可自行定义
        deleteRoWAction.backgroundColor = colorWithHexString(@"#E00b0b");
        UITableViewRowAction *editRowAction = [UITableViewRowAction rowActionWithStyle:UITableViewRowActionStyleNormal title:LocalizedString(@"button_report", nil) handler:^(UITableViewRowAction *action, NSIndexPath *indexPath) {
            UserModel *user = self.communicationArray[indexPath.row];
            self.deleteIndex = indexPath.row;
            [self showReportUserAlert:user];
        }];
        editRowAction.backgroundColor = colorWithHexString(@"#4c4b4b");//可以定义RowAction的颜色
        return @[deleteRoWAction, editRowAction];//最后返回这俩个RowAction 的数组
    }
    
    return nil;
}

- (void)showReportUserAlert:(UserModel *)user
{
    self.reportUser = user;
    self.reportUserAlert = [[UIAlertView alloc] initWithTitle:@"Tips" message:@"report" delegate:self cancelButtonTitle:@"YES" otherButtonTitles:@"NO", nil];
    [self.reportUserAlert show];
}

- (void)reportUser:(UserModel *)user
{
    NetworkingManager *mananger = [NetworkingManager manager];
    [mananger reportUserFromRequestId:[userdefault objectForKey:kRequestId] toUserId:user.userId success:^(NSURLSessionDataTask *task, id responseObject) {
        NSDictionary *result = (NSDictionary *)responseObject;
        NSLog(@"report User = %@",result);
        NSNumber *stateNum = [result objectForKey:@"state"];
        if (stateNum.intValue == 10000) {
            
        }
    } error:^(NSError *err) {
        
    }];
}

- (void)getDetailInfo:(UITapGestureRecognizer *)tap
{
    UIImageView *imageView = (UIImageView *)tap.view;
    NSInteger index = imageView.tag;
    UserModel *user = [self.feedDataArray objectAtIndex:index];
    DetailInfoViewController *detail = [[DetailInfoViewController alloc] init];
    detail.user = user;
    [self presentViewController:detail animated:YES completion:nil];
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)timerFireMethod:(NSTimer *)theTimer
{
//    BOOL timeStart = YES;
    NSCalendar *cal = [NSCalendar currentCalendar];//定义一个NSCalendar对象
    NSDateComponents *endTime = [[NSDateComponents alloc] init];    //初始化目标时间...
    NSDate *today = [NSDate date];    //得到当前时间
    
    NSTimeInterval interval = [today timeIntervalSince1970];
    NSDate *today2 = [NSDate dateWithTimeIntervalSince1970:interval + [CommonUtil defaultUtil].fixTime/1000.f];
//    NSLog(@"fixtime = %ld",[CommonUtil defaultUtil].fixTime/1000.f);
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
//    NSTimeZone *timezone = [NSTimeZone localTimeZone];
//    [dateFormatter setTimeZone:timezone];
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
//    NSDate *date = [NSdate date]
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:(((NSNumber *)[userdefault objectForKey:kEndTime]).integerValue) / 1000];
//    NSDate *dateString = [dateFormatter
//    NSDate *dateString = [dateFormatter dateFromString:todate];
    
    NSString *overdate = [dateFormatter stringFromDate:date];
//        NSLog(@"overdate = %@",overdate);
    static int year;
    static int month;
    static int day;
    static int hour;
    static int minute;
    static int second;
    if(_timerStart) {//从NSDate中取出年月日，时分秒，但是只能取一次
        year = [[overdate substringWithRange:NSMakeRange(0, 4)] intValue];
        month = [[overdate substringWithRange:NSMakeRange(5, 2)] intValue];
        day = [[overdate substringWithRange:NSMakeRange(8, 2)] intValue];
        hour = [[overdate substringWithRange:NSMakeRange(11, 2)] intValue];
        minute = [[overdate substringWithRange:NSMakeRange(14, 2)] intValue];
        second = [[overdate substringWithRange:NSMakeRange(17, 2)] intValue];
        _timerStart = NO;
    }
    
    [endTime setYear:year];
    [endTime setMonth:month];
    [endTime setDay:day];
    [endTime setHour:hour];
    [endTime setMinute:minute];
    [endTime setSecond:second];
    NSDate *overTime = [cal dateFromComponents:endTime]; //把目标时间装载入date
    //用来得到具体的时差，是为了统一成北京时间
    unsigned int unitFlags = NSYearCalendarUnit| NSMonthCalendarUnit| NSDayCalendarUnit| NSHourCalendarUnit| NSMinuteCalendarUnit| NSSecondCalendarUnit;
    NSDateComponents *d = [cal components:unitFlags fromDate:today2 toDate:overTime options:0];
    NSString *t = [NSString stringWithFormat:@"%ld", (long)[d day]];
    NSString *h = [NSString stringWithFormat:@"%ld", (long)[d hour]];
    NSString *fen = [NSString stringWithFormat:@"%ld", (long)[d minute]];
    if([d minute] < 10) {
        fen = [NSString stringWithFormat:@"0%ld",(long)[d minute]];
    }
    NSString *miao = [NSString stringWithFormat:@"%ld", (long)[d second]];
    if([d second] < 10) {
        miao = [NSString stringWithFormat:@"0%ld",(long)[d second]];
    }
//        NSLog(@"===%@天 %@:%@:%@",t,h,fen,miao);
//    [self.fdv.timeLabel setText:[NSString stringWithFormat:@"%@天 %@:%@:%@",t,h,fen,miao]];
    
    if([d second] >= 0) {
        [self.fDv.timeLabel setText:[NSString stringWithFormat:LocalizedString(@"time_left", nil),fen]];
        [self.fView.timeLabel setText:[NSString stringWithFormat:LocalizedString(@"time_left", nil),fen]];
        //计时尚未结束，do_something
        //        [_longtime setText:[NSString stringWithFormat:@"%@:%@:%@",d,fen,miao]];
    }else {
        [self timeOver];
//        //计时器失效
        _timerStart = YES;
        [theTimer invalidate];
    }
    
}

- (void)timeOver
{
    [self.fDv.timeLabel setText:LocalizedString(@"request_expired", nil)];
    [self.fView.timeLabel setText:LocalizedString(@"request_expired", nil)];
    [self.feedDataArray removeAllObjects];
    [self.mainTableView reloadData];
    self.mainTableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
//    self.isRequesting = NO;
//    [userdefault setObject:[NSNumber numberWithBool:self.isRequesting] forKey:kIsRequesting];
//    [userdefault synchronize];
     [self.requestLoadingView removeFromSuperview];
    [self setRequestViewAndAnimation];
    [self.animationView removeFromSuperview];
    self.loadingTipsLabel.text = LocalizedString(@"times_up_tips", nil);
//    [self.fDv.deleteBtn setTitle:@"Start Over" forState:UIControlStateNormal];
}

#pragma mark - ScrollView delegate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if (scrollView == self.mainScrollView)
    {
        self.leftTableView.scrollEnabled = NO;
        self.rightTableView.scrollEnabled = NO;
    }
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    if (scrollView == self.mainScrollView)
    {
        self.leftTableView.scrollEnabled = YES;
        self.rightTableView.scrollEnabled = YES;
    }
    if (scrollView.contentOffset.x >= windowWidth() *2) {
        self.tips.hidden = YES;
    }
}


/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end

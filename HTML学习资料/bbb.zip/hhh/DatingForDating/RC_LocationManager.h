//
//  RC_LocationManager.h
//  DatingForDating
//
//  Created by MAXToooNG on 16/3/30.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RC_LocationManager : NSObject

- (RC_LocationManager *)manager;

@end

/*
 Copyright (C) 2015 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 Implements the SKPaymentTransactionObserver protocol. Handles purchasing and restoring products
         as well as downloading hosted content using paymentQueue:updatedTransactions: and paymentQueue:updatedDownloads:,
         respectively. Provides download progress information using SKDownload's progres. Logs the location of the downloaded
         file using SKDownload's contentURL property.
 */


#import "StoreObserver.h"

NSString * const IAPPurchaseNotification = @"IAPPurchaseNotification";


@implementation StoreObserver

+ (StoreObserver *)sharedInstance
{
    static dispatch_once_t onceToken;
    static StoreObserver * storeObserverSharedInstance;
    
    dispatch_once(&onceToken, ^{
        storeObserverSharedInstance = [[StoreObserver alloc] init];
    });
    return storeObserverSharedInstance;
}


- (instancetype)init
{
	self = [super init];
	if (self != nil)
    {
        _productsPurchased = [[NSMutableArray alloc] initWithCapacity:0];
        _productsRestored = [[NSMutableArray alloc] initWithCapacity:0];
    }
	return self;
}


#pragma mark -
#pragma mark Make a purchase

// Create and add a payment request to the payment queue
-(void)buy:(SKProduct *)product
{
    SKMutablePayment *payment = [SKMutablePayment paymentWithProduct:product];
	[[SKPaymentQueue defaultQueue] addPayment:payment];
}


#pragma mark -
#pragma mark Has purchased products

// Returns whether there are purchased products
- (BOOL)hasPurchasedProducts
{
    // productsPurchased keeps track of all our purchases.
    // Returns YES if it contains some items and NO, otherwise
     return (self.productsPurchased.count > 0);
}


#pragma mark -
#pragma mark Has restored products

// Returns whether there are restored purchases
-(BOOL)hasRestoredProducts
{
    // productsRestored keeps track of all our restored purchases.
    // Returns YES if it contains some items and NO, otherwise
    return (self.productsRestored.count > 0);
}


#pragma mark -
#pragma mark Restore purchases

-(void)restore
{
    self.productsRestored = [[NSMutableArray alloc] initWithCapacity:0];
    [[SKPaymentQueue defaultQueue] restoreCompletedTransactions];
}


#pragma mark -
#pragma mark SKPaymentTransactionObserver methods

// Called when there are trasactions in the payment queue
- (void)paymentQueue:(SKPaymentQueue *)queue updatedTransactions:(NSArray *)transactions
{
	for(SKPaymentTransaction * transaction in transactions)
	{
		switch (transaction.transactionState )
		{
			case SKPaymentTransactionStatePurchasing:
				break;
                
            case SKPaymentTransactionStateDeferred:
                // Do not block your UI. Allow the user to continue using your app.
                NSLog(@"Allow the user to continue using your app.");
                break;
            // The purchase was successful
			case SKPaymentTransactionStatePurchased:
            {
                self.purchasedID = transaction.payment.productIdentifier;
                [self.productsPurchased addObject:transaction];
                
                NSLog(@"Deliver content for %@",transaction.payment.productIdentifier);
                // Check whether the purchased product has content hosted with Apple.
                if(transaction.downloads && transaction.downloads.count > 0)
                {
                    [self completeTransaction:transaction forStatus:IAPDownloadStarted];
                }
                else
                {
                    [self completeTransaction:transaction forStatus:IAPPurchaseSucceeded];
                }
            }
                break;
            // There are restored products
            case SKPaymentTransactionStateRestored:
            {
                self.purchasedID = transaction.payment.productIdentifier;
                [self.productsRestored addObject:transaction];
                
                NSLog(@"Restore content for %@",transaction.payment.productIdentifier);
                // Send a IAPDownloadStarted notification if it has
                if(transaction.downloads && transaction.downloads.count > 0)
                {
                    [self completeTransaction:transaction forStatus:IAPDownloadStarted];
                }
                else
                {
                   [self completeTransaction:transaction forStatus:IAPRestoredSucceeded];
                }
            }
				break;
            // The transaction failed
			case SKPaymentTransactionStateFailed:
            {
                self.message = [NSString stringWithFormat:@"Purchase of %@ failed.",transaction.payment.productIdentifier];
                [self completeTransaction:transaction forStatus:IAPPurchaseFailed];
            }
            break;
			default:
                break;
		}
	}
}


// Called when the payment queue has downloaded content
- (void)paymentQueue:(SKPaymentQueue *)queue updatedDownloads:(NSArray *)downloads
{
    for (SKDownload* download in downloads)
    {
        switch (download.downloadState)
        {
            // The content is being downloaded. Let's provide a download progress to the user
            case SKDownloadStateActive:
            {
                self.status = IAPDownloadInProgress;
                self.purchasedID = download.transaction.payment.productIdentifier;
                self.downloadProgress = download.progress*100;
                [[NSNotificationCenter defaultCenter] postNotificationName:IAPPurchaseNotification object:self];
            }
                break;
                
            case SKDownloadStateCancelled:
                // StoreKit saves your downloaded content in the Caches directory. Let's remove it
                // before finishing the transaction.
                [[NSFileManager defaultManager] removeItemAtURL:download.contentURL error:nil];
                [self finishDownloadTransaction:download.transaction];
                break;
                
            case SKDownloadStateFailed:
                // If a download fails, remove it from the Caches, then finish the transaction.
                // It is recommended to retry downloading the content in this case.
                [[NSFileManager defaultManager] removeItemAtURL:download.contentURL error:nil];
                [self finishDownloadTransaction:download.transaction];
                break;
                
            case SKDownloadStatePaused:
                NSLog(@"Download was paused");
                break;
                
            case SKDownloadStateFinished:
                // Download is complete. StoreKit saves the downloaded content in the Caches directory.
                NSLog(@"Location of downloaded file %@",download.contentURL);
                [self finishDownloadTransaction:download.transaction];
                break;
                
            case SKDownloadStateWaiting:
                NSLog(@"Download Waiting");
                [[SKPaymentQueue defaultQueue] startDownloads:@[download]];
                break;
                
            default:
                break;
        }
    }
}


// Logs all transactions that have been removed from the payment queue
- (void)paymentQueue:(SKPaymentQueue *)queue removedTransactions:(NSArray *)transactions
{
	for(SKPaymentTransaction * transaction in transactions)
	{
		NSLog(@"%@ was removed from the payment queue.", transaction.payment.productIdentifier);
	}
}


// Called when an error occur while restoring purchases. Notify the user about the error.
- (void)paymentQueue:(SKPaymentQueue *)queue restoreCompletedTransactionsFailedWithError:(NSError *)error
{
    if (error.code != SKErrorPaymentCancelled)
    {
        self.status = IAPRestoredFailed;
        self.message = error.localizedDescription;
        [[NSNotificationCenter defaultCenter] postNotificationName:IAPPurchaseNotification object:self];
    }
 
}


// Called when all restorable transactions have been processed by the payment queue
- (void)paymentQueueRestoreCompletedTransactionsFinished:(SKPaymentQueue *)queue
{
    NSLog(@"All restorable transactions have been processed by the payment queue.");
}


#pragma mark -
#pragma mark Complete transaction

// Notify the user about the purchase process. Start the download process if status is
// IAPDownloadStarted. Finish all transactions, otherwise.
-(void)completeTransaction:(SKPaymentTransaction *)transaction forStatus:(NSInteger)status
{
    self.status = status;
    //Do not send any notifications when the user cancels the purchase
    if (transaction.error.code != SKErrorPaymentCancelled)
    {
        // Notify the user
        [[NSNotificationCenter defaultCenter] postNotificationName:IAPPurchaseNotification object:self];
    }
    if (transaction.error.code == SKErrorPaymentCancelled) {
        [[NSNotificationCenter defaultCenter] postNotificationName:@"canceled" object:self];
    }
    
    if (status == IAPPurchaseSucceeded) {
        [self verifyPruchase:transaction];
    }
    
    if (status == IAPDownloadStarted)
    {
        // The purchased product is a hosted one, let's download its content
        [[SKPaymentQueue defaultQueue] startDownloads:transaction.downloads];
    }
    else
    {
        // Remove the transaction from the queue for purchased and restored statuses
        [[SKPaymentQueue defaultQueue] finishTransaction:transaction];
    }
}


#pragma mark -
#pragma mark - Handle download transaction

- (void)finishDownloadTransaction:(SKPaymentTransaction*)transaction
{
    //allAssetsDownloaded indicates whether all content associated with the transaction were downloaded.
    BOOL allAssetsDownloaded = YES;
    
    // A download is complete if its state is SKDownloadStateCancelled, SKDownloadStateFailed, or SKDownloadStateFinished
    // and pending, otherwise. We finish a transaction if and only if all its associated downloads are complete.
    // For the SKDownloadStateFailed case, it is recommended to try downloading the content again before finishing the transaction.
    for (SKDownload* download in transaction.downloads)
    {
        if (download.downloadState != SKDownloadStateCancelled &&
            download.downloadState != SKDownloadStateFailed &&
            download.downloadState != SKDownloadStateFinished )
        {
            //Let's break. We found an ongoing download. Therefore, there are still pending downloads.
            allAssetsDownloaded = NO;
            break;
        }
    }
    
    // Finish the transaction and post a IAPDownloadSucceeded notification if all downloads are complete
    if (allAssetsDownloaded)
    {
        self.status = IAPDownloadSucceeded;
        
        [[SKPaymentQueue defaultQueue] finishTransaction:transaction];
        [[NSNotificationCenter defaultCenter] postNotificationName:IAPPurchaseNotification object:self];
        
        if ([self.productsRestored containsObject:transaction])
        {
            self.status = IAPRestoredSucceeded;
            [[NSNotificationCenter defaultCenter] postNotificationName:IAPPurchaseNotification object:self];
        }

    }
}

#pragma mark 本地验证购买凭据
- (void)verifyPruchase:(SKPaymentTransaction *)transaction
{
    //  transaction.transactionReceipt
     NSString *key = [NSString stringWithFormat:@"%d%@",((NSNumber *)[userdefault objectForKey:kUserId]).intValue,kReceiptData];
    //      验证凭据，获取到苹果返回的交易凭据
    //      appStoreReceiptURL iOS7.0增加的，购买交易完成后，会将凭据存放在该地址
    NSURL *receiptURL = [[NSBundle mainBundle] appStoreReceiptURL];
    //      从沙盒中获取到购买凭据
    NSData *receiptData = [NSData dataWithContentsOfURL:receiptURL];
    
    //      发送网络POST请求，对购买凭据进行验证
    NSURL *url = [NSURL URLWithString:@"https://sandbox.itunes.apple.com/verifyReceipt"];
    //      国内访问苹果服务器比较慢，timeoutInterval需要长一点
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:10.0f];
    
    request.HTTPMethod = @"POST";
    
    // 在网络中传输数据，大多情况下是传输的字符串而不是二进制数据
    // 传输的是BASE64编码的字符串
    /**
     -      BASE64 常用的编码方案，通常用于数据传输，以及加密算法的基础算法，传输过程中能够保证数据传输的稳定性
     -      BASE64是可以编码和解码的
     -      */
    
    NSString *encodeStr = [receiptData base64EncodedStringWithOptions:NSDataBase64EncodingEndLineWithLineFeed];
    [userdefault setObject:encodeStr forKey:key];
    [userdefault synchronize];
    
    [[iCloud sharedCloud] saveAndCloseDocumentWithName:@"Data1.ext" withContent:[encodeStr dataUsingEncoding:NSUTF8StringEncoding] completion:^(UIDocument *cloudDocument, NSData *documentData, NSError *error) {
        NSLog(@"error = %@",error.localizedDescription);
        if (error == nil) {
            // Code here to use the UIDocument or NSData objects which have been passed with the completion handler
        }
    }];
//             NSString *encodeStr = [transaction.transactionReceipt base64EncodedStringWithOptions:NSDataBase64EncodingEndLineWithLineFeed];
    
//    NSString *payload = [NSString stringWithFormat:@"{\"receipt-data\" : \"%@\"}", encodeStr];
    NSMutableDictionary *parms = [[NSMutableDictionary alloc] init];
    [parms setObject:encodeStr forKey:@"receipt-data"];
    [parms setObject:kSecretKey forKey:@"password"];
    NSString *payload = [self dictionaryToJson:parms];
    NSLog(@"payload = %@",payload);
    NSData *payloadData = [payload dataUsingEncoding:NSUTF8StringEncoding];
    
    request.HTTPBody = payloadData;
    
    //      提交验证请求，并获得官方的验证JSON结果
    NSData *result = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
    
    //      官方验证结果为空

    if (result == nil) {
        NSLog(@"验证失败");
//        [CommonUtil defaultUtil].isFee = @NO;
//        [userdefault setObject:[CommonUtil defaultUtil].isFee forKey:kIsFee];
//        [userdefault synchronize];
        return;
    }
    
    NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:result options:NSJSONReadingAllowFragments error:nil];
    
    NSLog(@"%@", dict);
    
    if (dict != nil) {
        NSNumber *state = [dict objectForKey:@"status"];
        if (state.intValue == 0) {
            NSString *receipt = [dict objectForKey:@"latest_receipt"];
            [userdefault setObject:receipt forKey:kReceiptData];
            [userdefault setObject:receipt forKey:key];
            [userdefault synchronize];
            NSArray *array = [dict objectForKey:@"latest_receipt_info"];
            NSDictionary *receiptDic = array.lastObject;
            if (receipt) {
                NSString *number = [receiptDic objectForKey:@"expires_date_ms"];
                NSLog(@"^^^^^^^^^^^^^time = %lld ^^^^^^^^^^^^^^^ ",number.longLongValue);
                NSDate *now = [NSDate date];    //得到当前时间
                NSTimeInterval interval = [now timeIntervalSince1970];
                NSTimeInterval tureTime = interval + [CommonUtil defaultUtil].fixTime/1000.f;
                if (number.longLongValue / 1000.f > tureTime) {
                    NSLog(@"验证成功并有效");
//                    [CommonUtil defaultUtil].isFee = @YES;
                }else{
                    NSLog(@"验证成功但无效");
//                    [CommonUtil defaultUtil].isFee = @NO;
                }
            }
            //      比对字典中以下信息基本上可以保证数据安全
            //      bundle_id&application_version&product_id&transaction_id
            hideMBProgressHUD();
            
        }else{
//            [CommonUtil defaultUtil].isFee = @NO;
            NSLog(@"验证异常");
        }
        [userdefault setObject:[CommonUtil defaultUtil].isFee forKey:kIsFee];
        [userdefault synchronize];
        
    }
    
}

- (void)restoreAutoResult:(void (^)(void))resu
{
    NSString *key = [NSString stringWithFormat:@"%d%@",((NSNumber *)[userdefault objectForKey:kUserId]).intValue,kReceiptData];
    //      发送网络POST请求，对购买凭据进行验证
    NSURL *url = [NSURL URLWithString:@"https://sandbox.itunes.apple.com/verifyReceipt"];
    //      国内访问苹果服务器比较慢，timeoutInterval需要长一点
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:10.0f];
    
    request.HTTPMethod = @"POST";
    
    // 在网络中传输数据，大多情况下是传输的字符串而不是二进制数据
    // 传输的是BASE64编码的字符串
    /**
     -      BASE64 常用的编码方案，通常用于数据传输，以及加密算法的基础算法，传输过程中能够保证数据传输的稳定性
     -      BASE64是可以编码和解码的
     -      */
    NSString *encodeStr = [userdefault objectForKey:key];
    if (encodeStr == nil || [encodeStr isEqualToString:@" "]) {
        [CommonUtil defaultUtil].isFee = @NO;
        resu();
        return;
    }
//    NSString *encodeStr = [[userdefault objectForKey:kReceiptData] base64EncodedStringWithOptions:NSDataBase64EncodingEndLineWithLineFeed];
    //         NSString *encodeStr = [transaction.transactionReceipt base64EncodedStringWithOptions:NSDataBase64EncodingEndLineWithLineFeed];
    
    //    NSString *payload = [NSString stringWithFormat:@"{\"receipt-data\" : \"%@\"}", encodeStr];
    NSMutableDictionary *parms = [[NSMutableDictionary alloc] init];
    [parms setObject:encodeStr forKey:@"receipt-data"];
    [parms setObject:kSecretKey forKey:@"password"];
    NSString *payload = [self dictionaryToJson:parms];
    //    NSLog(@"payload = %@",payload);
    NSData *payloadData = [payload dataUsingEncoding:NSUTF8StringEncoding];
    
    request.HTTPBody = payloadData;
    
    //      提交验证请求，并获得官方的验证JSON结果
    NSData *result = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
    
    //      官方验证结果为空
    if (result == nil) {
        NSLog(@"验证失败");
        [CommonUtil defaultUtil].isFee = @NO;
        resu();
        return;
    }

    NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:result options:NSJSONReadingAllowFragments error:nil];
    
    NSLog(@"%@", dict);
    
    if (dict != nil) {
        NSNumber *state = [dict objectForKey:@"status"];
        if (state.intValue == 0) {
            NSString *receipt = [dict objectForKey:@"latest_receipt"];
            [userdefault setObject:receipt forKey:key];
            [userdefault synchronize];
            [[iCloud sharedCloud] saveAndCloseDocumentWithName:@"Data1.ext" withContent:[receipt dataUsingEncoding:NSUTF8StringEncoding] completion:^(UIDocument *cloudDocument, NSData *documentData, NSError *error) {
                NSLog(@"error = %@",error.localizedDescription);
                if (error == nil) {
                    // Code here to use the UIDocument or NSData objects which have been passed with the completion handler
                }
            }];
            NSArray *array = [dict objectForKey:@"latest_receipt_info"];
            NSDictionary *receiptDic = array.lastObject;
            if (receipt) {
                NSString *number = [receiptDic objectForKey:@"expires_date_ms"];
                NSLog(@"^^^^^^^^^^^^^time = %lld ^^^^^^^^^^^^^^^ ",number.longLongValue);
                NSDate *now = [NSDate date];    //得到当前时间
                NSTimeInterval interval = [now timeIntervalSince1970];
                NSTimeInterval tureTime = interval + [CommonUtil defaultUtil].fixTime/1000.f;
                if (number.longLongValue / 1000.f > tureTime) {
                    NSLog(@"验证成功并有效");
                    [CommonUtil defaultUtil].isFee = @YES;
                }else{
                    NSLog(@"验证成功但无效");
                    [CommonUtil defaultUtil].isFee = @NO;
                }
                
                [userdefault setObject:@NO forKey:kIsFirstIap];
                [userdefault synchronize];
            }
            //      比对字典中以下信息基本上可以保证数据安全
            //      bundle_id&application_version&product_id&transaction_id
            
            hideMBProgressHUD();
            
        }else{
             [CommonUtil defaultUtil].isFee = @NO;

            NSLog(@"验证异常");
        }
        [userdefault setObject:[CommonUtil defaultUtil].isFee forKey:kIsFee];
        [userdefault synchronize];
        
    }
    resu();

}

- (NSString*)dictionaryToJson:(NSDictionary *)dic
{
    //    NSLog(@"dict = %@",dic);
    NSError *parseError = nil;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dic options:NSJSONWritingPrettyPrinted error:&parseError];
    return [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
}


@end

//
//  UIButton+imageAndLabel.h
//  DatingForDating
//
//  Created by MAXToooNG on 16/4/14.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton (imageAndLabel)
- (void) setImage:(UIImage *)image withTitle:(NSString *)title forState:(UIControlState)stateType;
@end

//
//  OutgoingTableViewCell.m
//  DatingForDating
//
//  Created by MAXToooNG on 16/4/13.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import "OutgoingTableViewCell.h"

@interface OutgoingTableViewCell ()

@property (nonatomic, strong) UIImageView *coverView;
@end

@implementation OutgoingTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle: style reuseIdentifier:reuseIdentifier]) {
        
    }
    return self;
}

- (void)initView
{
     [self.headView removeFromSuperview];
    self.headView = [[UIImageView alloc] initWithFrame:CGRectMake(8, 8, 40, 40)];
    self.headView.layer.cornerRadius = self.headView.frame.size.width / 2;
    self.headView.layer.masksToBounds = YES;
    self.headView.contentMode = UIViewContentModeScaleAspectFill;
    [self.contentView addSubview:self.headView];
    self.backgroundColor = colorWithHexString(@"#181818");
//    [self.contentView addSubview:self.headView];
    [self.textView removeFromSuperview];
    [self.textViewBackgroundView removeFromSuperview];
    [self.coverView removeFromSuperview];
    [self.photoView removeFromSuperview];
    switch (self.cellType) {
        case CellOutTypeText:
        {
            [self.contentView addSubview:self.headView];
            self.textView = [[UITextView alloc] initWithFrame:CGRectMake(60, 8, windowWidth() - 60, 44)];
            self.textView.backgroundColor = [UIColor clearColor];
            self.textView.textContainerInset = UIEdgeInsetsMake(15, 10, 15, 10);
            self.textViewBackgroundView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, self.textView.frame.size.width, self.textView.frame.size.height)];
            UIImage *backImage = [[UIImage imageNamed:@"chat_dialogbox_2"] resizableImageWithCapInsets:UIEdgeInsetsMake(24, 24, 53, 55) resizingMode:UIImageResizingModeTile];
            self.textViewBackgroundView.image = backImage;
            [self.textView addSubview:self.textViewBackgroundView];
            [self.textView sendSubviewToBack:self.textViewBackgroundView];
            self.textView.delegate = self;
            self.textView.userInteractionEnabled = NO;
            self.textView.textColor = [UIColor whiteColor];
            self.textView.font = fontWithSize(17);
            [self.contentView addSubview:self.textView];
        }
            break;
        case CellOutTypeImage:
        {
            [self.contentView addSubview:self.headView];
            self.photoView = [[UIImageView alloc] initWithFrame:CGRectMake(windowWidth() - 98, 8, 98, 93)];
            self.photoView.contentMode = UIViewContentModeScaleAspectFill;
            self.photoView.clipsToBounds = YES;
            self.photoView.userInteractionEnabled = YES;
            self.coverView = [[UIImageView alloc] initWithFrame:self.photoView.frame];
            self.coverView.image = [UIImage imageNamed:@"chat_dialogboxpic_2"];
            [self.contentView addSubview:self.photoView];
            [self.contentView addSubview:self.coverView];
            
        }
            break;
        case CellOutTypeGps:
        {
            [self.contentView addSubview:self.headView];
            self.photoView = [[UIImageView alloc] initWithFrame:CGRectMake(windowWidth() - 98, 8, 98, 93)];
            self.photoView.contentMode = UIViewContentModeScaleAspectFill;
            self.photoView.clipsToBounds = YES;
            self.photoView.userInteractionEnabled = YES;
            self.photoView.backgroundColor = [UIColor redColor];
            self.coverView = [[UIImageView alloc] initWithFrame:self.photoView.frame];
            self.coverView.image = [UIImage imageNamed:@"chat_dialogboxpic_2"];
            [self.contentView addSubview:self.photoView];
            [self.contentView addSubview:self.coverView];
        }
            break;
        case CellOutTypeLeave:
        case CellOutTypeTimeOut:
        {
            [self.headView removeFromSuperview];
            self.textLabel.textColor = [UIColor whiteColor];
            self.textLabel.textAlignment = NSTextAlignmentCenter;
            self.textLabel.font = fontWithSize(15);
        }
            break;
        default:
            break;
    }
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

//- (void)textViewDidChange:(UITextView *)textView
//{
//    CGSize size = [textView sizeThatFits:CGSizeMake(CGRectGetWidth(textView.frame), MAXFLOAT)];
//    CGRect frame = textView.frame;
//    frame.size.height = size.height;
//    textView.frame = frame;
//    self.textViewBackgroundView.frame = CGRectMake(0, 0, frame.size.width, frame.size.height);
//}


@end

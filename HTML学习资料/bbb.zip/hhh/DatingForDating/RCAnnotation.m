//
//  RCAnnotation.m
//  DatingForDating
//
//  Created by MAXToooNG on 16/3/31.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import "RCAnnotation.h"

@implementation RCAnnotation

- (void)setCoordinate:(CLLocationCoordinate2D)newCoordinate
{
    _coordinate = newCoordinate;
}

@end

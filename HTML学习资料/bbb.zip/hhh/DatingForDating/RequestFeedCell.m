//
//  RequestFeedCell.m
//  DatingForDating
//
//  Created by MAXToooNG on 16/4/7.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import "RequestFeedCell.h"

@implementation RequestFeedCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    self.likeButton.layer.borderColor = colorWithHexString(@"#fa5b3a").CGColor;
    self.likeButton.layer.borderWidth = 1;
    self.passButton.layer.borderWidth =1 ;
    self.passButton.layer.borderColor = colorWithHexString(@"#c6c6c6").CGColor;
    self.headerView.userInteractionEnabled = YES;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
- (IBAction)like:(id)sender {
}
- (IBAction)pass:(id)sender {
}

@end

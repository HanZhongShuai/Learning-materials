//
//  CommonUtil.m
//  DatingForDating
//
//  Created by MAXToooNG on 16/3/30.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import "CommonUtil.h"
@import MapKit;

@implementation CommonUtil
static CommonUtil *common = nil;
+ (CommonUtil *)defaultUtil
{
    if (!common) {
        common = [[CommonUtil alloc] init];
    }
    return common;
}

- (NSString*) uuid {
    CFUUIDRef puuid = CFUUIDCreate( nil );
    CFStringRef uuidString = CFUUIDCreateString( nil, puuid );
    NSString * result = (NSString *)CFBridgingRelease(CFStringCreateCopy( NULL, uuidString));
    CFRelease(puuid);
    CFRelease(uuidString);
    return result;
}

- (void)getTotalDistanceWalkTimeSuccess:(void (^)(NSString *, NSString *))walk AndCarTime:(void (^)(NSString *))car WithUser:(UserModel *)user
{
    NSLog(@"longitude = %f, latitude = %f",user.lat.doubleValue,user.lon.doubleValue);
    CLLocationCoordinate2D coordinateSource = CLLocationCoordinate2DMake(((NSNumber *)[userdefault objectForKey:kLatitude]).doubleValue, ((NSNumber *)[userdefault objectForKey:kLongitude]).doubleValue);
    
    MKDirectionsRequest *request = [[MKDirectionsRequest alloc] init];
    request.transportType = MKDirectionsTransportTypeWalking;
    MKPlacemark *sourceMark = [[MKPlacemark alloc] initWithCoordinate:coordinateSource addressDictionary:nil];
    request.source = [[MKMapItem alloc] initWithPlacemark:sourceMark];
    CLLocationCoordinate2D coordinate = CLLocationCoordinate2DMake(user.lat.doubleValue, user.lon.doubleValue);
    MKPlacemark *mark = [[MKPlacemark alloc] initWithCoordinate:coordinate addressDictionary:nil];
    request.destination = [[MKMapItem alloc] initWithPlacemark:mark];
    
    request.requestsAlternateRoutes = YES;
    MKDirections *direction = [[MKDirections alloc] initWithRequest:request];
    [direction calculateDirectionsWithCompletionHandler:^(MKDirectionsResponse * _Nullable response, NSError * _Nullable error) {
        NSLog(@"gei Info Success ");
        NSArray *array = response.routes;
        NSTimeInterval totalTime = 0;
        NSInteger times = 0;
        double distance = 0;
        for (MKRoute *route in array) {
            totalTime += route.expectedTravelTime;
            distance += route.distance;
            times += 1;
        }
        NSLog(@"times = %ld",times);
        NSLog(@"totalTime = %f",totalTime);
        NSLog(@"total distance = %f",distance);
        NSTimeInterval walkingTime = totalTime;
        CGFloat totalDistance = distance;
        NSString *resultDistance = [NSString stringWithFormat:@"%.1f km", totalDistance /1000];
//        self.distanceLabel.text = [NSString stringWithFormat:@"%.1f km",self.totalDistance /1000];
        NSString *walkTime = [NSString stringWithFormat:@"%.0fmin",(walkingTime / 60.f)];
//        self.timeLabel.text = [NSString stringWithFormat:@"%dh%.0fmin",(int)(self.walkingTime / 3600) ,((int)totalTime%3600 / 60.f)];
//        self.timeLabel.text = [NSString stringWithFormat:@"%.0fmin",(walkingTime / 60.f)];
        walk(resultDistance,walkTime);
    }];
    
    MKDirectionsRequest *carRequest = [[MKDirectionsRequest alloc] init];
    carRequest.transportType = MKDirectionsTransportTypeAutomobile;
    carRequest.source = [[MKMapItem alloc] initWithPlacemark:sourceMark];
    
    carRequest.destination = [[MKMapItem alloc] initWithPlacemark:mark];
    
    carRequest.requestsAlternateRoutes = NO;
    MKDirections *direction2 = [[MKDirections alloc] initWithRequest:carRequest];
    [direction2 calculateDirectionsWithCompletionHandler:^(MKDirectionsResponse * _Nullable response, NSError * _Nullable error) {
        NSLog(@"gei Info Success ");
        NSArray *array = response.routes;
        NSTimeInterval totalTime = 0;
        NSInteger times = 0;
        double distance = 0;
        for (MKRoute *route in array) {
            totalTime += route.expectedTravelTime;
            distance += route.distance;
            times += 1;
        }
        NSLog(@"times = %ld",times);
        NSLog(@"totalTime = %f",totalTime);
        NSLog(@"total distance = %f",distance);
        CGFloat carTime = totalTime;
        //        self.totalDistance = distance;
        //        self.distanceLabel.text = [NSString stringWithFormat:@"%.1f km",self.totalDistance /1000];
        //        self.carTimeLabel.text = [NSString stringWithFormat:@"%dh%.0fmin",(int)(self.carTime / 3600) ,((int)totalTime%3600 / 60.f)];
        NSString *resultTime =  [NSString stringWithFormat:@"%.0fmin",carTime / 60.f];
        car(resultTime);
    }];
}
@end

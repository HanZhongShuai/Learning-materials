//
//  UserModel.m
//  DatingForDating
//
//  Created by MAXToooNG on 16/3/29.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import "UserModel.h"

@implementation UserModel

- (void)getTestModel
{
    self.userId = @2;
    
    self.headViewUrlString_L = @"http://img5.duitang.com/uploads/blog/201406/20/20140620103001_8KhuZ.jpeg";
    self.headViewUrlString_S = @"http://img5.duitang.com/uploads/blog/201406/20/20140620103001_8KhuZ.jpeg";
//    self.startTime = [NSDate date];
//    self.timeOut = [NSDate date];
}

//@property (nonatomic, strong) NSNumber *userId;
//@property (nonatomic, strong) NSString *headViewUrlString_L;
//@property (nonatomic, strong) NSString *headViewUrlString_S;
//@property (nonatomic, strong) NSNumber *beginTime;
//@property (nonatomic, strong) NSNumber *endTime;
////@property (nonatomic, strong) NSNumber *dateTime;
//@property (nonatomic, strong) NSNumber *gender;
//@property (nonatomic, strong) NSNumber *requestId;
//@property (nonatomic, strong) NSNumber *lon;
//@property (nonatomic, strong) NSNumber *lat;
////notification status
//@property (nonatomic, strong) NSNumber *status;
//@property (nonatomic, strong) NSString *notiString;
//@property (nonatomic, assign) BOOL likeTag;
//@property (nonatomic, strong) NSNumber *likedTime;

- (id)initWithCoder:(NSCoder *)aDecoder
{
    if(self = [super init])
    {
        self.userId       = [aDecoder decodeObjectForKey:@"userId"];
        self.headViewUrlString_L           = [aDecoder decodeObjectForKey:@"headViewUrlString_L"];
        self.headViewUrlString_S = [aDecoder decodeObjectForKey:@"headViewUrlString_S"];
        self.beginTime = [aDecoder decodeObjectForKey:@"beginTime"];
        self.endTime = [aDecoder decodeObjectForKey:@"endTime"];
        self.gender = [aDecoder decodeObjectForKey:@"gender"];
        self.requestId = [aDecoder decodeObjectForKey:@"requestId"];
        self.lon = [aDecoder decodeObjectForKey:@"lon"];
        self.lat = [aDecoder decodeObjectForKey:@"lat"];
        self.status = [aDecoder decodeObjectForKey:@"status"];
        self.notiString = [aDecoder decodeObjectForKey:@"notiString"];
        self.commId = [aDecoder decodeObjectForKey:@"commId"];
//        self.likedTime = [aDecoder decodeObjectForKey:@"likedTime"];
    }
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{
    if (self.userId) {
        [aCoder encodeObject:self.userId forKey:@"userId"];
    }
    if (self.headViewUrlString_L) {
        [aCoder encodeObject:self.headViewUrlString_L forKey:@"headViewUrlString_L"];
    }
    if (self.headViewUrlString_S) {
        [aCoder encodeObject:self.headViewUrlString_S forKey:@"headViewUrlString_S"];
    }
    if (self.beginTime) {
        [aCoder encodeObject:self.beginTime forKey:@"beginTime"];
    }
    if (self.endTime) {
        [aCoder encodeObject:self.endTime forKey:@"endTime"];
    }
    if (self.gender) {
        [aCoder encodeObject:self.gender forKey:@"gender"];
    }
    if (self.requestId) {
        [aCoder encodeObject:self.requestId forKey:@"requestId"];
    }
    if (self.lon) {
        [aCoder encodeObject:self.lon forKey:@"lon"];
    }
    if (self.lat) {
        [aCoder encodeObject:self.lat forKey:@"lat"];
    }
    if (self.status) {
        [aCoder encodeObject:self.status forKey:@"status"];
    }
    if (self.notiString) {
        [aCoder encodeObject:self.notiString forKey:@"notiString"];
    }
    if (self.commId) {
        [aCoder encodeObject:self.commId forKey:@"commId"];
    }
//    [aCoder encodeObject:self.likedTime forKey:@"likedTime"];
    
    
}

@end

//
//  NotiTableViewCell.h
//  DatingForDating
//
//  Created by MAXToooNG on 16/4/17.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NotiTableViewCell : UITableViewCell
@property (nonatomic, strong) UIImageView *headerView;
@property (nonatomic, strong) UILabel *messageLabel;
@property (nonatomic, strong) UILabel *timeLabel;
@property (nonatomic, strong) UIView *lineView;
@end

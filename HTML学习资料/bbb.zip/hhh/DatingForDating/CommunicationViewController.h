//
//  CommunicationViewController.h
//  DatingForDating
//
//  Created by MAXToooNG on 16/4/13.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UserModel.h"

@interface CommunicationViewController : UIViewController
@property (nonatomic, strong) UserModel * userModel;
@property (nonatomic, strong) id<SINMessageClient> messageClient;
@end

//
//  RequestViewController.h
//  DatingForDating
//
//  Created by MAXToooNG on 16/3/15.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "StoreManager.h"

typedef NS_ENUM(NSUInteger, MessageType) {
    MessageText,
    MessageImage,
    MessageGPS,
    MessageLike,
    MessageWhoLikeU,
    MessageMatch,
    MessageLeave,
    MessageTimeOut
};

@interface RequestViewController : UIViewController

@end

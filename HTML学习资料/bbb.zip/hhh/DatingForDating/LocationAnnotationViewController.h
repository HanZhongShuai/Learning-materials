//
//  LocationAnnotationViewController.h
//  DatingForDating
//
//  Created by MAXToooNG on 16/3/31.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UserModel.h"
typedef void(^CoordinateInfo)(NSString *lat,NSString*lon);

@interface LocationAnnotationViewController : UIViewController

@property (nonatomic, copy) CoordinateInfo coor;
@property (nonatomic, strong) UserModel *user;

@end

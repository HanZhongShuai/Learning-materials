//
//  FeedFootView.m
//  DatingForDating
//
//  Created by MAXToooNG on 16/4/18.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import "FeedFootView.h"

@interface FeedFootView()
@property (nonatomic, strong) UIImageView *clockView;

//@property (nonatomic,)
@end

@implementation FeedFootView

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        [self initViews];
    }
    return self;
}

- (void)initViews
{
    self.backgroundColor = colorWithHexString(@"#181818");
    self.clockView = [[UIImageView alloc] initWithFrame:CGRectMake(0, setH(18), setW(23), setH(26))];
    self.clockView.center = CGPointMake(windowWidth() / 2, self.clockView.center.y);
    self.clockView.image = [UIImage imageNamed:@"newrequest_ic_timer"];
    [self addSubview:self.clockView];
    self.timeLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, setH(18) + setH(26) + setH(14), windowWidth(), 30)];
    self.timeLabel.font = fontWithSize(19);
    self.timeLabel.textColor = colorWithHexString(@"#e7e02D");
    [self addSubview:self.timeLabel];
    self.timeLabel.textAlignment = NSTextAlignmentCenter;
    self.timeLabel.text = @"59 minutes left";
    self.deleteBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    [self.deleteBtn setTitle:LocalizedString(@"button_delete",nil) forState:UIControlStateNormal];
    self.deleteBtn.layer.borderWidth = 1;
    self.deleteBtn.layer.borderColor = colorWithHexString(@"#fa5b3a").CGColor;
    [self.deleteBtn setTintColor:colorWithHexString(@"#fa5b3a")];
    self.deleteBtn.frame = CGRectMake(40, setH(18) + setH(26) + setH(14)+ 30 + setH(30), windowWidth() - 80, 35);
    [self addSubview:self.deleteBtn];
}

@end

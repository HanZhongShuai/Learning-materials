//
//  LaunchLoadingViewController.m
//  DatingForDating
//
//  Created by MAXToooNG on 16/4/14.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import "LaunchLoadingViewController.h"
#import "NetworkingManager.h"
#import "RequestViewController.h"
#import "ViewController.h"
#import "UIImage+GIF.h"
#import "BannedView.h"
#import "TermsViewController.h"
#import "StoreObserver.h"
@import MapKit;

@interface LaunchLoadingViewController ()<CLLocationManagerDelegate, UIAlertViewDelegate, iCloudDelegate>
@property (nonatomic, strong) CLLocationManager *locationManager;
@property (nonatomic, strong) BannedView *bannerView;
@property (nonatomic, assign) BOOL timerStart;
@property (nonatomic, strong) NSTimer *bannedTimer;
@end

@implementation LaunchLoadingViewController

- (void)viewDidLoad
{
    self.view.backgroundColor = colorWithHexString(@"#181818");
    UIImageView *gifView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, setW(55), setW(55))];
    gifView.center = CGPointMake(self.view.center.x, self.view.center.y - 40);
    gifView.image = [UIImage sd_animatedGIFNamed:@"loading1"];
    [self.view addSubview:gifView];
         [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changeToken) name:NSUbiquityIdentityDidChangeNotification object:nil];
//    NSString *token = (NSString *)[[NSFileManager defaultManager] ubiquityIdentityToken];
    NSRange range = NSMakeRange(1,[[[[NSFileManager defaultManager] ubiquityIdentityToken] description] length]-2);
    NSString *icloudToken = [[[[NSFileManager defaultManager] ubiquityIdentityToken] description] substringWithRange:range];
    if (icloudToken) {
        NSLog(@"icloudToken = %@",icloudToken);
        [userdefault setObject:icloudToken forKey:kiCloudToken];
        [userdefault synchronize];
    }

    
    
        [self initiCloud];

    [super viewDidLoad];
    [self getLocationData];
//    [self testData];
   
    
}

- (void)initiCloud
{
    [[iCloud sharedCloud] setDelegate:self];
    [[iCloud sharedCloud] setVerboseLogging:YES];
    [[iCloud sharedCloud] setupiCloudDocumentSyncWithUbiquityContainer:nil];
    BOOL cloudIsAvailable = [[iCloud sharedCloud] checkCloudAvailability];
    if (cloudIsAvailable) {
        [[iCloud sharedCloud] retrieveCloudDocumentWithName:@"token.ext" completion:^(UIDocument *cloudDocument, NSData *documentData, NSError *error) {
            NSLog(@"token error = %@",error.localizedDescription);
            if (!error) {
                NSData *tokenData = documentData;
                if (tokenData && tokenData.length > 5) {
                    NSString *token = [[NSString alloc] initWithData:tokenData encoding:NSUTF8StringEncoding];
                    NSLog(@"real Token = %@",token);
                    [userdefault setObject:token forKey:kiCloudToken];
                    [userdefault synchronize];
                }else{
                    NSString *token = [userdefault objectForKey:kiCloudToken];
                    [[iCloud sharedCloud] saveAndCloseDocumentWithName:@"token.ext" withContent:[token dataUsingEncoding:NSUTF8StringEncoding] completion:^(UIDocument *cloudDocument, NSData *documentData, NSError *error) {
                        NSLog(@"Token .ext .error = %@",error.localizedDescription);
                        if (!error) {
                            NSLog(@"saved Token = %@",[[NSString alloc] initWithData:documentData encoding:NSUTF8StringEncoding]);
                        }
                    }];
                }
                
            }
            [[iCloud sharedCloud] retrieveCloudDocumentWithName:@"image.ext" completion:^(UIDocument *cloudDocument, NSData *documentData, NSError *error) {
                NSLog(@"Image icloud error = %@",error.localizedDescription);
                if (!error) {
                    NSString *fileName = [cloudDocument.fileURL lastPathComponent];
                    NSData *fileData = documentData;
                    [userdefault setObject:fileData forKey:kHeaderImage];
                    [userdefault synchronize];
                }
                [self login];
            }];
        }];
        
        
    }else{
        [self login];
    }
    
}

- (void)iCloudDidFinishInitializingWitUbiquityToken:(id)cloudToken withUbiquityContainer:(NSURL *)ubiquityContainer
{
    NSLog(@"cloudToken = %@ URL = %@",cloudToken,ubiquityContainer.description);
}

- (void)iCloudFilesDidChange:(NSMutableArray *)files withNewFileNames:(NSMutableArray *)fileNames
{

}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 200, 44)];
    title.text = @"Wink";
    title.textAlignment = NSTextAlignmentCenter;
    title.font = fontWithSize(23);
    title.textColor = [UIColor whiteColor];
    self.navigationItem.titleView = title;
}

- (void)testData
{
    [CommonUtil defaultUtil].userId = @"1";
    [userdefault setObject:@1 forKey:kUserId];
//    [userdefault setObject:userToken forKey:kUserToken];
    [userdefault synchronize];
    RequestViewController *rVC = [self.storyboard instantiateViewControllerWithIdentifier:@"RequestVC"];
    [self.navigationController pushViewController:rVC animated:NO];
}

- (void)changeToken
{
    NSString *token = (NSString *)[[NSFileManager defaultManager] ubiquityIdentityToken];
    if (token) {
        [userdefault setObject:token forKey:kiCloudToken];
        [userdefault synchronize];
    }

}

- (void)login{
    NetworkingManager *manage = [NetworkingManager manager];
    [manage loginSuccess:^(NSURLSessionDataTask *task, id resp) {
        NSDictionary *dic = (NSDictionary *)resp;
        NSNumber *stateNum = [dic objectForKey:@"state"];
        NSLog(@"Login dict = %@",dic);
        if (stateNum.intValue == 10000) {
            NSLog(@"Login Success");
            NSNumber *userId = [dic objectForKey:@"userid"];
            NSLog(@"userid = %@",userId);
            NSString *userToken = [dic objectForKey:@"usertoken"];
            NSNumber *gender = [dic objectForKey:@"gender"];
            [CommonUtil defaultUtil].userToken = userToken;
            [CommonUtil defaultUtil].userId = [NSString stringWithFormat:@"%ld",userId.integerValue];
            [userdefault setObject:gender forKey:kGender];
            [userdefault setObject:userId forKey:kUserId];
            [userdefault setObject:userToken forKey:kUserToken];
            [userdefault synchronize];
            BOOL cloudIsAvailable = [[iCloud sharedCloud] checkCloudAvailability];
            if (cloudIsAvailable) {
                [[iCloud sharedCloud] retrieveCloudDocumentWithName:@"Data1.ext" completion:^(UIDocument *cloudDocument, NSData *documentData, NSError *error) {
                    NSLog(@"data icloud error = %@",error.localizedDescription);
                    if (!error) {
                         NSString *key = [NSString stringWithFormat:@"%d%@",((NSNumber *)[userdefault objectForKey:kUserId]).intValue,kReceiptData];
                        NSString *fileName = [cloudDocument.fileURL lastPathComponent];
                        NSData *fileData = documentData;
                        NSString *dataString = [[NSString alloc] initWithData:fileData encoding:NSUTF8StringEncoding];
                        [userdefault setObject:dataString forKey:key];
                        [userdefault synchronize];
                    }
                    [[StoreObserver sharedInstance] restoreAutoResult:^{
                        RequestViewController *rVC = [self.storyboard instantiateViewControllerWithIdentifier:@"RequestVC"];
                        [self.navigationController pushViewController:rVC animated:NO];
                    }];
                    
                }];
            }else{
                [[StoreObserver sharedInstance] restoreAutoResult:^{
                    RequestViewController *rVC = [self.storyboard instantiateViewControllerWithIdentifier:@"RequestVC"];
                    [self.navigationController pushViewController:rVC animated:NO];
                }];

            }
           

        }else if (stateNum.intValue == 10002){
//            [self.loadingView removeFromSuperview];
            ViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"ViewController"];
            [self.navigationController pushViewController:vc animated:NO];
            
        }else if (stateNum.intValue == 10010){
            NSNumber *b_time = [dic objectForKey:@"b_time"];
            NSNumber *e_time = [dic objectForKey:@"e_time"];
            [userdefault setObject:b_time forKey:kFBeginTime];
            [userdefault setObject:e_time forKey:kEndTime];
            [userdefault synchronize];
            
            //被ban
            _bannerView = [[BannedView alloc] initWithFrame:CGRectZero];
            __weak LaunchLoadingViewController *weakSelf = self;
            _bannerView.linkClicked = ^(void){
                TermsViewController *termsVC = [[TermsViewController alloc] init];
                [weakSelf.navigationController pushViewController:termsVC animated:YES];
            };
           _bannerView.apperaClicked = ^(void){
                NSLog(@"Appeal");
            };
            
            [self.view addSubview:_bannerView];
            [self startFire];
        }
    } error:^(NSError *err) {
        [[[UIAlertView alloc] initWithTitle:nil message:LocalizedString(@"network_error", nil) delegate:self cancelButtonTitle:LocalizedString(@"ok", nil) otherButtonTitles:nil, nil] show];
        NSLog(@"error = %@",err.localizedDescription);
    }];
    
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    [self login];
}

- (void)startFire
{
    [self.bannedTimer invalidate];
    self.bannedTimer = [NSTimer scheduledTimerWithTimeInterval:600 target:self selector:@selector(timerFireMethod:) userInfo:nil repeats:YES];
}


- (void)getLocationData
{ 
    //定位管理器
    _locationManager=[[CLLocationManager alloc]init];
    [CommonUtil defaultUtil].locationManager = _locationManager;
    if (![CLLocationManager locationServicesEnabled]) {
        NSLog(@"定位服务当前可能尚未打开，请设置打开！");
        return;
    }
    
    //如果没有授权则请求用户授权
    if ([CLLocationManager authorizationStatus]==kCLAuthorizationStatusNotDetermined){
        if ([self.locationManager respondsToSelector:@selector(requestAlwaysAuthorization)]) {
            [_locationManager requestWhenInUseAuthorization];
        }else{
            [_locationManager startUpdatingLocation];
        }
    }else if([CLLocationManager authorizationStatus]==kCLAuthorizationStatusDenied){
       
    }
    //设置代理
    _locationManager.delegate=self;
    //设置定位精度
    _locationManager.desiredAccuracy=kCLLocationAccuracyBest;
    //定位频率,每隔多少米定位一次
    CLLocationDistance distance=500.0;//十米定位一次
    _locationManager.distanceFilter=distance;
    //启动跟踪定位
    [_locationManager startUpdatingLocation];
}

#pragma mark - CoreLocation 代理
#pragma mark 跟踪定位代理方法，每次位置发生变化即会执行（只要定位到相应位置）
//可以通过模拟器设置一个虚拟位置，否则在模拟器中无法调用此方法
-(void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations{
    CLLocation *location=[locations firstObject];//取出第一个位置
    CLLocationCoordinate2D coordinate=location.coordinate;//位置坐标
    //经度
    CGFloat longitude = coordinate.longitude;
    //纬度
    CGFloat latitude = coordinate.latitude;
    [userdefault setObject:@(longitude) forKey:kLongitude];
    [userdefault setObject:@(latitude) forKey:kLatitude];
    [userdefault synchronize];
    NSLog(@"经度：%f,纬度：%f,海拔：%f,航向：%f,行走速度：%f",coordinate.longitude,coordinate.latitude,location.altitude,location.course,location.speed);
    //获取当前所在的城市名
    CLGeocoder *geocoder = [[CLGeocoder alloc] init];
    //根据经纬度反向地理编译出地址信息
    [geocoder reverseGeocodeLocation:location completionHandler:^(NSArray *array, NSError *error)
     {
         if (array.count > 0)
         {
             CLPlacemark *placemark = [array objectAtIndex:0];
             
             //将获得的所有信息显示到label上
//             self.location.text = placemark.name;
             //获取城市
             NSString *city = placemark.locality;
             if (!city) {
                 //四大直辖市的城市信息无法通过locality获得，只能通过获取省份的方法来获得（如果city为空，则可知为直辖市）
                 city = placemark.administrativeArea;
             }
             NSString *cityInfo = [NSString stringWithFormat:@"%@, %@",city,placemark.country];
             NSLog(@"city = %@,%@", city,placemark.country);
             [userdefault setObject:cityInfo forKey:kCityName];
             [userdefault synchronize];
             
         }
         else if (error == nil && [array count] == 0)
         {
             NSLog(@"No results were returned.");
         }
         else if (error != nil)
         {
             NSLog(@"An error occurred = %@", error);
         }
     }];
    
    
    //如果不需要实时定位，使用完即使关闭定位服务
    [_locationManager stopUpdatingLocation];
}

- (void)timerFireMethod:(NSTimer *)theTimer
{
    //    BOOL timeStart = YES;
    NSCalendar *cal = [NSCalendar currentCalendar];//定义一个NSCalendar对象
    NSDateComponents *endTime = [[NSDateComponents alloc] init];    //初始化目标时间...
    NSDate *today = [NSDate date];    //得到当前时间
    
    NSTimeInterval interval = [today timeIntervalSince1970];
    NSDate *today2 = [NSDate dateWithTimeIntervalSince1970:interval + [CommonUtil defaultUtil].fixTime/1000.f];
    //    NSLog(@"fixtime = %ld",[CommonUtil defaultUtil].fixTime/1000.f);
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    //    NSTimeZone *timezone = [NSTimeZone localTimeZone];
    //    [dateFormatter setTimeZone:timezone];
    [dateFormatter setDateFormat:@"HH"];
    //    NSDate *date = [NSdate date]
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:(((NSNumber *)[userdefault objectForKey:kFEndTime]).integerValue) / 1000];
    //    NSDate *dateString = [dateFormatter
    //    NSDate *dateString = [dateFormatter dateFromString:todate];
    
    NSString *overdate = [dateFormatter stringFromDate:date];
    //        NSLog(@"overdate = %@",overdate);
    static int year;
    static int month;
    static int day;
    static int hour;
    static int minute;
    static int second;
    if(_timerStart) {//从NSDate中取出年月日，时分秒，但是只能取一次
        year = [[overdate substringWithRange:NSMakeRange(0, 4)] intValue];
        month = [[overdate substringWithRange:NSMakeRange(5, 2)] intValue];
        day = [[overdate substringWithRange:NSMakeRange(8, 2)] intValue];
        hour = [[overdate substringWithRange:NSMakeRange(11, 2)] intValue];
        minute = [[overdate substringWithRange:NSMakeRange(14, 2)] intValue];
        second = [[overdate substringWithRange:NSMakeRange(17, 2)] intValue];
        _timerStart = NO;
    }
    
    [endTime setYear:year];
    [endTime setMonth:month];
    [endTime setDay:day];
    [endTime setHour:hour];
    [endTime setMinute:minute];
    [endTime setSecond:second];
    NSDate *overTime = [cal dateFromComponents:endTime]; //把目标时间装载入date
    //用来得到具体的时差，是为了统一成北京时间
    unsigned int unitFlags = NSYearCalendarUnit| NSMonthCalendarUnit| NSDayCalendarUnit| NSHourCalendarUnit| NSMinuteCalendarUnit| NSSecondCalendarUnit;
    NSDateComponents *d = [cal components:unitFlags fromDate:today2 toDate:overTime options:0];
    NSString *t = [NSString stringWithFormat:@"%ld", (long)[d day]];
    NSString *h = [NSString stringWithFormat:@"%ld", (long)[d hour]];
    NSString *fen = [NSString stringWithFormat:@"%ld", (long)[d minute]];
    if([d minute] < 10) {
        fen = [NSString stringWithFormat:@"0%ld",(long)[d minute]];
    }
    NSString *miao = [NSString stringWithFormat:@"%ld", (long)[d second]];
    if([d second] < 10) {
        miao = [NSString stringWithFormat:@"0%ld",(long)[d second]];
    }
    //        NSLog(@"===%@天 %@:%@:%@",t,h,fen,miao);
    //    [self.fdv.timeLabel setText:[NSString stringWithFormat:@"%@天 %@:%@:%@",t,h,fen,miao]];
    [self.bannerView.timeLabel setText:[NSString stringWithFormat:@"%@ %@",overdate,LocalizedString(@"hours",nil)]];
    if([d second] >= 0) {
        
        //计时尚未结束，do_something
        //        [_longtime setText:[NSString stringWithFormat:@"%@:%@:%@",d,fen,miao]];
    }else {
//        [self timeOver];
        //        //计时器失效
        _timerStart = YES;
        [theTimer invalidate];
    }
    
}



@end

//
//  NetworkManager.h
//  DatingForDating
//
//  Created by MAXToooNG on 16/3/29.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AFNetworking/AFHTTPSessionManager.h>

@interface NetworkingManager : NSObject
@property (nonatomic, strong) AFJSONRequestSerializer *requestSerializer;
@property (nonatomic, strong) AFHTTPSessionManager *sessionManager;

+ (NetworkingManager *)manager;

- (void)loginSuccess:(void(^)(NSURLSessionDataTask *task,id resp))suc error:(void(^)(NSError *err))e;

- (void)registWithGender:(NSInteger)gender uniquToken:(NSString *)uniquToken pushToken:(NSString *)pushToken success:(void (^)(NSURLSessionDataTask *task, id responseObject))success error:(void (^)(NSError *))e1;

- (void)uploadImageWithData:(NSData *)imageData progress:(void(^)(NSProgress *progress))progress success:(void (^)(NSURLSessionDataTask *, id))success error:(void (^)(NSError *err))e;

- (void)getDatingListSuccess:(void(^)(NSURLSessionDataTask *task, id responseObject))success error:(void(^)(NSError *e))err;

- (void)queryRequestInfoWithRequestId:(NSNumber *)requestId success:(void(^)(NSURLSessionDataTask *task,id responseObject))success error:(void(^)(NSError *err))e;

- (void)doLikeWithFromRequestId:(NSNumber *)fromRequestId toUserId:(NSNumber *)userId toRequestid:(NSNumber *)toRequestid likeOrNot:(NSInteger)likeOrNot success:(void(^)(NSURLSessionDataTask *task, id responseObject))success error:(void(^)(NSError *err))e;

- (void)deleteDatingRequestWithRequestId:(NSNumber *)requestId success:(void(^)(NSURLSessionDataTask *task, id responseObject))success error:(void(^)(NSError *err))e;

- (void)getSystemConfigureSuccess:(void(^)(NSURLSessionDataTask *task, id responseObject))success error:(void(^)(NSError *err))e;

- (void)uploadMessageFromRequestId:(NSNumber *)fromRequestId toUserId:(NSNumber *)toUserId toRequestid:(NSNumber *)toRequestid content:(NSString *)content success:(void(^)(NSURLSessionDataTask *task, id responseObject))success error:(void(^)(NSError *err))e;

- (void)uploadMessageImageWithData:(NSData *)data success:(void(^)(NSURLSessionDataTask *task,id responseObject))success error:(void(^)(NSError *err))e;

- (void)getAllLikedUsUserInfoWithRequestId:(NSNumber *)requestId success:(void(^)(NSURLSessionDataTask *task,id responseObject))success error:(void(^)(NSError *err))e;

- (void)reportImageFromRequestId:(NSNumber *)fromRequestId toUserId:(NSNumber *)userId toRequestid:(NSNumber *)toRequestid imageUrl:(NSString *)url success:(void(^)(NSURLSessionDataTask *task, id responseObject))success error:(void(^)(NSError *err))e;

- (void)reportUserFromRequestId:(NSNumber *)fromRequestId toUserId:(NSNumber *)userId success:(void(^)(NSURLSessionDataTask *task, id responseObject))success error:(void(^)(NSError *err))e;

- (void)queryMatchingRequestsSuccess:(void(^)(NSURLSessionDataTask *task, id repsonseObject))success error:(void(^)(NSError *err))e;

- (void)cancelMatchWithMatchId:(NSNumber *)matchId success:(void(^)(NSURLSessionDataTask *task, id responseObject))success error:(void(^)(NSError *err))e;

- (void)syncTimeSuccess:(void(^)(NSURLSessionDataTask *task, id respsonseObject))success error:(void(^)(NSError *err))e;
//- (void)registerUserSuccess:(void(^)(NSURLSessionDataTask *task, id responseObject))success andFailed:(void (^)(NSURLSessionDataTask *task, NSError *error))failure;
@end

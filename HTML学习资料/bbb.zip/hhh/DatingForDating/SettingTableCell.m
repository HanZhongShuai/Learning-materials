//
//  SettingTableCell.m
//  DatingForDating
//
//  Created by MAXToooNG on 16/4/22.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import "SettingTableCell.h"
@interface SettingTableCell()

@end

@implementation SettingTableCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self.lineView removeFromSuperview];
        self.lineView = [[UIView alloc] initWithFrame:CGRectMake(0, 57, windowWidth(), 1)];
        self.detailLabel = [[UILabel alloc] initWithFrame:CGRectMake(58, 2, windowWidth() - 80, 54)];
        
        [self.contentView addSubview:self.detailLabel];
        self.lineView.backgroundColor = colorWithHexString(@"#666666");
        [self.contentView addSubview:self.lineView];
    }
    return self;
}

@end

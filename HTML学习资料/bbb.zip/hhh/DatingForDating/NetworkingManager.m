//
//  NetworkManager.m
//  DatingForDating
//
//  Created by MAXToooNG on 16/3/29.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import "NetworkingManager.h"
#import "SFHFKeychainUtils.h"
#import "Utility.h"

#define kUrl @"192.168.0.88:8088"
//#define kUrl @"45.79.8.16:8081"

@interface NetworkingManager()
//@property (nonatomic, assign) void(^id)(successReponse);

@end

@implementation NetworkingManager

static NetworkingManager *manager = nil;

+ (NetworkingManager *)manager
{
    if (manager == nil) {
        manager = [[NetworkingManager alloc] init];
        manager.sessionManager = [[AFHTTPSessionManager alloc] init];
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        manager.sessionManager.requestSerializer = manager.requestSerializer;
    }
    return manager;
}


- (void)registWithGender:(NSInteger)gender uniquToken:(NSString *)uniquToken pushToken:(NSString *)pushToken success:(void (^)(NSURLSessionDataTask *task, id responseObject))success error:(void (^)(NSError *))e
{
    //plat          int
    //appid       string
    //gender     int
    //deviceid   string
    //icloudToken string
    //pushToken string
    //countryid  string
    //language  string
    //timezone  int
    //lon            double
    //lat             double
    //isfree        int
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"Z"];
    NSTimeZone *timeZone = [NSTimeZone systemTimeZone];
    [dateFormatter setTimeZone:timeZone];
    NSDate *date = [NSDate date];
    //+0800
    NSString *timeZoneZ = [dateFormatter stringFromDate:date];
    NSRange range = NSMakeRange(0, 3);
    //+08
    NSString *timeZoneInt = [timeZoneZ substringWithRange:range];
    //    NSLog(@"timeZone = %@",timeZoneInt);
    
    //en
    NSArray *languageArray = [NSLocale preferredLanguages];
    NSString *language = [languageArray objectAtIndex:0];
    if ([language rangeOfString:@"zh-Hans"].location != NSNotFound) {
        language = @"zh-Hans";
    }else if([language rangeOfString:@"zh-Hant"].location != NSNotFound){
        language = @"zh-Hant";
    }else{
        NSArray *array = [language componentsSeparatedByString:@"-"];
        if (array) {
            language = [array firstObject];
        }
        
    }
    NSLog(@"language：%@", language);
    //US
    NSLocale *locale = [NSLocale currentLocale];
    NSString *country = [[[locale localeIdentifier] componentsSeparatedByString:@"_"] lastObject];
    
    if (!uniquToken) {
        uniquToken = [NSString stringWithFormat:@"tmp_%@",[CommonUtil defaultUtil].idfv];
    }
    NSNumber *lon = [userdefault objectForKey:kLongitude];
    NSNumber *lat = [userdefault objectForKey:kLatitude];
    if (!lon) {
        lon = @0;
    }
    
    if (!lat) {
        lat = @0;
    }
    
    NSMutableDictionary *parmDic = [[NSMutableDictionary alloc] init];
    [parmDic setObject:@1 forKey:@"plat"];
    [parmDic setObject:kAppleId forKey:@"appid"];
    [parmDic setObject:[NSNumber numberWithInteger:gender] forKey:@"gender"];
    [parmDic setObject:[CommonUtil defaultUtil].idfv forKey:@"deviceid"];
    [parmDic setObject:uniquToken forKey:@"icloudtoken"];
    [parmDic setObject:pushToken forKey:@"pushtoken"];
    [parmDic setObject:country forKey:@"countryid"];
    [parmDic setObject:language forKey:@"language"];
    [parmDic setObject:timeZoneInt forKey:@"timezone"];
    [parmDic setObject:lon forKey:@"lon"];
    [parmDic setObject:lat forKey:@"lat"];
    [parmDic setObject:@1 forKey:@"isfee"];
    NSString *jsonString = [self dictionaryToJson:parmDic];
    NSString *desJson = [Utility encryptUseDES:jsonString key:@"$Nu&a*6M"];
    NSDictionary *finalDic = [[NSDictionary alloc] initWithObjectsAndKeys:desJson,@"parm", nil];
    AFHTTPSessionManager *manager = self.sessionManager;
    NSString *url = [NSString stringWithFormat:@"http://%@/DatingWeb/userinfo/userRegister.do",kUrl];
    [manager POST:url parameters:finalDic progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        success(task,responseObject);
        NSDictionary *dic = (NSDictionary *)responseObject;
        NSLog(@"success,  dic = %@",dic);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        e(error);
        NSLog(@"error = %@",error.localizedDescription);
    }];
}

- (void)loginSuccess:(void(^)(NSURLSessionDataTask *task,id resp))suc error:(void(^)(NSError *err))e{
    NSNumber *userId = [userdefault objectForKey:kUserId];
    if (!userId) {
        userId = @0;
    }
    NSString *userToken = [userdefault objectForKey:kUserToken];
    if (!userToken) {
        userToken = @"";
    }
    NSString *icloudToken = [userdefault objectForKey:kiCloudToken];
    if (!icloudToken) {
        icloudToken = [NSString stringWithFormat:@"tmp_%@",[CommonUtil defaultUtil].idfv];
    }
    NSMutableDictionary *parmDic = [[NSMutableDictionary alloc] init];
    [parmDic setObject:@1 forKey:@"plat"];
    [parmDic setObject:kAppleId forKey:@"appid"];
    [parmDic setObject:[CommonUtil defaultUtil].idfv forKey:@"deviceid"];
    [parmDic setObject:userId forKey:@"userid"];
    [parmDic setObject:userToken forKey:@"usertoken"];
    [parmDic setObject:icloudToken forKey:@"icloudtoken"];
    
    NSString *jsonString = [self dictionaryToJson:parmDic];
    NSLog(@"jsonString = %@",jsonString);
    NSString *desJson = [Utility encryptUseDES:jsonString key:@"$Nu&a*6M"];
    
    NSDictionary *finalParms = [[NSDictionary alloc] initWithObjectsAndKeys:desJson,@"parm", nil];
    AFHTTPSessionManager *manager = self.sessionManager;
    NSString *url = [NSString stringWithFormat:@"http://%@/DatingWeb/userinfo/userLogin.do",kUrl];
    [manager POST:url parameters:finalParms progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSDictionary *dic = (NSDictionary *)responseObject;
        NSLog(@"success,  dic = %@",dic);
        suc(task,responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"error = %@",error.localizedDescription);
        e(error);
    }];
    
}

- (NSString*)dictionaryToJson:(NSDictionary *)dic
{
//    NSLog(@"dict = %@",dic);
    NSError *parseError = nil;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dic options:NSJSONWritingPrettyPrinted error:&parseError];
    return [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
}

- (void)uploadImageWithData:(NSData *)imageData progress:(void(^)(NSProgress *progress))progress success:(void (^)(NSURLSessionDataTask *, id))success error:(void (^)(NSError *err))e
{
    NSNumber *userId = [userdefault objectForKey:kUserId];
    if (!userId) {
        userId = @0;
    }
    NSString *userToken = [userdefault objectForKey:kUserToken];
    if (!userToken) {
        userToken = @"";
    }
    NSNumber *lon = [userdefault objectForKey:kLongitude];
    NSNumber *lat = [userdefault objectForKey:kLatitude];
    NSString *pushToken = [userdefault objectForKey:kPushToken];
    if (!pushToken) {
        pushToken = @"";
    }
    if (!lon) {
        lon = @0;
    }
    if (!lat) {
        lat = @0;
    }
    
    NSMutableDictionary *parmDic = [[NSMutableDictionary alloc] init];
    [parmDic setObject:@1 forKey:@"plat"];
    [parmDic setObject:kAppleId forKey:@"appid"];
    [parmDic setObject:userId forKey:@"userid"];
    [parmDic setObject:userToken forKey:@"usertoken"];
    [parmDic setObject:lon forKey:@"lon"];
    [parmDic setObject:lat forKey:@"lat"];
    [parmDic setObject:pushToken forKey:@"pushtoken"];
    
    NSString *jsonString = [self dictionaryToJson:parmDic];
    NSLog(@"jsonString = %@",jsonString);
    NSString *desJson = [Utility encryptUseDES:jsonString key:kDKey];
    
    NSDictionary *finalParms = [[NSDictionary alloc] initWithObjectsAndKeys:desJson,@"parm", nil];
    AFHTTPSessionManager *manager = self.sessionManager;
    NSString *url = [NSString stringWithFormat:@"http://%@/DatingWeb/request/userRequest.do?method=upload",kUrl];
    [manager POST:url parameters:finalParms constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        // 上传文件
//        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
//        formatter.dateFormat = @"yyyyMMddHHmmss";
//        NSString *str = [formatter stringFromDate:[NSDate date]];
//        NSString *fileName = [NSString stringWithFormat:@"%@.jpg", str];
        
        [formData appendPartWithFileData:imageData name:@"picfile" fileName:@"picfile" mimeType:@"image/jpeg"];
    } progress:^(NSProgress * _Nonnull uploadProgress) {
        progress(uploadProgress);
//        NSLog(@"uploadProgress = %f",uploadProgress.)
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        success(task,responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        e(error);
    }];
    
}

- (void)getDatingListSuccess:(void (^)(NSURLSessionDataTask *, id))success error:(void (^)(NSError *))err
{
    NSNumber *userId = [userdefault objectForKey:kUserId];
    if (!userId) {
        userId = @0;
    }
    NSNumber *requestId = [userdefault objectForKey:kRequestId];
    if (!requestId) {
        requestId = @0;
    }
    NSString *userToken = [userdefault objectForKey:kUserToken];
    if (!userToken) {
        userToken = @"";
    }
    NSNumber *lon = [userdefault objectForKey:kLongitude];
    NSNumber *lat = [userdefault objectForKey:kLatitude];
    NSString *pushToken = [userdefault objectForKey:kPushToken];
    if (!pushToken) {
        pushToken = @"";
    }
    NSNumber *gender = [userdefault objectForKey:kGender];
    if (!gender) {
        gender = @0;
    }
    NSMutableDictionary *parmDic = [[NSMutableDictionary alloc] init];
    [parmDic setObject:@1 forKey:@"plat"];
    [parmDic setObject:kAppleId forKey:@"appid"];
    [parmDic setObject:userId forKey:@"userid"];
    [parmDic setObject:userToken forKey:@"usertoken"];
    [parmDic setObject:lon forKey:@"lon"];
    [parmDic setObject:lat forKey:@"lat"];
    [parmDic setObject:gender forKey:@"gender"];
    [parmDic setObject:requestId forKey:@"requestid"];
    
    NSString *jsonString = [self dictionaryToJson:parmDic];
    NSLog(@"jsonString = %@",jsonString);
    NSString *desJson = [Utility encryptUseDES:jsonString key:kDKey];
    
    NSDictionary *finalParms = [[NSDictionary alloc] initWithObjectsAndKeys:desJson,@"parm", nil];
    NSString *url = [NSString stringWithFormat:@"http://%@/DatingWeb/request/queryRequests.do",kUrl];
    AFHTTPSessionManager *manager = self.sessionManager;
    [manager POST:url parameters:finalParms progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        success(task,responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        err(error);
    }];

}

- (void)queryRequestInfoWithRequestId:(NSNumber *)requestId success:(void (^)(NSURLSessionDataTask *, id))success error:(void (^)(NSError *))e
{
    NSNumber *userId = [userdefault objectForKey:kUserId];
    if (!userId) {
        userId = @0;
    }
    NSString *userToken = [userdefault objectForKey:kUserToken];
    if (!userToken) {
        userToken = @"";
    }
    NSNumber *requestNumber = requestId;
    if (!requestNumber) {
        requestNumber = @0;
    }

    NSMutableDictionary *parmDic = [[NSMutableDictionary alloc] init];
    [parmDic setObject:@1 forKey:@"plat"];
    [parmDic setObject:kAppleId forKey:@"appid"];
    [parmDic setObject:userId forKey:@"userid"];
    [parmDic setObject:userToken forKey:@"usertoken"];
    [parmDic setObject:requestNumber forKey:@"requestid"];
    NSString *jsonString = [self dictionaryToJson:parmDic];
    NSLog(@"jsonString = %@",jsonString);
    NSString *desJson = [Utility encryptUseDES:jsonString key:kDKey];
    
    NSDictionary *finalParms = [[NSDictionary alloc] initWithObjectsAndKeys:desJson,@"parm", nil];
    NSString *url = [NSString stringWithFormat:@"http://%@/DatingWeb/request/queryRequest.do",kUrl];
    AFHTTPSessionManager *manager = self.sessionManager;
    [manager POST:url parameters:finalParms progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        success(task, responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        e(error);
    }];
}

- (void)doLikeWithFromRequestId:(NSNumber *)fromRequestId toUserId:(NSNumber *)toUserId toRequestid:(NSNumber *)toRequestid likeOrNot:(NSInteger)likeOrNot success:(void (^)(NSURLSessionDataTask *, id))success error:(void (^)(NSError *))e
{
    NSNumber *fromUserId = [userdefault objectForKey:kUserId];
    if (!fromUserId) {
        fromUserId = @0;
    }
    NSString *fromUserToken = [userdefault objectForKey:kUserToken];
    if (!fromUserToken) {
        fromUserToken = @"";
    }
    NSNumber *requestNumber = fromRequestId;
    if (!requestNumber) {
        requestNumber = @0;
    }
    NSNumber *like = [NSNumber numberWithInteger:likeOrNot];
    NSMutableDictionary *parmDic = [[NSMutableDictionary alloc] init];
    [parmDic setObject:@1 forKey:@"plat"];
    [parmDic setObject:kAppleId forKey:@"appid"];
    [parmDic setObject:fromUserId forKey:@"userid1"];
    [parmDic setObject:toUserId forKey:@"userid2"];
    [parmDic setObject:fromUserToken forKey:@"usertoken1"];
    [parmDic setObject:requestNumber forKey:@"requestid1"];
    [parmDic setObject:toRequestid forKey:@"requestid2"];
    [parmDic setObject:like forKey:@"status"];
    NSString *jsonString = [self dictionaryToJson:parmDic];
    NSLog(@"jsonString = %@",jsonString);
    NSString *desJson = [Utility encryptUseDES:jsonString key:kDKey];
    NSString *url = [NSString stringWithFormat:@"http://%@/DatingWeb/like/likeRequest.do",kUrl];
    NSDictionary *finalParms = [[NSDictionary alloc] initWithObjectsAndKeys:desJson,@"parm", nil];
    AFHTTPSessionManager *manager = self.sessionManager;
    [manager POST:url parameters:finalParms progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        success(task, responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        e(error);
    }];
}

- (void)deleteDatingRequestWithRequestId:(NSNumber *)requestId success:(void (^)(NSURLSessionDataTask *, id))success error:(void (^)(NSError *))e
{
    NSNumber *userId = [userdefault objectForKey:kUserId];
    if (!userId) {
        userId = @0;
    }
    NSString *userToken = [userdefault objectForKey:kUserToken];
    if (!userToken) {
        userToken = @"";
    }
    NSNumber *requestNumber = requestId;
    if (!requestNumber) {
        requestNumber = @0;
    }
    
    NSMutableDictionary *parmDic = [[NSMutableDictionary alloc] init];
    [parmDic setObject:@1 forKey:@"plat"];
    [parmDic setObject:kAppleId forKey:@"appid"];
    [parmDic setObject:userId forKey:@"userid"];
    [parmDic setObject:userToken forKey:@"usertoken"];
    [parmDic setObject:requestNumber forKey:@"requestid"];
    NSString *jsonString = [self dictionaryToJson:parmDic];
    NSLog(@"jsonString = %@",jsonString);
    NSString *desJson = [Utility encryptUseDES:jsonString key:kDKey];
    
    NSDictionary *finalParms = [[NSDictionary alloc] initWithObjectsAndKeys:desJson,@"parm", nil];
    NSString *url = [NSString stringWithFormat:@"http://%@/DatingWeb/request/deleteRequest.do",kUrl];
    AFHTTPSessionManager *manager = self.sessionManager;
    [manager POST:url parameters:finalParms progress:^(NSProgress * _Nonnull uploadProgress) {
        } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            success(task,responseObject);
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            e(error);
    }];
}

- (void)getSystemConfigureSuccess:(void (^)(NSURLSessionDataTask *, id))success error:(void (^)(NSError *))e
{
    NSNumber *userId = [userdefault objectForKey:kUserId];
    if (!userId) {
        userId = @0;
    }
    NSString *userToken = [userdefault objectForKey:kUserToken];
    if (!userToken) {
        userToken = @"";
    }
    NSMutableDictionary *parmDic = [[NSMutableDictionary alloc] init];
    [parmDic setObject:@1 forKey:@"plat"];
    [parmDic setObject:kAppleId forKey:@"appid"];
    [parmDic setObject:userId forKey:@"userid"];
    [parmDic setObject:userToken forKey:@"usertoken"];
    NSString *jsonString = [self dictionaryToJson:parmDic];
    NSLog(@"jsonString = %@",jsonString);
    NSString *desJson = [Utility encryptUseDES:jsonString key:kDKey];
    
    NSDictionary *finalParms = [[NSDictionary alloc] initWithObjectsAndKeys:desJson,@"parm", nil];
    NSString *url = [NSString stringWithFormat:@"http://%@/DatingWeb/userinfo/getSystemConfigure.do",kUrl];
    AFHTTPSessionManager *manager = self.sessionManager;
    [manager POST:url parameters:finalParms progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        success(task,responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        e(error);
    }];
}
/**
 *  聊天日志上传
 *
 *  @param fromRequestId 发送者请求 Id
 *  @param toUserId       接收者 UserId
 *  @param toRequestid   接收者 请求 id
 *  @param content        内容
 *  @param success        success
 *  @param e             error
 */
- (void)uploadMessageFromRequestId:(NSNumber *)fromRequestId toUserId:(NSNumber *)toUserId toRequestid:(NSNumber *)toRequestid content:(NSString *)content success:(void (^)(NSURLSessionDataTask *, id))success error:(void (^)(NSError *))e
{
    NSNumber *fromUserId = [userdefault objectForKey:kUserId];
    if (!fromUserId) {
        fromUserId = @0;
    }
//    NSString *fromUserToken = [userdefault objectForKey:kUserToken];
//    if (!fromUserToken) {
//        fromUserToken = @"";
//    }
    NSNumber *requestNumber = fromRequestId;
    if (!requestNumber) {
        requestNumber = @0;
    }
    NSNumber *gender = [userdefault objectForKey:kGender];
    NSMutableDictionary *parmDic = [[NSMutableDictionary alloc] init];
    [parmDic setObject:@1 forKey:@"plat"];
    [parmDic setObject:kAppleId forKey:@"appid"];
    [parmDic setObject:fromUserId forKey:@"userid1"];
    [parmDic setObject:toUserId forKey:@"userid2"];
//    [parmDic setObject:fromUserToken forKey:@"usertoken1"];
    [parmDic setObject:requestNumber forKey:@"requestid1"];
    [parmDic setObject:toRequestid forKey:@"requestid2"];
//    [parmDic setObject:gender forKey:@"gender"];
    [parmDic setObject:content forKey:@"content"];
    NSString *jsonString = [self dictionaryToJson:parmDic];
    NSLog(@"jsonString = %@",jsonString);
    NSString *desJson = [Utility encryptUseDES:jsonString key:kDKey];
//    NSString *test = [Utility encryptStr:jsonString];
//    NSLog(@"test = %@",test);
//    NSLog(@"test result = %@",[Utility decryptStr:desJson]);
    
    NSDictionary *finalParms = [[NSDictionary alloc] initWithObjectsAndKeys:desJson,@"parm", nil];
    NSString *url = [NSString stringWithFormat:@"http://%@/DatingWeb/request/uploadContent.do",kUrl];
    AFHTTPSessionManager *manager = self.sessionManager;
    [manager POST:url parameters:finalParms progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        success(task, responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        e(error);
    }];

}

- (void)uploadMessageImageWithData:(NSData *)data success:(void (^)(NSURLSessionDataTask *, id))success error:(void (^)(NSError *))e
{
    NSNumber *userId = [userdefault objectForKey:kUserId];
    if (!userId) {
        userId = @0;
    }
    NSMutableDictionary *parmDic = [[NSMutableDictionary alloc] init];
    [parmDic setObject:userId forKey:@"userid"];
 
    NSString *jsonString = [self dictionaryToJson:parmDic];
    NSLog(@"jsonString = %@",jsonString);
    NSString *desJson = [Utility encryptUseDES:jsonString key:kDKey];
    
    NSDictionary *finalParms = [[NSDictionary alloc] initWithObjectsAndKeys:desJson,@"parm", nil];
    NSString *url = [NSString stringWithFormat:@"http://%@/DatingWeb/request/upLoadPic.do?method=upload",kUrl];
    AFHTTPSessionManager *manager = self.sessionManager;
    [manager POST:url parameters:finalParms constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        // 上传文件
        //        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        //        formatter.dateFormat = @"yyyyMMddHHmmss";
        //        NSString *str = [formatter stringFromDate:[NSDate date]];
        //        NSString *fileName = [NSString stringWithFormat:@"%@.jpg", str];
        
        [formData appendPartWithFileData:data name:@"picfile" fileName:@"picfile" mimeType:@"image/jpeg"];
    } progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        success(task,responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        e(error);
    }];

}

- (void)getAllLikedUsUserInfoWithRequestId:(NSNumber *)requestId success:(void (^)(NSURLSessionDataTask *, id))success error:(void (^)(NSError *))e
{
    NSNumber *userId = [userdefault objectForKey:kUserId];
    if (!userId) {
        userId = @0;
    }
    NSString *userToken = [userdefault objectForKey:kUserToken];
    if (!userToken) {
        userToken = @"";
    }
    NSNumber *requestNumber = requestId;
    if (!requestNumber) {
        requestNumber = @0;
    }
    
    NSMutableDictionary *parmDic = [[NSMutableDictionary alloc] init];
    [parmDic setObject:@1 forKey:@"plat"];
    [parmDic setObject:kAppleId forKey:@"appid"];
    [parmDic setObject:userId forKey:@"userid"];
    [parmDic setObject:userToken forKey:@"usertoken"];
    [parmDic setObject:requestNumber forKey:@"requestid"];
    NSString *jsonString = [self dictionaryToJson:parmDic];
    NSLog(@"jsonString = %@",jsonString);
    NSString *desJson = [Utility encryptUseDES:jsonString key:kDKey];
    
    NSDictionary *finalParms = [[NSDictionary alloc] initWithObjectsAndKeys:desJson,@"parm", nil];
    NSString *url = [NSString stringWithFormat:@"http://%@/DatingWeb/like/queryLikeRequests.do" ,kUrl];
    AFHTTPSessionManager *manager = self.sessionManager;
    [manager POST:url parameters:finalParms progress:^(NSProgress * _Nonnull uploadProgress) {
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        success(task,responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        e(error);
    }];

}

/**
 *  举报图片
 *
 *  @param fromRequestId <#fromRequestId description#>
 *  @param userId        <#userId description#>
 *  @param success       <#success description#>
 *  @param e             <#e description#>
 */
- (void)reportImageFromRequestId:(NSNumber *)fromRequestId toUserId:(NSNumber *)userId toRequestid:(NSNumber *)toRequestid imageUrl:(NSString *)url success:(void (^)(NSURLSessionDataTask *, id))success error:(void (^)(NSError *))e
{
    NSNumber *fromUserId = [userdefault objectForKey:kUserId];
    if (!fromUserId) {
        fromUserId = @0;
    }
    NSString *fromUserToken = [userdefault objectForKey:kUserToken];
    if (!fromUserToken) {
        fromUserToken = @"";
    }
    NSNumber *requestNumber = fromRequestId;
    if (!requestNumber) {
        requestNumber = @0;
    }
    NSMutableDictionary *parmDic = [[NSMutableDictionary alloc] init];
    [parmDic setObject:@1 forKey:@"plat"];
    [parmDic setObject:kAppleId forKey:@"appid"];
    [parmDic setObject:fromUserId forKey:@"userid1"];
    [parmDic setObject:userId forKey:@"userid2"];
    [parmDic setObject:fromUserToken forKey:@"usertoken1"];
    [parmDic setObject:requestNumber forKey:@"requestid1"];
    [parmDic setObject:toRequestid forKey:@"requestid2"];
    [parmDic setObject:url forKey:@"url_big2"];
    NSString *jsonString = [self dictionaryToJson:parmDic];
    NSLog(@"jsonString = %@",jsonString);
    NSString *desJson = [Utility encryptUseDES:jsonString key:kDKey];
    
    NSDictionary *finalParms = [[NSDictionary alloc] initWithObjectsAndKeys:desJson,@"parm", nil];
    NSString *urlString = [NSString stringWithFormat:@"http://%@/DatingWeb/userinfo/reportPicture.do",kUrl];
    AFHTTPSessionManager *manager = self.sessionManager;
    [manager POST:urlString parameters:finalParms progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        success(task, responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        e(error);
    }];
}
/**
 *  举报用户
 *
 *  @param fromRequestId 自己的请求 Id
 *  @param userId         对方的请求 Id
 *  @param success        请求成功
 *  @param e              error
 */
- (void)reportUserFromRequestId:(NSNumber *)fromRequestId toUserId:(NSNumber *)userId success:(void (^)(NSURLSessionDataTask *, id))success error:(void (^)(NSError *))e
{
    NSNumber *fromUserId = [userdefault objectForKey:kUserId];
    if (!fromUserId) {
        fromUserId = @0;
    }
    NSString *fromUserToken = [userdefault objectForKey:kUserToken];
    if (!fromUserToken) {
        fromUserToken = @"";
    }
    NSNumber *requestNumber = fromRequestId;
    if (!requestNumber) {
        requestNumber = @0;
    }
    NSMutableDictionary *parmDic = [[NSMutableDictionary alloc] init];
    [parmDic setObject:@1 forKey:@"plat"];
    [parmDic setObject:kAppleId forKey:@"appid"];
    [parmDic setObject:fromUserId forKey:@"userid1"];
    [parmDic setObject:userId forKey:@"userid2"];
    [parmDic setObject:fromUserToken forKey:@"usertoken1"];
    [parmDic setObject:requestNumber forKey:@"requestid1"];
    NSString *jsonString = [self dictionaryToJson:parmDic];
    NSLog(@"jsonString = %@",jsonString);
    NSString *desJson = [Utility encryptUseDES:jsonString key:kDKey];
    
    NSDictionary *finalParms = [[NSDictionary alloc] initWithObjectsAndKeys:desJson,@"parm", nil];
    NSString *url = [NSString stringWithFormat:@"http://%@/DatingWeb/userinfo/reportUser.do",kUrl];
    AFHTTPSessionManager *manager = self.sessionManager;
    [manager POST:url parameters:finalParms progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        success(task, responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        e(error);
    }];

}

- (void)queryMatchingRequestsSuccess:(void (^)(NSURLSessionDataTask *, id))success error:(void (^)(NSError *))e
{
    NSNumber *userId = [userdefault objectForKey:kUserId];
    if (!userId) {
        userId = @0;
    }
    NSString *userToken = [userdefault objectForKey:kUserToken];
    if (!userToken) {
        userToken = @"";
    }
    NSNumber *requestNumber = [userdefault objectForKey:kRequestId];;
    if (!requestNumber) {
        requestNumber = @0;
    }
    
    NSMutableDictionary *parmDic = [[NSMutableDictionary alloc] init];
    [parmDic setObject:@1 forKey:@"plat"];
    [parmDic setObject:kAppleId forKey:@"appid"];
    [parmDic setObject:userId forKey:@"userid"];
    [parmDic setObject:userToken forKey:@"usertoken"];
    [parmDic setObject:requestNumber forKey:@"requestid"];
    NSString *jsonString = [self dictionaryToJson:parmDic];
    NSLog(@"jsonString = %@",jsonString);
    NSString *desJson = [Utility encryptUseDES:jsonString key:kDKey];
    
    NSDictionary *finalParms = [[NSDictionary alloc] initWithObjectsAndKeys:desJson,@"parm", nil];
    NSString *url = [NSString stringWithFormat:@"http://%@/DatingWeb/like/queryMatchingRequests.do",kUrl];
    AFHTTPSessionManager *manager = self.sessionManager;
    [manager POST:url parameters:finalParms progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        success(task,responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        e(error);
    }];

}

- (void)syncTimeSuccess:(void (^)(NSURLSessionDataTask *, id))success error:(void (^)(NSError *))e
{
    NSNumber *userId = [userdefault objectForKey:kUserId];
    if (!userId) {
        userId = @0;
    }
    NSString *userToken = [userdefault objectForKey:kUserToken];
    if (!userToken) {
        userToken = @"";
    }
    NSNumber *requestNumber = [userdefault objectForKey:kRequestId];;
    if (!requestNumber) {
        requestNumber = @0;
    }
    
    NSMutableDictionary *parmDic = [[NSMutableDictionary alloc] init];
    [parmDic setObject:@1 forKey:@"plat"];
    [parmDic setObject:kAppleId forKey:@"appid"];
    [parmDic setObject:userId forKey:@"userid"];
    [parmDic setObject:userToken forKey:@"usertoken"];
    NSString *jsonString = [self dictionaryToJson:parmDic];
    NSLog(@"jsonString = %@",jsonString);
    NSString *desJson = [Utility encryptUseDES:jsonString key:kDKey];
    
    NSDictionary *finalParms = [[NSDictionary alloc] initWithObjectsAndKeys:desJson,@"parm", nil];
    NSString *url = [NSString stringWithFormat:@"http://%@/DatingWeb/userinfo/getSystemtime.do",kUrl];
    AFHTTPSessionManager *manager = self.sessionManager;
    [manager POST:url parameters:finalParms progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        success(task,responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        e(error);
    }];

}

- (void)cancelMatchWithMatchId:(NSNumber *)matchId success:(void (^)(NSURLSessionDataTask *, id))success error:(void (^)(NSError *err))e
{
    NSNumber *userId = [userdefault objectForKey:kUserId];
    if (!userId) {
        userId = @0;
    }
    NSString *userToken = [userdefault objectForKey:kUserToken];
    if (!userToken) {
        userToken = @"";
    }
    NSNumber *requestNumber = [userdefault objectForKey:kRequestId];;
    if (!requestNumber) {
        requestNumber = @0;
    }
    NSNumber *mId = matchId;
    if (!matchId) {
        mId = @0;
    }
    NSMutableDictionary *parmDic = [[NSMutableDictionary alloc] init];
    [parmDic setObject:@1 forKey:@"plat"];
    [parmDic setObject:kAppleId forKey:@"appid"];
    [parmDic setObject:userId forKey:@"userid"];
    [parmDic setObject:userToken forKey:@"usertoken"];
    [parmDic setObject:mId forKey:@"matchingid"];
    NSString *jsonString = [self dictionaryToJson:parmDic];
    NSLog(@"jsonString = %@",jsonString);
    NSString *desJson = [Utility encryptUseDES:jsonString key:kDKey];
    
    NSDictionary *finalParms = [[NSDictionary alloc] initWithObjectsAndKeys:desJson,@"parm", nil];
    NSString *url = [NSString stringWithFormat:@"http://%@/DatingWeb/like/cancelMatching.do",kUrl];
    AFHTTPSessionManager *manager = self.sessionManager;
    [manager POST:url parameters:finalParms progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        success(task, responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        e(error);
    }];
}

- (void)loginWithUniquToken:(NSString *)uniquToken
{

}

@end

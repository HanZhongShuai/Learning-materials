//
//  CommunicationViewController.m
//  DatingForDating
//
//  Created by MAXToooNG on 16/4/13.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import "RequestViewController.h"
#import "CommunicationViewController.h"
#import "MapViewController.h"
#import "IncomingTableViewCell.h"
#import "OutgoingTableViewCell.h"
#import "UIImageView+WebCache.h"
#import "CMethods.h"
#import "CommonUtil.h"
#import <Sinch/Sinch.h>
#import "UIImage+Utility.h"
#import "NetworkingManager.h"
#import "MapViewController.h"
#import "CommonUtil.h"
#import "BigImageViewController.h"
#import "LocationAnnotationViewController.h"
#import "SHowGpsInfoViewController.h"
#import "RCMessage.h"

@interface CommunicationViewController () <UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate, UIActionSheetDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>
@property (nonatomic, strong) UITableView *communicationTableView;
@property (nonatomic, strong) NSMutableArray *dataArray;
@property (nonatomic, strong) NSString *toUserId;
@property (nonatomic, strong) UIView *bottomView;
@property (nonatomic, strong) UITextField *textField;
@property (nonatomic, strong) UIButton *sendBtn;
@property (nonatomic, strong) UIButton *modeBtn;
@property (nonatomic, assign) BOOL timerStart;
@property (nonatomic, strong) UILabel *timeLabel;
@property (nonatomic, strong) NSTimer *communicationTimer;
@property (nonatomic, strong) UIImagePickerController *imagePicker;
@property (nonatomic, strong) NSData *uploadData;
@property (nonatomic, strong) NSString *distance;
@property (nonatomic, strong) NSString *walkTime;
@property (nonatomic, strong) NSString *carTime;
@property (nonatomic, strong) NSString *locationString;

@end

@implementation CommunicationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _timerStart = YES;
    [self setLocationInfo];
    self.toUserId = self.userModel.requestId.stringValue;
    self.dataArray = [[NSMutableArray alloc] initWithArray:self.userModel.communiDataArray];
    NSDate *date = [NSDate date];
    NSTimeInterval interval = [date timeIntervalSince1970];
    if ((interval + [CommonUtil defaultUtil].fixTime/1000.f) > self.userModel.endTime.doubleValue / 1000.f) {
        //timeOUt
        RCMessage *message = [[RCMessage alloc] init];
        message.headers = [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%lu",MessageTimeOut],@"type", nil];
        [self.dataArray addObject:message];
        
    }

    [self initView];
    [self initObsever];
    [[CommonUtil defaultUtil].sinchClient setPushNotificationDisplayName:@""];
    [self startFire];
    [self registerForKeyboardNotifications];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(startFire) name:@"changeTime" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self  selector:@selector(stopFire) name:UIApplicationDidEnterBackgroundNotification object:nil];
    //    [self testNotiData];
    //    [self test];
}

- (void)stopFire
{
    [self.communicationTimer invalidate];
}

- (void)startFire
{
    [self.communicationTimer invalidate];
    self.communicationTimer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(timerFireMethod:) userInfo:nil repeats:YES];
    if (!self.bottomView.superview) {
        self.bottomView.userInteractionEnabled = YES;
        [self.view addSubview:self.bottomView];
    }
}

- (void)setLocationInfo
{
    NetworkingManager *manager = [NetworkingManager manager];
    [manager queryRequestInfoWithRequestId:self.userModel.requestId success:^(NSURLSessionDataTask *task, id responseObject) {
        NSDictionary *result = (NSDictionary *)responseObject;
        NSNumber *stateNum = [result objectForKey:@"state"];
        if (stateNum.intValue == 10000) {
            NSLog(@"querySuccess");
            NSDictionary *userDic = [result objectForKey:@"user_request"];
            if (![userDic isKindOfClass:[NSNull class]]) {
                self.userModel.lon = [userDic objectForKey:@"lon"];
                self.userModel.lat = [userDic objectForKey:@"lat"];
                self.userModel.headViewUrlString_L = [userDic objectForKey:@"url_big"];
                self.userModel.headViewUrlString_S = [userDic objectForKey:@"url_small"];
                [[CommonUtil defaultUtil] getTotalDistanceWalkTimeSuccess:^(NSString *distance, NSString *walkTime) {
                    self.distance = distance;
                    self.walkTime = walkTime;
                } AndCarTime:^(NSString *carTime) {
                    self.carTime = carTime;
                } WithUser:self.userModel];
            }
        }
    } error:^(NSError *err) {
        
    }];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    UIButton *backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [backBtn setImage:[UIImage imageNamed:@"title_ic_back_nor"] forState:UIControlStateNormal];
    [backBtn setImage:[UIImage imageNamed:@"title_ic_back_pre"] forState:UIControlStateNormal];
    [backBtn setFrame:CGRectMake(0, 0, 44, 44)];
    [backBtn addTarget:self action:@selector(back:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc] initWithCustomView:backBtn];
    self.navigationItem.leftBarButtonItems = @[fixBarButtonItem(),leftItem];
    
    UIButton *locationBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [locationBtn setImage:[UIImage imageNamed:@"title_ic_location_nor"] forState:UIControlStateNormal];
    [locationBtn setImage:[UIImage imageNamed:@"title_ic_location_pre"] forState:UIControlStateHighlighted];
    [locationBtn setFrame:CGRectMake(0, 0, 44, 44)];
    [locationBtn addTarget:self action:@selector(showMapView:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *right = [[UIBarButtonItem alloc] initWithCustomView:locationBtn];
    self.navigationItem.rightBarButtonItems = @[fixBarButtonItem(),right];
    
    self.timeLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 200, 44)];
    self.timeLabel.textColor = [UIColor whiteColor];
    self.timeLabel.textAlignment = NSTextAlignmentCenter;
//    self.timeLabel.text = @"60:00";
    self.navigationItem.titleView = self.timeLabel;
}

- (void)showMapView:(UIButton *)btn
{
    MapViewController *mapVC = [[MapViewController alloc] init];
    mapVC.user = self.userModel;
    mapVC.distance = self.distance;
    mapVC.walkTime = self.walkTime;
    mapVC.carTime = self.carTime;
    [self presentViewController:mapVC animated:YES completion:nil];
}

- (void)back:(UIButton *)btn
{
    [self.navigationController popViewControllerAnimated:YES];
    [self stopFire];
}

- (void)initView
{
    
    self.communicationTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, windowWidth(), windowHeight() - 50)];
    self.communicationTableView.delegate = self;
    self.communicationTableView.dataSource = self;
    self.communicationTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.communicationTableView.backgroundColor = colorWithHexString(@"#181818");
    
    self.view.backgroundColor = colorWithHexString(@"#181818");
    [self.view addSubview:self.communicationTableView];
    
    self.bottomView = [[UIView alloc] initWithFrame:CGRectMake(0, windowHeight() - 50, windowWidth(), 50)];
    self.bottomView.backgroundColor = colorWithHexString(@"#6c6c6c");
    [self.view addSubview:self.bottomView];
    self.modeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.modeBtn setImage:[UIImage imageNamed:@"chat_ic_add"] forState:UIControlStateNormal];
    [self.modeBtn addTarget:self action:@selector(alertMode:) forControlEvents:UIControlEventTouchUpInside];
    [self.modeBtn setFrame: CGRectMake(8, 18, 16, 16)];
    self.textField = [[UITextField alloc] initWithFrame:CGRectMake(8 + 16 + 8, 9, windowWidth() - 8 - 16 - 8 - 37-11-8, 33)];
    [self.textField.layer setCornerRadius:16.f];
    self.textField.layer.masksToBounds = YES;
    self.textField.delegate = self;
    self.textField.backgroundColor = colorWithHexString(@"#242424");
    CGRect frame = self.textField.frame;
    frame.size.width = 3;
    UIView *leftview = [[UIView alloc] initWithFrame:frame];
    self.textField.leftViewMode = UITextFieldViewModeAlways;
    self.textField.leftView = leftview;
    self.textField.textColor = [UIColor whiteColor];
    self.sendBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    self.sendBtn.titleLabel.font = fontWithSize(17);
    [self.sendBtn setTitle:@"Send" forState:UIControlStateNormal];
    [self.sendBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    self.sendBtn.frame = CGRectMake(windowWidth() - 11 - 37, 11, 37, 30);
    [self.sendBtn addTarget:self action:@selector(sendCommMessage:) forControlEvents:UIControlEventTouchUpInside];
    [self.bottomView addSubview:self.modeBtn];
    [self.bottomView addSubview:self.textField];
    [self.bottomView addSubview:self.sendBtn];
    [self.view addSubview:self.bottomView];
    
    if (self.dataArray.count > 1) {
        [self.communicationTableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:self.dataArray.count-1 inSection:0] atScrollPosition:UITableViewScrollPositionBottom animated:YES];
    }
}

- (void)alertMode:(UIButton *)btn
{
    UIActionSheet *sheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"cancel" destructiveButtonTitle:nil otherButtonTitles:@"Camera",@"Photo library",@"GPS", nil];
    [sheet showInView:self.view];
}

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    switch (buttonIndex) {
        case 0:
            //camera
            if([[[UIDevice
                  currentDevice] systemVersion] floatValue]>=8.0) {
                
                self.modalPresentationStyle=UIModalPresentationOverCurrentContext;
                
            }
            [self getImageWithImagePickerType:UIImagePickerControllerSourceTypeCamera];
            
            break;
        case 1:
        {
             [self getImageWithImagePickerType:UIImagePickerControllerSourceTypePhotoLibrary];
        }
            break;
        case 2:
            // map
        {
            LocationAnnotationViewController *lvc = [[LocationAnnotationViewController alloc] init];
//            lvc.user = self.userModel;
            lvc.coor = ^(NSString *lat, NSString *lon){
                NSString *userId = self.userModel.requestId.stringValue;
                NSString *gpsString = [NSString stringWithFormat:@"%@,%@",lat,lon];
                SINOutgoingMessage *message = [SINOutgoingMessage messageWithRecipient:userId text:gpsString];
                [message addHeaderWithValue:[NSString stringWithFormat:@"%lu",MessageGPS] key:@"type"];

                [self.messageClient sendMessage:message];
            };
//            UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:lvc];
            [self.navigationController pushViewController:lvc animated:YES];
//            [self presentViewController:lvc animated:YES completion:nil];
        }
            break;
        case 3:
            break;
        default:
            break;
    }
}

- (void)getImageWithImagePickerType:(UIImagePickerControllerSourceType)sourceType
{
    if (!self.imagePicker) {
        self.imagePicker = [[UIImagePickerController alloc] init];
        self.imagePicker.delegate = self;
    }
    self.imagePicker.sourceType = sourceType;
    [self presentViewController:self.imagePicker animated:YES completion:nil];
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [picker dismissViewControllerAnimated:YES completion:nil];
    
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info
{
    //    if (picker.sourceType == UIImagePickerControllerSourceTypeCamera) {
    
    //    }
    UIImage *image = [info objectForKey:UIImagePickerControllerOriginalImage];
    UIImage *finalImage = [[image setMaxResolution:1024.f imageOri:image.imageOrientation]compressImage];
    self.uploadData = UIImageJPEGRepresentation(finalImage, 1);
    NSLog(@"image = %@",image);
//    self.uploadImageView.image = image;
    [self uploadImageWithComm:self.uploadData];
    [picker dismissViewControllerAnimated:YES completion:nil];
    
}

- (void)uploadImageWithComm:(NSData *)data
{
    NetworkingManager *manager = [NetworkingManager manager];
    [manager uploadMessageImageWithData:data success:^(NSURLSessionDataTask *task, id responseObject) {
        NSDictionary *result = (NSDictionary *)responseObject;
        NSNumber *stateNum = [result objectForKey:@"state"];
        NSLog(@"swssssssss = %@",result);
        if (stateNum.intValue == 10000) {
            NSString *url = [result objectForKey:@"url_big"];
            NSString *userId = self.userModel.requestId.stringValue;
            NSLog(@"userid = %@",userId);
            SINOutgoingMessage *message = [SINOutgoingMessage messageWithRecipient:userId text:url];
            [message addHeaderWithValue:[NSString stringWithFormat:@"%lu",MessageImage] key:@"type"];
            [self.messageClient sendMessage:message];
        }
    } error:^(NSError *err) {
        NSLog(@"error = %@",err.localizedDescription);
    }];
}

- (void)sendCommMessage:(UIButton *)btn
{
    if (self.textField.text.length > 0) {
//        [self.textField resignFirstResponder];
        NSString *userId = self.userModel.requestId.stringValue;
        NSLog(@"userid = %@",userId);
        SINOutgoingMessage *message = [SINOutgoingMessage messageWithRecipient:userId text:self.textField.text];
        [message addHeaderWithValue:[NSString stringWithFormat:@"%lu",MessageText] key:@"type"];
        [self.messageClient sendMessage:message];
        self.textField.text = @"";
    }

}


- (void)initObsever
{
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateTextInfo:) name:kMessageText object:nil];
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateGpsInfo:) name:kMessageGPS object:nil];
//    [[NSNotificationCenter defaultCenter]  addObserver:self selector:@selector(updateImageInfo:) name:kMessageImage object:nil];
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateLeaveInfo:) name:kMessageLeave object:nil];
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateTimeOutInfo:) name:kMessageTimeOut object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateMessageInfo:) name:kMessageCommunication object:nil];
}

- (void)updateMessageInfo:(NSNotification *)noti
{
    id<SINMessage> message = noti.object;
    NSLog(@"updateMessageInfo");
    if ([message.recipientIds containsObject:self.toUserId] || [message.senderId isEqualToString:self.toUserId]) {
        [self.dataArray addObject:message];
    }
    
    [self.communicationTableView reloadData];
    if (self.dataArray.count > 1) {
        [self.communicationTableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:self.dataArray.count-1 inSection:0] atScrollPosition:UITableViewScrollPositionBottom animated:YES];
    }
}

- (void)updateTextInfo:(id<SINMessage>) message
{
    [self.dataArray addObject:message];
}

- (void)updateGpsInfo:(id<SINMessage>)message
{
    [self.dataArray addObject:message];
}

- (void)updateImageInfo:(id<SINMessage>)message
{
    [self.dataArray addObject:message];
}

- (void)updateLeaveInfo:(id<SINMessage>)message
{
    [self.dataArray addObject:message];
}

- (void)updateTimeOutInfo:(id<SINMessage>)message
{
    [self.dataArray addObject:message];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *inCellIde = @"iCommunicationCellIde";
    static NSString *outCellIde = @"oCommunicationCellIde";
    id<SINMessage> message = [self.dataArray objectAtIndex:indexPath.row];
    NSNumber *userIdNum = [userdefault objectForKey:kRequestId];
    NSString *userId = [NSString stringWithFormat:@"%d",userIdNum.intValue];
    UITableViewCell *cell = nil;
    NSLog(@"senderId = %@",message.senderId);
    UITapGestureRecognizer *tap = nil;
    if ([message.senderId isEqualToString:userId]) {
        cell = [tableView dequeueReusableCellWithIdentifier:outCellIde];
        if (!cell) {
            cell = [[OutgoingTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:outCellIde];
        }
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        [((OutgoingTableViewCell *)cell).photoView sd_setImageWithURL:[NSURL URLWithString:self.userModel.headViewUrlString_S]];
        NSString *mType = [message.headers objectForKey:@"type"];
        MessageType type = mType.integerValue;
         ((OutgoingTableViewCell *)cell).photoView.tag = indexPath.row;
        for (UIGestureRecognizer *ges in ((OutgoingTableViewCell *)cell).photoView.gestureRecognizers) {
            [((OutgoingTableViewCell *)cell).photoView removeGestureRecognizer:ges];
        }
        if (type == MessageText) {
            ((OutgoingTableViewCell *)cell).cellType = CellOutTypeText;
            [((OutgoingTableViewCell *)cell) initView];
            ((OutgoingTableViewCell *)cell).textView.text = message.text;
            CGSize size = [((OutgoingTableViewCell *)cell).textView sizeThatFits:CGSizeMake(((OutgoingTableViewCell *)cell).textView.frame.size.width,CGFLOAT_MAX)];
//             NSLog(@"CSIze = %@",NSStringFromCGSize(size));
            ((OutgoingTableViewCell *)cell).textView.frame = CGRectMake(windowWidth() - size.width, ((OutgoingTableViewCell *)cell).textView.frame.origin.y, size.width, size.height);
            ((OutgoingTableViewCell *)cell).textViewBackgroundView.frame = CGRectMake(0, 0, size.width, size.height);
            
        }else if (type == MessageImage){
            ((OutgoingTableViewCell *)cell).cellType = CellOutTypeImage;
            [((OutgoingTableViewCell *)cell) initView];
            [((OutgoingTableViewCell *)cell).photoView sd_setImageWithURL:[NSURL URLWithString:message.text]];
            tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(showBigImage:)];
            [((OutgoingTableViewCell *)cell).photoView addGestureRecognizer:tap];
        }else if(type == MessageGPS){
            ((OutgoingTableViewCell *)cell).cellType = CellOutTypeGps;
            [((OutgoingTableViewCell *)cell) initView];
            self.locationString = message.text;
            [((OutgoingTableViewCell *)cell).photoView setImage:[UIImage imageNamed:@"map"]];
            tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(showGpsMap:)];
            [((OutgoingTableViewCell *)cell).photoView addGestureRecognizer:tap];
        }else if (type == MessageLeave){
            ((OutgoingTableViewCell *)cell).cellType = CellOutTypeLeave;
            [((OutgoingTableViewCell *)cell) initView];
            cell.textLabel.text = message.text;
            [self.bottomView removeFromSuperview];
            self.bottomView.userInteractionEnabled = NO;
            [self.textField resignFirstResponder];
        }else if (type == MessageTimeOut){
            ((OutgoingTableViewCell *)cell).cellType = CellOutTypeTimeOut;
             [((OutgoingTableViewCell *)cell) initView];
            cell.textLabel.text = LocalizedString(@"time_up",nil);
            [self.bottomView removeFromSuperview];
            self.bottomView.userInteractionEnabled = NO;
            [self.textField resignFirstResponder];
        }

        
    }else{
        cell = [tableView dequeueReusableCellWithIdentifier:inCellIde];
        if (!cell) {
            cell = [[IncomingTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:inCellIde];
        }
        for (UIGestureRecognizer *ges in ((IncomingTableViewCell *)cell).photoView.gestureRecognizers) {
            [((IncomingTableViewCell *)cell).photoView removeGestureRecognizer:ges];
        }
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
       
        NSString *mType = [message.headers objectForKey:@"type"];
        MessageType type = mType.integerValue;
        ((IncomingTableViewCell *)cell).photoView.tag = indexPath.row;
        if (type == MessageText) {
            ((IncomingTableViewCell *)cell).cellType = CellTypeText;
            [((IncomingTableViewCell *)cell) initView];
            ((IncomingTableViewCell *)cell).textView.text = message.text;
            CGSize size = [((IncomingTableViewCell *)cell).textView sizeThatFits:CGSizeMake(((IncomingTableViewCell *)cell).textView.frame.size.width,CGFLOAT_MAX)];
//            NSLog(@"CSIze = %@",NSStringFromCGSize(size));
            ((IncomingTableViewCell *)cell).textView.frame = CGRectMake(40 + 8 + 5, ((IncomingTableViewCell *)cell).textView.frame.origin.y, size.width, size.height);
            ((IncomingTableViewCell *)cell).textViewBackgroundView.frame = CGRectMake(0, 0, size.width, size.height);
            

        }else if (type == MessageImage){
            ((IncomingTableViewCell *)cell).cellType = CellTypeImage;
            [((IncomingTableViewCell *)cell) initView];
            [((IncomingTableViewCell *)cell).photoView sd_setImageWithURL:[NSURL URLWithString:message.text]];
            tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(showBigImage:)];
            [((IncomingTableViewCell *)cell).photoView addGestureRecognizer:tap];
        }else if(type == MessageGPS){
            ((IncomingTableViewCell *)cell).cellType = CellTypeGps;
            [((IncomingTableViewCell *)cell) initView];
//            ((IncomingTableViewCell *)cell).textView.text = message.text;
            self.locationString = message.text;
            [((IncomingTableViewCell *)cell).photoView setImage:[UIImage imageNamed:@"map"]];
            tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(showGpsMap:)];
            [((IncomingTableViewCell *)cell).photoView addGestureRecognizer:tap];
//            [((IncomingTableViewCell *)cell).photoView sd_setImageWithURL:[NSURL URLWithString:message.text]];
        }else if (type == MessageLeave){
            ((IncomingTableViewCell *)cell).cellType = CellTypeLeave;
            [((IncomingTableViewCell *)cell) initView];
            cell.textLabel.text = message.text;
//            cell.textLabel.textAlignment = NSTextAlignmentCenter;
            [self.bottomView removeFromSuperview];
            self.bottomView.userInteractionEnabled = NO;
            [self.textField resignFirstResponder];
        }else if (type == MessageTimeOut){
            ((IncomingTableViewCell *)cell).cellType = CellTypeTimeOut;
            [((IncomingTableViewCell *)cell) initView];
            cell.textLabel.text = LocalizedString(@"time_up",nil);
//            cell.textLabel.textAlignment = NSTextAlignmentCenter;
            [self.bottomView removeFromSuperview];
            self.bottomView.userInteractionEnabled = NO;
            [self.textField resignFirstResponder];
        }
         [((IncomingTableViewCell *)cell).headView sd_setImageWithURL:[NSURL URLWithString:self.userModel.headViewUrlString_S]];
    }
    
    return cell;
}

- (void)showGpsMap:(UITapGestureRecognizer *)tap
{
    ShowGpsInfoViewController *map = [[ShowGpsInfoViewController alloc] init];
    map.user = self.userModel;
    NSNumber *lat = [NSNumber numberWithDouble:[self.locationString componentsSeparatedByString:@","].firstObject.doubleValue];
    NSNumber *lon = [NSNumber numberWithDouble:[self.locationString componentsSeparatedByString:@","].lastObject.doubleValue];
    map.user.lon = lon;
    map.user.lat = lat;
    [self.navigationController pushViewController:map animated:YES];
//    [self presentViewController:map animated:YES completion:nil];
}

- (void)showBigImage:(UITapGestureRecognizer *)tap
{
    UIImageView *imageView = (UIImageView *)tap.view;
    BigImageViewController *bvc = [[BigImageViewController alloc] init];
    bvc.imageUrl = imageView.sd_imageURL;
    [self.navigationController pushViewController:bvc animated:YES];
}

//- (void)showAnnotationView:(UITapGestureRecognizer *)tap
//{
//    UserModel *user = self.userModel;
//    MapViewController *map = [[MapViewController alloc] init];
//    map.user = user;
//    map.user.lon = [NSNumber numberWithFloat:<#(float)#>]
//}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    id<SINMessage> message = [self.dataArray objectAtIndex:indexPath.row];
    NSString *type = [message.headers objectForKey:@"type"];
    if (type.integerValue == MessageText) {
        return [self heightForString:message.text fontSize:17 andWidth:windowWidth() - 60];
    }else if (type.integerValue == MessageGPS || type.integerValue == MessageImage){
        return 109;
    }else if(type.integerValue == MessageLeave || type.integerValue == MessageTimeOut)
    {
        return 44;
    }
    return 200;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _dataArray.count;
}


- (void)intentToMapView:(UIButton *)btn
{
    MapViewController *mapVC = [[MapViewController alloc] init];
    [self presentViewController:mapVC animated:YES completion:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [self stopFire];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    NSString *userId = self.userModel.requestId.stringValue;
    NSLog(@"userid = %@",userId);
    SINOutgoingMessage *message = [SINOutgoingMessage messageWithRecipient:userId text:textField.text];
    [message addHeaderWithValue:[NSString stringWithFormat:@"%lu",MessageText] key:@"type"];
    [self.messageClient sendMessage:message];
    textField.text = @"";
    return YES;
}

- (float)heightForString:(NSString *)value fontSize:(float)fontSize andWidth:(float)width
{
    UITextView *textView = [[UITextView alloc] initWithFrame:CGRectMake(60, 8, width, 44)];
    textView.backgroundColor = [UIColor clearColor];
    textView.textContainerInset = UIEdgeInsetsMake(15, 10, 15, 10);
    textView.font = fontWithSize(fontSize);
    textView.text = value;
    CGSize deSize = [textView sizeThatFits:CGSizeMake(width,CGFLOAT_MAX)];
    return deSize.height + 15;
}

- (void)timerFireMethod:(NSTimer *)theTimer
{
    //    BOOL timeStart = YES;
    NSCalendar *cal = [NSCalendar currentCalendar];//定义一个NSCalendar对象
    NSDateComponents *endTime = [[NSDateComponents alloc] init];    //初始化目标时间...
    NSDate *today = [NSDate date];    //得到当前时间
    NSTimeInterval interval = [today timeIntervalSince1970];
    NSDate *today2 = [NSDate dateWithTimeIntervalSince1970:interval +[CommonUtil defaultUtil].fixTime/1000.f];

    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    
    //    NSDate *date = [NSdate date]
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:self.userModel.endTime.longValue/ 1000.f ];
    //    NSDate *dateString = [dateFormatter
    //    NSDate *dateString = [dateFormatter dateFromString:todate];
//    NSLog(@"self.userModel.endtime = %ld",self.userModel.endTime.intValue);
    NSString *overdate = [dateFormatter stringFromDate:date];
            NSLog(@"overdate = %@",overdate);
    static int year;
    static int month;
    static int day;
    static int hour;
    static int minute;
    static int second;
    if(_timerStart) {//从NSDate中取出年月日，时分秒，但是只能取一次
        year = [[overdate substringWithRange:NSMakeRange(0, 4)] intValue];
        month = [[overdate substringWithRange:NSMakeRange(5, 2)] intValue];
        day = [[overdate substringWithRange:NSMakeRange(8, 2)] intValue];
        hour = [[overdate substringWithRange:NSMakeRange(11, 2)] intValue];
        minute = [[overdate substringWithRange:NSMakeRange(14, 2)] intValue];
        second = [[overdate substringWithRange:NSMakeRange(17, 2)] intValue];
        _timerStart = NO;
    }
    
    [endTime setYear:year];
    [endTime setMonth:month];
    [endTime setDay:day];
    [endTime setHour:hour];
    [endTime setMinute:minute];
    [endTime setSecond:second];
    NSDate *overTime = [cal dateFromComponents:endTime]; //把目标时间装载入date
    //用来得到具体的时差，是为了统一成北京时间
    unsigned int unitFlags = NSYearCalendarUnit| NSMonthCalendarUnit| NSDayCalendarUnit| NSHourCalendarUnit| NSMinuteCalendarUnit| NSSecondCalendarUnit;
    NSDateComponents *d = [cal components:unitFlags fromDate:today2 toDate:overTime options:0];
    NSString *t = [NSString stringWithFormat:@"%ld", (long)[d day]];
    NSString *h = [NSString stringWithFormat:@"%ld", (long)[d hour]];
    NSString *fen = [NSString stringWithFormat:@"%ld", (long)[d minute]];
    if([d minute] < 10) {
        fen = [NSString stringWithFormat:@"0%ld",(long)[d minute]];
    }
    NSString *miao = [NSString stringWithFormat:@"%ld", (long)[d second]];
    if([d second] < 10) {
        miao = [NSString stringWithFormat:@"0%ld",(long)[d second]];
    }
//        NSLog(@"===%@天 %@:%@:%@",t,h,fen,miao);
    //    [self.fdv.timeLabel setText:[NSString stringWithFormat:@"%@天 %@:%@:%@",t,h,fen,miao]];
    [self.timeLabel setText:[NSString stringWithFormat:@"%@:%@",fen,miao]];
//    [self.fView.timeLabel setText:[NSString stringWithFormat:@"%@ minutes left",fen]];
    if([d second] >= 0) {
        //计时尚未结束，do_something
        //        [_longtime setText:[NSString stringWithFormat:@"%@:%@:%@",d,fen,miao]];
    }else{
        self.bottomView.userInteractionEnabled = NO;
        [self.bottomView removeFromSuperview];
        [self.textField resignFirstResponder];
        //计时器失效
        [self.timeLabel setText:@"00:00"];
        _timerStart = YES;
        [theTimer invalidate];
    } 
    
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    [self.textField resignFirstResponder];
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    CGRect frame = self.view.bounds;
    
    
    return YES;
}

- (void) registerForKeyboardNotifications
{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWasShown:) name:UIKeyboardWillShowNotification object:nil];
    
    [[NSNotificationCenter defaultCenter]  addObserver:self selector:@selector(keyboardWasHidden:) name:UIKeyboardWillHideNotification object:nil];
}

- (void) keyboardWasShown:(NSNotification *) notif
{
    NSDictionary *info = [notif userInfo];
    NSValue *value = [info objectForKey:UIKeyboardFrameEndUserInfoKey];
    CGSize keyboardSize = [value CGRectValue].size;
    
    CGRect bottomFrame = self.bottomView.frame;
    bottomFrame.origin.y -= keyboardSize.height;
    [UIView animateWithDuration:0.3 animations:^{
        self.communicationTableView.frame = CGRectMake(0, 0, windowWidth(), windowHeight() - 50 - keyboardSize.height);
        self.bottomView.frame = CGRectMake(0, windowHeight() - 50 - keyboardSize.height, windowWidth(), 50);

    }];
    NSLog(@"keyBoard:%f", keyboardSize.height);  //216
    ///keyboardWasShown = YES;
}
- (void) keyboardWasHidden:(NSNotification *) notif
{
    NSDictionary *info = [notif userInfo];
    
    NSValue *value = [info objectForKey:UIKeyboardFrameEndUserInfoKey];
    CGSize keyboardSize = [value CGRectValue].size;
    NSLog(@"keyboardWasHidden keyBoard:%f", keyboardSize.height);
    // keyboardWasShown = NO;
    CGRect frame = self.communicationTableView.frame;
    frame.size.height += keyboardSize.height;
    CGRect bottomFrame = self.bottomView.frame;
    bottomFrame.origin.y += keyboardSize.height;
    [UIView animateWithDuration:0.3 animations:^{
        self.communicationTableView.frame = CGRectMake(0, 0, windowWidth(), windowHeight() - 50);
        self.bottomView.frame = CGRectMake(0, windowHeight() - 50 , windowWidth(), 50);

    }];
}

- (void)timeOver{

}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

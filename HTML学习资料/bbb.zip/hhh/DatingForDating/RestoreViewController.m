//
//  RestoreViewController.m
//  DatingForDating
//
//  Created by MAXToooNG on 16/5/4.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import "RestoreViewController.h"

@implementation RestoreViewController

- (void)viewDidLoad{
    self.view.backgroundColor = colorWithHexString(@"#181818");
    self.label = [[UITextView alloc] initWithFrame:CGRectMake(10, 0, windowWidth() - 20, self.view.frame.size.height - 44)];
//    self.label.numberOfLines = 0;
    self.label.backgroundColor = colorWithHexString(@"#181818");
    self.label.textAlignment = NSTextAlignmentLeft;
    self.label.textColor = colorWithHexString(@"#b1b1b1");
    self.label.font = fontWithSize(18);
    self.label.text = LocalizedString(@"restore_tips",nil);
    self.label.userInteractionEnabled = NO;
    
    [self.view addSubview:self.label];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    UIButton *leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    leftBtn.frame = CGRectMake(0, 0, 44, 44);
    [leftBtn setImage:[UIImage imageNamed:@"title_ic_back_nor"] forState:UIControlStateNormal];
    [leftBtn setImage:[UIImage imageNamed:@"title_ic_back_pre"] forState:UIControlStateHighlighted];
    [leftBtn addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc] initWithCustomView:leftBtn];
    self.navigationItem.leftBarButtonItems = @[fixBarButtonItem(),leftItem];
    
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 200, 44)];
    titleLabel.text = LocalizedString(@"restore", nil);
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.textColor = [UIColor whiteColor];
    self.navigationItem.titleView = titleLabel;
}

- (void)back{
    [self.navigationController popViewControllerAnimated:YES];
}

@end

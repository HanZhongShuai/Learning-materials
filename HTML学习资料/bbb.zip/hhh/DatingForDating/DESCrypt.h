//
//DESCrypt
//  SmartHome
//
//  Created by gbcomApple on 14-8-26.
//  Copyright (c) 2014年 GBCOM. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CommonCrypto/CommonCryptor.h>
#import "GTMBase64.h"
  
/**
 *  des加，解密
 */
@interface DESCrypt : NSObject
+(NSString *)encrypt:(NSString *)plainText key:(NSString *)key;
+(NSString *)decrypt:(NSData *)data WithKey:(NSString *)key;
+ (NSString*)encodeBase64String:(NSString *)input;
+ (NSString*)decodeBase64String:(NSString *)input;
+ (NSString*)encodeBase64Data:(NSData *)data;
+ (NSString*)decodeBase64Data:(NSData *)data;
@end

//
//  FreeOneMonthView.h
//  DatingForDating
//
//  Created by MAXToooNG on 16/5/3.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void(^BuyOneMonth)(void);
typedef void(^CancelBuy)(void);
@interface FreeOneMonthView : UIView
@property (nonatomic, strong) BuyOneMonth buyOneMonth;
@property (nonatomic, strong) CancelBuy cancelBuy;
@end

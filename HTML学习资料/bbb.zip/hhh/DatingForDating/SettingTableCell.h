//
//  SettingTableCell.h
//  DatingForDating
//
//  Created by MAXToooNG on 16/4/22.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingTableCell : UITableViewCell
@property (nonatomic, strong) UIView *lineView;
@property (nonatomic, strong) UILabel *detailLabel;
@end

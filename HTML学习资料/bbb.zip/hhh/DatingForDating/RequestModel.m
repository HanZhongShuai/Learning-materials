//
//  RequestModel.m
//  DatingForDating
//
//  Created by MAXToooNG on 16/3/29.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import "RequestModel.h"

@implementation RequestModel

@end

//
//  RequestFeedCell.h
//  DatingForDating
//
//  Created by MAXToooNG on 16/4/7.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RequestFeedCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *headerView;
@property (weak, nonatomic) IBOutlet UIButton *likeButton;
@property (weak, nonatomic) IBOutlet UIButton *passButton;
@property (weak, nonatomic) IBOutlet UILabel *likedLabel;
@property (weak, nonatomic) IBOutlet UILabel *timeLabel;
@property (weak, nonatomic) IBOutlet UILabel *footTime;
@property (weak, nonatomic) IBOutlet UILabel *carTime;
@property (weak, nonatomic) IBOutlet UIButton *reportButton;
@property (nonatomic, strong) NSNumber *userId ;
@end

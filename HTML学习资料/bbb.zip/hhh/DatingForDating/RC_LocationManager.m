//
//  RC_LocationManager.m
//  DatingForDating
//
//  Created by MAXToooNG on 16/3/30.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import "RC_LocationManager.h"
@import MapKit;

@implementation RC_LocationManager

static RC_LocationManager *locationManager;

- (RC_LocationManager *)manager
{
    locationManager = [[RC_LocationManager alloc] init];
    return locationManager;
}

@end

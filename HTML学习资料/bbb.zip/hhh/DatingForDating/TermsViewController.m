//
//  TermsViewController.m
//  DatingForDating
//
//  Created by MAXToooNG on 16/3/28.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import "TermsViewController.h"

@implementation TermsViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = colorWithHexString(@"#181818");
    UIWebView *view = [[UIWebView alloc] initWithFrame:self.view.bounds];
    NSURL *url = [NSURL URLWithString:kTermsOfUserUrl];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    [view loadRequest:request];
    [self.view addSubview:view];
}

- (void)viewWillAppear:(BOOL)animated
{
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 200, 44)];
    titleLabel.text = @"Terms of use";
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.textColor = [UIColor whiteColor];
    self.navigationItem.titleView = titleLabel;
    
    UIButton *leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    leftBtn.frame = CGRectMake(0, 0, 44, 44);
    [leftBtn setImage:[UIImage imageNamed:@"title_ic_back_nor"] forState:UIControlStateNormal];
    [leftBtn setImage:[UIImage imageNamed:@"title_ic_back_pre"] forState:UIControlStateHighlighted];
    [leftBtn addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc] initWithCustomView:leftBtn];
    self.navigationItem.leftBarButtonItems = @[fixBarButtonItem(),leftItem];
}

- (void)back{
    [self.navigationController popViewControllerAnimated:YES];
}

@end

//
//  Public.h
//  DatingForDating
//
//  Created by MAXToooNG on 16/3/15.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#ifndef Public_h
#define Public_h

#define userdefault [NSUserDefaults standardUserDefaults]

#define kiCloudToken @"iCloudToken"
#define kLongitude @"lastLongitude"
#define kLatitude @"lastLatitude"
#define kGender @"UserGender"
//#define kAppleId @"1106259301"
#define kAppleId @"10000"
#define kHeaderViewSmall @"headerSmall"
#define kHeaderViewBig @"headerBig"
#define kRequestId @"requestId"
#define kBeginTime @"beginTime"
#define kEndTime @"endTime"
#define kIsRequesting @"isRequesting"
#define kFeedbackEmail @"wink@rileycillian.com"
#define kCityName @"cityName"
#define kTermsOfUserUrl @"http://45.79.10.24:85/wink_termsuse.html"
#define kShowMail @"showMail"

#define kDataTime @"l_t"
#define kCommTime @"m_t"
#define kTotalTime @"total_t"
#define kRateTime @"rate_t"
#define kPageSize @"page_size"
#define kFillSize @"fill_size"
#define kUserReportNum @"user_report_num"
#define kPicReportNum @"pic_report_num"
#define kFreezLen @"user_freez_len"
#define kDistance @"distance"
#define kImFlag @"imflage"
#define kHeaderImage @"headerImage"
#define kCommArray @"commArray"
#define kFBeginTime @"f_b_t"
#define kFEndTime @"f_e_t"


//des string
#define kStra @"sEDcu"
#define kStrd @"nvjIfuy"
#define kStri @"otiEuy"
#define kStrg @"zxsiu"
#define kStrt @"ncjhdh"
#define kStrn @"ty3ui1zpo"

#define kDKey @"$Nu&a*6M"

//MessageText,
//MessageImage,
//MessageGPS,
//MessageLike,
//MessageWhoLikeU,
//MessageMatch,
//MessageLeave,
//MessageTimeOut

#define kMessageText @"MessageText"
#define kMessageImage @"MessageImage"
#define kMessageGPS @"MessageGPS"
#define kMessageLike @"MessageLike"
#define kMessageWhoLikeU @"MessageWhoLikeU"
#define kMessageMatch @"MessageMatch"
#define kMessageLeave @"MessageLeave"
#define kMessageTimeOut @"MessageTimeOut"
#define kMessageCommunication @"MessageCommunication"

#define kUserId @"userId"
#define kUserToken @"userToken"
#define kPushToken @"pushToken"
#define kIsFee @"isFee"
#define kReceiptData @"receiptData"
#define kSecretKey @"83af9ed114584ef69c5f9abdcef2d41c"
#define kIsFirstIap @"isFirstIap"
#define UMENG_KEY @"5718590c67e58e73ff001b6a"
#define kRefreshFeedList @"feedList"


#import "CMethods.h"
#import "CommonUtil.h"
#import "MobClick.h"
#import "UIImageView+WebCache.h"
#import "iCloud.h"

#endif /* Public_h */

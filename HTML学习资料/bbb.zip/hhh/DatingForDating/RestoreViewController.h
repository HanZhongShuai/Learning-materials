//
//  RestoreViewController.h
//  DatingForDating
//
//  Created by MAXToooNG on 16/5/4.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RestoreViewController : UIViewController
@property (nonatomic, strong) UITextView *label;
@end



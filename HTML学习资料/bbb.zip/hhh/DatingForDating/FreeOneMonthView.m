//
//  FreeOneMonthView.m
//  DatingForDating
//
//  Created by MAXToooNG on 16/5/3.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import "FreeOneMonthView.h"

@implementation FreeOneMonthView

- (instancetype)initWithFrame:(CGRect)frame
{
    
    if (self = [super initWithFrame: frame]) {
        [self initViews];
    }
    return self;
}

- (void)initViews
{
    CGRect f = CGRectMake(20, 100 - 40 - 22, windowWidth() - 40, windowHeight() - 200);
    self.backgroundColor = [UIColor colorWithWhite:0 alpha:0.5];
    
    UIView *alertView = [[UIView alloc] initWithFrame:f];
    alertView.backgroundColor = colorWithHexString(@"fafafa");
    [self addSubview:alertView];
    UIImageView *backImageView = [[UIImageView alloc] initWithFrame:CGRectMake((f.size.width - setW(172)) / 2, 0, setW(172), setH(207))];
    backImageView.image = [UIImage imageNamed:@"Ribbon"];
    [alertView addSubview:backImageView];
    UIImageView *freeIcon = [[UIImageView alloc] initWithFrame:CGRectMake((f.size.width - setW(136)) / 2, 12, setW(136) ,setH(130))];
    freeIcon.image = [UIImage imageNamed:@"free"];
    [alertView addSubview:freeIcon];
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(5, 0, f.size.width-10, 200)];
    label.center = CGPointMake(f.size.width / 2, f.size.height / 2 + 10);
    label.text = LocalizedString(@"free_content", nil);
    label.font = fontWithSize(setH(16));
    label.lineBreakMode = NSLineBreakByWordWrapping;
    label.numberOfLines = 0;
    label.textColor = colorWithHexString(@"#4a4a4a");
    label.textAlignment = NSTextAlignmentCenter;
    [alertView addSubview:label];
    
    UIButton *cancelBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    [cancelBtn setTitle:LocalizedString(@"button_cancel", nil) forState:UIControlStateNormal];
    [cancelBtn addTarget:self action:@selector(cancel) forControlEvents:UIControlEventTouchUpInside];
    [cancelBtn setFrame:CGRectMake(15, f.size.height - 44 - 10, f.size.width - 30, 44)];
    cancelBtn.titleLabel.font = fontWithSize(16);
    [cancelBtn setTitleColor:colorWithHexString(@"#4a4a4a") forState:UIControlStateNormal];
    [alertView addSubview:cancelBtn];
    
    UIButton *buyBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    [buyBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [buyBtn setTitle:LocalizedString(@"Sounds Great!", nil) forState:UIControlStateNormal];
    buyBtn.titleLabel.font = fontWithSize(16);
    [buyBtn setFrame:CGRectMake(15, f.size.height - 44 - 10 -10 - 44, f.size.width - 30, 44)];
    [buyBtn setBackgroundColor:colorWithHexString(@"#fa5b3a")];
    [buyBtn addTarget:self action:@selector(buy) forControlEvents:UIControlEventTouchUpInside];
    [alertView addSubview:buyBtn];
    
}

- (void)buy
{
    self.buyOneMonth();
}

- (void)cancel
{
    [self removeFromSuperview];
    self.cancelBuy();
}

@end

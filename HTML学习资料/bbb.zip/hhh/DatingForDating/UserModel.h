//
//  UserModel.h
//  DatingForDating
//
//  Created by MAXToooNG on 16/3/29.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UserModel : NSObject

@property (nonatomic, strong) NSNumber *userId;
@property (nonatomic, strong) NSString *headViewUrlString_L;
@property (nonatomic, strong) NSString *headViewUrlString_S;
@property (nonatomic, strong) NSNumber *beginTime;
@property (nonatomic, strong) NSNumber *endTime;
//@property (nonatomic, strong) NSNumber *dateTime;
@property (nonatomic, strong) NSNumber *gender;
@property (nonatomic, strong) NSNumber *requestId;
@property (nonatomic, strong) NSNumber *lon;
@property (nonatomic, strong) NSNumber *lat;
//notification status
@property (nonatomic, strong) NSNumber *status;
@property (nonatomic, strong) NSString *notiString;
@property (nonatomic, assign) BOOL likeTag;
@property (nonatomic, strong) NSNumber *likedTime;
@property (nonatomic, strong) NSMutableArray *communiDataArray;
@property (nonatomic, strong) NSNumber *commId;

- (void)getTestModel;
- (id)initWithCoder:(NSCoder *)aDecoder;
- (void)encodeWithCoder:(NSCoder *)aCoder;
@end

//
//  OutgoingTableViewCell.h
//  DatingForDating
//
//  Created by MAXToooNG on 16/4/13.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef NS_ENUM(NSUInteger, CellOutType) {
    CellOutTypeText,
    CellOutTypeImage,
    CellOutTypeGps,
    CellOutTypeLeave,
    CellOutTypeTimeOut
};
@interface OutgoingTableViewCell : UITableViewCell <UITextViewDelegate>
@property (nonatomic, assign) CellOutType cellType;
@property (nonatomic, strong) UIImageView *headView;
@property (nonatomic, strong) UIImageView *photoView;
@property (nonatomic, strong) UITextView *textView;
@property (nonatomic, strong) UIImageView *textViewBackgroundView;
- (void)initView;
//- (CGFloat)getHeight;
@end

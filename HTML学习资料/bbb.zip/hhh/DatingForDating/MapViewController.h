//
//  MapViewController.h
//  DatingForDating
//
//  Created by MAXToooNG on 16/3/30.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MapViewController : UIViewController
@property (nonatomic, strong) UserModel *user;
@property (nonatomic, strong) NSString *distance;
@property (nonatomic, strong) NSString *walkTime;
@property (nonatomic, strong) NSString *carTime;
@end

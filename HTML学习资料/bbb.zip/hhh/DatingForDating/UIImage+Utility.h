//
//  UIImage+Utility.h
//
//  Created by sho yakushiji on 2013/05/17.
//  Copyright (c) 2013年 CALACULU. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (Utility)

+ (UIImage*)fastImageWithData:(NSData*)data;
+ (UIImage*)fastImageWithContentsOfFile:(NSString*)path;

- (UIImage*)deepCopy;

- (UIImage*)resize:(CGSize)size;
- (UIImage*)aspectFit:(CGSize)size;
- (UIImage*)aspectFill:(CGSize)size;
- (UIImage*)aspectFill:(CGSize)size offset:(CGFloat)offset;

- (UIImage*)crop:(CGRect)rect;

- (UIImage*)maskedImage:(UIImage*)maskImage;

- (UIImage*)gaussBlur:(CGFloat)blurLevel;       //  {blurLevel | 0 ≤ t ≤ 1}
- (UIImage *)makeOverlapImage:(NSInteger)number withSpace:(CGFloat)space;//叠层
- (UIImage*)gaussBlur:(CGFloat)blurLevel withOverlapImage:(NSInteger)number withSpace:(CGFloat)space;//模糊叠层
- (UIImage *)setMaxResolution:(CGFloat)maxResolution imageOri:(UIImageOrientation)ori;
- (UIImage *)compressImage;
@end

//
//  LocationAnnotationViewController.m
//  DatingForDating
//
//  Created by MAXToooNG on 16/3/31.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import "LocationAnnotationViewController.h"
#import "RCAnnotation.h"
@import MapKit;
@interface LocationAnnotationViewController () <MKMapViewDelegate>
@property (nonatomic, strong) MKMapView *mapView;
@property (nonatomic, strong) NSString *lon;
@property (nonatomic, strong) NSString *lat;
@end

@implementation LocationAnnotationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.mapView = [[MKMapView alloc] initWithFrame:self.view.bounds];
    [self.view addSubview: self.mapView];
    self.mapView.delegate = self;
    self.mapView.showsUserLocation = YES;
    RCAnnotation *annotation = [[RCAnnotation alloc] init];
    CLLocationDegrees latitude = ((NSNumber *)[userdefault objectForKey:kLatitude]).doubleValue;
    CLLocationDegrees longitude = ((NSNumber *)[userdefault objectForKey:kLongitude]).doubleValue;
    CLLocationCoordinate2D coordinate = CLLocationCoordinate2DMake(latitude, longitude);
    [annotation setCoordinate:coordinate];
    [self.mapView addAnnotation:annotation];
    MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance(coordinate, 1000, 1000);
    MKCoordinateRegion adjustedRegion = [self.mapView regionThatFits:region];
    [self.mapView setRegion:adjustedRegion animated:YES];
    self.lon = [NSString stringWithFormat:@"%f",longitude];
    self.lat = [NSString stringWithFormat:@"%f",latitude];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    UIButton *leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    leftBtn.frame = CGRectMake(0, 0, 44, 44);
    [leftBtn setImage:[UIImage imageNamed:@"title_ic_back_nor"] forState:UIControlStateNormal];
    [leftBtn setImage:[UIImage imageNamed:@"title_ic_back_pre"] forState:UIControlStateHighlighted];
    [leftBtn addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc] initWithCustomView:leftBtn];
    
    UIButton *sendBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    [sendBtn setTitle:@"Send" forState:UIControlStateNormal];
    [sendBtn setTintColor:colorWithHexString(@"#ffffff")];
    [sendBtn addTarget:self action:@selector(sendGPSMessage) forControlEvents:UIControlEventTouchUpInside];
    sendBtn.frame = CGRectMake(0, 0, 50, 44);
    UIBarButtonItem *rightItem = [[UIBarButtonItem alloc] initWithCustomView:sendBtn];
    
    self.navigationItem.leftBarButtonItems = @[fixBarButtonItem(),leftItem];
    self.navigationItem.rightBarButtonItems = @[fixBarButtonItem(),rightItem];
}

- (void)sendGPSMessage
{
    self.coor(self.lat,self.lon);
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)back
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id<MKAnnotation>)annotation
{
    if ([annotation isKindOfClass:[RCAnnotation class]]) {
        MKAnnotationView *pinView = [[MKAnnotationView alloc] init];
        pinView.image = [UIImage imageNamed:@"chat_ic_map"];
        pinView.draggable = YES;
        return pinView;
    }
    return nil;
}

- (void)mapView:(MKMapView *)mapView annotationView:(MKAnnotationView *)view didChangeDragState:(MKAnnotationViewDragState)newState fromOldState:(MKAnnotationViewDragState)oldState
{
    NSLog(@"oldState = %lu, new state = %lu",(unsigned long)oldState,(unsigned long)newState);
    if (newState == MKAnnotationViewDragStateEnding)
    {
        CLLocationCoordinate2D droppedAt = view.annotation.coordinate;
        NSLog(@"dropped at %f,%f", droppedAt.latitude, droppedAt.longitude);
        self.lat = [NSString stringWithFormat:@"%f",droppedAt.latitude];
        self.lon = [NSString stringWithFormat:@"%f",droppedAt.longitude];
        //update the annotation
        //see if its an information annotation
        if ([view.annotation isKindOfClass:[RCAnnotation class]]) {
            NSLog(@"Info annotation updating..");
            RCAnnotation* userAnnotation = [[RCAnnotation alloc] init];
            [userAnnotation setCoordinate:droppedAt];
            [self.mapView removeAnnotation:view.annotation];
            [self.mapView addAnnotation:userAnnotation];
//            [userAnnotation updateLocationWithServerForConvoy: self.title];
        }
        
    }
}

- (void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation
{

}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear: animated];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

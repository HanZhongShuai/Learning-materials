//
//  AppDelegate.m
//  DatingForDating
//
//  Created by MAXToooNG on 16/3/15.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import "AppDelegate.h"
#import "StoreObserver.h"
#import "SFHFKeychainUtils.h"
#import "CommonUtil.h"
#import "NetworkingManager.h"
#import <Sinch/Sinch.h>
#import "UserModel.h"

@interface AppDelegate () <SINManagedPushDelegate>
@property (nonatomic, strong) id<SINManagedPush> push;
@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {

    [UIApplication sharedApplication].applicationIconBadgeNumber = 0;
    NSNumber *isFirstIap = [userdefault objectForKey:kIsFirstIap];
    if (!isFirstIap) {
        isFirstIap = @YES;
        [userdefault setObject:isFirstIap forKey:kIsFirstIap];
    }
    self.push = [Sinch managedPushWithAPSEnvironment:SINAPSEnvironmentAutomatic];
    self.push.delegate = self;
    [self.push setDesiredPushType:SINPushTypeRemote];
//    [self cancelNotification];
//    [self registNotification];
    [self.push registerUserNotificationSettings];
    [self.push setDisplayName:@"!"];
    [CommonUtil defaultUtil].push = self.push;
//    NSString *bundleIdentifier = [[NSBundle mainBundle] bundleIdentifier];
    NSError *error = nil;
    NSString *idfv = [SFHFKeychainUtils getPasswordForUsername:@"IDFV" andServiceName:@"datingService" error:&error];
    NSLog(@"error = %@",error.localizedDescription);
    if (!idfv) {
        idfv = [[[UIDevice currentDevice] identifierForVendor] UUIDString];
        [SFHFKeychainUtils storeUsername:@"IDFV" andPassword:idfv forServiceName:@"datingService" updateExisting:NO error:nil];
    }
    [CommonUtil defaultUtil].idfv = idfv;
    NSLog(@"idfv = %@",idfv );
    [self getConfig];
    [self setHistoryData];
    [self umengSetting];
    // Override point for customization after application launch.
//    [[SKPaymentQueue defaultQueue] addTransactionObserver:[StoreObserver sharedInstance]];
    return YES;
}

#pragma mark -
#pragma mark 配置友盟
- (void)umengSetting
{
    [MobClick startWithAppkey:UMENG_KEY reportPolicy:SEND_ON_EXIT channelId:@"App Store"];
    //在线参数配置
    [MobClick setAppVersion:XcodeAppVersion];
}

- (void)setHistoryData
{
    NSArray *array = [userdefault objectForKey: kCommArray];
    NSMutableArray *hisArray = [[NSMutableArray alloc] init];
    if (array && array.count > 0) {
        for (NSData *data in array) {
            UserModel *user = [NSKeyedUnarchiver unarchiveObjectWithData:data];
            [hisArray addObject:user];
        }
    }
    [CommonUtil defaultUtil].commArray = [NSArray arrayWithArray:hisArray];
}

- (void)getConfig
{
    NetworkingManager *manager = [NetworkingManager manager];
    [manager getSystemConfigureSuccess:^(NSURLSessionDataTask *task, id responseObject) {
        NSDictionary *result = (NSDictionary *)responseObject;
        NSNumber *stateNum = [result objectForKey:@"state"];
        NSLog(@"system config result = %@",result);
        if (stateNum.intValue == 10000) {
            NSLog(@"getSystemConfigSuccess");
            NSDictionary *config = [result objectForKey:@"SystemConfigure"];
            //约会请求时间
            NSNumber *l_t = [config objectForKey:@"l_t"];
            NSNumber *m_t = [config objectForKey:@"m_t"];
            NSNumber *total_t = [config objectForKey:@"total_t"];
            NSNumber *rate_t = [config objectForKey:@"rate_t"];
            NSNumber *page_size = [config objectForKey:@"page_size"];
            NSNumber *fill_size = [config objectForKey:@"fill_size"];
            NSNumber *user_report_num = [config objectForKey:@"user_report_num"];
            NSNumber *pic_report_num = [config objectForKey:@"pic_report_num"];
            NSNumber *user_freez_len = [config objectForKey:@"user_freez_len"];
            NSNumber *distance = [config objectForKey:@"distance"];
            NSNumber *imflag = [config objectForKey:@"imflag"];
            
            [userdefault setObject:l_t forKey:kDataTime];
            [userdefault setObject:m_t forKey:kCommTime];
            [userdefault setObject:total_t forKey:kTotalTime];
            [userdefault setObject:rate_t forKey:kRateTime];
            [userdefault setObject:page_size forKey:kPageSize];
            [userdefault setObject:fill_size forKey:kFillSize];
            [userdefault setObject:user_report_num forKey:kUserReportNum];
            [userdefault setObject:pic_report_num forKey:kPicReportNum];
            [userdefault setObject:user_freez_len forKey:kFreezLen];
            [userdefault setObject:distance forKey:kDistance];
            [userdefault setObject:imflag forKey:kImFlag];
            [userdefault synchronize];
        }
    } error:^(NSError *err) {
        NSLog(@"systemConfig Error= %@",err.localizedDescription);
    }];
    
    [self setFixTime];
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    NSLog(@"did become active");
    NSNumber *isRequest = [userdefault objectForKey:kIsRequesting];
    if (isRequest && isRequest.boolValue) {
        [[NSNotificationCenter defaultCenter] postNotificationName:kRefreshFeedList object:nil];
    }
    [self setFixTime];
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

- (void)application:(UIApplication *)application didReceiveLocalNotification:(UILocalNotification *)notification
{
    NSLog(@"notification = %@",notification);
    
}

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo
{
//    NSLog(@"RemoteNotiuserInfo = %@",userInfo);
    [self.push application:application didReceiveRemoteNotification:userInfo];
}

- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken
{
    NSLog(@"GOTTOKEN");
    NSRange range = NSMakeRange(1,[[deviceToken description] length]-2);
    NSString *dToken = [[deviceToken description] substringWithRange:range];
    NSLog(@"deviceTokenStr==%@",dToken);
    NSString *token = [[NSUserDefaults standardUserDefaults] objectForKey:kPushToken];
    if (!token) {
        [userdefault setObject:dToken forKey:kPushToken];
        [userdefault synchronize];
    }
    [self.push application:application didRegisterForRemoteNotificationsWithDeviceToken:deviceToken];
}

- (void)application:(UIApplication *)application didRegisterUserNotificationSettings:(UIUserNotificationSettings *)notificationSettings
{
    [application registerForRemoteNotifications];
}

- (void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error
{
    NSLog(@"push token faild =%@",error.description);
}


- (void)managedPush:(id<SINManagedPush>)managedPush didReceiveIncomingPushWithPayload:(NSDictionary *)payload forType:(NSString *)pushType
{
    NSLog(@"payload = %@",payload);
    [[NSNotificationCenter defaultCenter] postNotificationName:kRefreshFeedList object:nil];
    NSLog(@"push Type = %@",pushType);
}

- (void)setFixTime
{
    [[NetworkingManager manager] syncTimeSuccess:^(NSURLSessionDataTask *task, id respsonseObject)  {
        NSDictionary *result = (NSDictionary *)respsonseObject;
        NSNumber *stateNum = [result objectForKey:@"state"];
        if (stateNum.intValue == 10000) {
            NSDate *date = [NSDate date];
            NSTimeInterval interval = [date timeIntervalSince1970] * 1000;
            NSNumber *time = [result objectForKey:@"systime"];
            NSTimeInterval fixTime = time.longValue - interval;
//            if (fixTime < -10000 || fixTime > 10000) {
                [CommonUtil defaultUtil].fixTime = fixTime;
//            }else{
//                [CommonUtil defaultUtil].fixTime = 0;
//            }
            [[NSNotificationCenter defaultCenter] postNotificationName:@"changeTime" object:nil];
            NSLog(@"fixtime = %ld",[CommonUtil defaultUtil].fixTime);
        }
    } error:^(NSError *err) {
        
    }];
}
- (void)registNotification{
    if([[[UIDevice currentDevice]systemVersion] floatValue] >= 8.0){
        [[UIApplication sharedApplication] registerForRemoteNotifications];
        [[UIApplication sharedApplication] registerUserNotificationSettings:[UIUserNotificationSettings settingsForTypes:UIUserNotificationTypeAlert|UIUserNotificationTypeBadge|UIUserNotificationTypeSound categories:nil]];
    }else{
        [[UIApplication sharedApplication] registerForRemoteNotificationTypes:(UIRemoteNotificationTypeBadge | UIRemoteNotificationTypeSound | UIRemoteNotificationTypeAlert)];
    }
}
- (void)cancelNotification{
    [[UIApplication sharedApplication] cancelAllLocalNotifications];
    [[UIApplication sharedApplication] setApplicationIconBadgeNumber:0];
}


@end

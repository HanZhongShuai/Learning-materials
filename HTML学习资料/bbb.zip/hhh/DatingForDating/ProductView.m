//
//  ProductView.m
//  DatingForDating
//
//  Created by MAXToooNG on 16/5/3.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import "ProductView.h"

@implementation ProductView
- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        [self initViews];
    }
    return self;
}

- (void)initViews
{
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] init];
    [tap addTarget:self action:@selector(dismissView)];
    [self addGestureRecognizer:tap];
     CGRect f = CGRectMake(20, 100 - 44 , windowWidth() - 40, windowHeight() - 200);
    UIView *alertView = [[UIView alloc] initWithFrame:f];
    alertView.backgroundColor = colorWithHexString(@"fafafa");
    [self addSubview:alertView];
    self.backgroundColor = colorWithHexString(@"#181818");
    UILabel *textView1 = [[UILabel alloc] initWithFrame:CGRectMake(80, setH(30), alertView.frame.size.width - 160, 65)];
    textView1.textAlignment = NSTextAlignmentCenter;
    textView1.text = @"Become a VIP to meet hot girls";
    textView1.textColor = colorWithHexString(@"#fa5b3a");
    textView1.font = [UIFont boldSystemFontOfSize:28];
    textView1.adjustsFontSizeToFitWidth = YES;
    textView1.minimumScaleFactor = 0.5;
    textView1.numberOfLines = 2;

    UIImageView *backView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, setW(132), setW(132))];
    backView.center = CGPointMake(alertView.frame.size.width  / 2, alertView.frame.size.height / 2 - 30);
    backView.image = [UIImage imageNamed:@"Diamond_p"];
    [alertView addSubview:backView];
    [alertView addSubview:textView1];
    
    UIImageView *vipView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, setW(56), setW(58))];
    vipView.image = [UIImage imageNamed:@"vip"];
    vipView.center = CGPointMake(alertView.frame.size.width / 2, alertView.frame.size.height / 2 - setH(60));
    [alertView addSubview:vipView];
    
    UIButton *sevenDayBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    sevenDayBtn.frame = CGRectMake(10, 0, alertView.frame.size.width - 20, 43);
    [sevenDayBtn setTitle:@"7 Days for $9.99" forState:UIControlStateNormal];
    [sevenDayBtn setTitleColor:colorWithHexString(@"#fa5b3a") forState:UIControlStateNormal];
    sevenDayBtn.titleLabel.font = fontWithSize(20);
    [sevenDayBtn.layer setBorderWidth:1];
    [sevenDayBtn.layer setBorderColor:colorWithHexString(@"#fa5b3a").CGColor];
    [sevenDayBtn addTarget:self action:@selector(buySevenDayOnClicked) forControlEvents:UIControlEventTouchUpInside];
    sevenDayBtn.center = CGPointMake(alertView.frame.size.width / 2, alertView.frame.size.height / 2 );
    [alertView addSubview:sevenDayBtn];
    
    UIButton *oneMonthBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    oneMonthBtn.frame = CGRectMake(10, sevenDayBtn.frame.origin.y + sevenDayBtn.frame.size.height + 11, alertView.frame.size.width - 20, 43);
    [oneMonthBtn setTitle:@"1 Month for $29.99" forState:UIControlStateNormal];
    [oneMonthBtn setTitleColor:colorWithHexString(@"#fa5b3a") forState:UIControlStateNormal];
    oneMonthBtn.titleLabel.font = fontWithSize(20);
    [oneMonthBtn.layer setBorderWidth:1];
    [oneMonthBtn.layer setBorderColor:colorWithHexString(@"#fa5b3a").CGColor];
    [oneMonthBtn addTarget:self action:@selector(buyOneMonthOnClicked) forControlEvents:UIControlEventTouchUpInside];
    [alertView addSubview:oneMonthBtn];

    
    UIButton *sixMonthBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    sixMonthBtn.frame = CGRectMake(10, oneMonthBtn.frame.origin.y + oneMonthBtn.frame.size.height + 11, alertView.frame.size.width - 20, 43);
    [sixMonthBtn setTitle:@"6 Months for $59.99" forState:UIControlStateNormal];
    [sixMonthBtn setTitleColor:colorWithHexString(@"#ffffff") forState:UIControlStateNormal];
    sixMonthBtn.titleLabel.font = fontWithSize(20);
    [sixMonthBtn setBackgroundColor:colorWithHexString(@"#fa5b3a")];
    [sixMonthBtn addTarget:self action:@selector(buySixMonthOnClicked) forControlEvents:UIControlEventTouchUpInside];
    [alertView addSubview:sixMonthBtn];

    UIImageView *saveView = [[UIImageView alloc] initWithFrame:CGRectMake(sixMonthBtn.frame.size.width - 43, -8, 48, 48)];
    saveView.image = [UIImage imageNamed:@"ic_biaoqian"];
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(12, 4, 31, 30)];
    label.text = @"SAVE 70%";
    label.font = [UIFont boldSystemFontOfSize:11];
    label.textColor = colorWithHexString(@"#ffffff");
    label.textAlignment = NSTextAlignmentRight;
    label.numberOfLines = 2;
    label.minimumScaleFactor = 0.5;
    label.adjustsFontSizeToFitWidth = YES;
    [saveView addSubview:label];
    
    [sixMonthBtn addSubview:saveView];
}

- (void)buySixMonthOnClicked
{
    self.buySixMonth();
}

- (void)buyOneMonthOnClicked
{
    self.buyOneMonth();
}

- (void)buySevenDayOnClicked
{
    self.buySevenDay();
}

- (void)dismissView
{
    [self removeFromSuperview];
}

@end

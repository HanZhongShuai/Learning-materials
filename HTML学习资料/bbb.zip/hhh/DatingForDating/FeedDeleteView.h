//
//  FeedDeleteView.h
//  DatingForDating
//
//  Created by MAXToooNG on 16/4/19.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FeedDeleteView : UIView

@property (nonatomic, strong) UIButton *deleteBtn;
@property (nonatomic, strong) UILabel *timeLabel;
- (instancetype)initWithFrame:(CGRect)frame;
@end

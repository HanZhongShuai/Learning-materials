//
//  ProductView.h
//  DatingForDating
//
//  Created by MAXToooNG on 16/5/3.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^BuySixMonth)(void);
typedef void(^BuySevenDay)(void);
typedef void(^BuyOneMonth)(void);
@interface ProductView : UIView

@property (nonatomic, strong) BuySixMonth buySixMonth;
@property (nonatomic, strong) BuyOneMonth buyOneMonth;
@property (nonatomic, strong) BuySevenDay buySevenDay;

@end

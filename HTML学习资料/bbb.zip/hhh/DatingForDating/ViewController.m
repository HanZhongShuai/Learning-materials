//
//  ViewController.m
//  DatingForDating
//
//  Created by MAXToooNG on 16/3/15.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import "ViewController.h"
#import "RequestViewController.h"
#import "Public.h"
#import "TermsViewController.h"
#import "NetworkingManager.h"
#import "UIButton+imageAndLabel.h"
@import MapKit;

@interface ViewController () <UIAlertViewDelegate>
@property (weak, nonatomic) IBOutlet UIButton *femaleButton;
@property (weak, nonatomic) IBOutlet UIButton *maleButton;
@property (weak, nonatomic) IBOutlet UIButton *registerButton;
@property (weak, nonatomic) IBOutlet UILabel *tipsLabel;
@property (nonatomic, strong) UIView *loadingView;
@property (nonatomic, assign) NSInteger gender;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topWidthConstraints;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *registerBtnWidthConstraint;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.topWidthConstraints.constant = windowWidth() - 50;
    self.loadingView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, windowWidth(), windowHeight())];
//    [self.view addSubview:self.loadingView];
    UILabel *loading = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, windowWidth(), 200)];
    loading.text = @"LOADING";
    loading.center = CGPointMake(windowWidth()/2, self.loadingView.frame.size.height / 2);
    [self.loadingView addSubview:loading];

//    [self login];
    [self.maleButton setImage:[UIImage imageNamed:@"sign_ic_male_nor"] withTitle:@"Male" forState:UIControlStateNormal];
    [self.maleButton setImage:[UIImage imageNamed:@"sign_ic_male_pre"] withTitle:@"Male" forState:UIControlStateSelected];
    
    [self.femaleButton setImage:[UIImage imageNamed:@"sign_ic_female_nor"] withTitle:@"Female" forState:UIControlStateNormal];
    [self.femaleButton setImage:[UIImage imageNamed:@"sign_ic_female_pre"] withTitle:@"Female" forState:UIControlStateSelected];
    self.registerBtnWidthConstraint.constant = windowWidth() - 50;
    self.registerButton.layer.borderWidth = 1;
    [self.registerButton.layer setBorderColor:colorWithHexString(@"#fa5b3a").CGColor];
}

- (void)awakeFromNib
{
//    [super awakeFromNib];
//    [self.maleButton setImage:[UIImage imageNamed:@"sign_ic_female_nor"] withTitle:@"MAN" forState:UIControlStateNormal];
//    [self.maleButton setImage:[UIImage imageNamed:@"sign_ic_female_pre"] withTitle:@"MAN" forState:UIControlStateSelected];

}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changeToken) name:NSUbiquityIdentityDidChangeNotification object:nil];
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:LocalizedString(@"term_of_us", nil) message:LocalizedString(@"terms",nil) delegate:self cancelButtonTitle:LocalizedString(@"review", nil) otherButtonTitles:LocalizedString(@"accept", nil), nil] ;
    [alertView show];
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeSystem];
    [btn setFrame:CGRectMake(0, 0, 44, 44)];
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc] initWithCustomView:btn];
    self.navigationItem.leftBarButtonItem = leftItem;
}

- (void)registUser{
    NSNumber *userGender = [NSNumber numberWithInteger:self.gender];
    [userdefault setObject:userGender forKey:kGender];
    [userdefault synchronize];
    NSString *pushToken = [userdefault objectForKey:kPushToken];
    if (!pushToken) {
        pushToken = @"";
        NSLog(@"push Token ===== nil");
    }
    NetworkingManager *manage = [NetworkingManager manager];
    [manage registWithGender:self.gender uniquToken:[userdefault objectForKey:kiCloudToken] pushToken:pushToken success:^(NSURLSessionDataTask *task, id responseObject) {
        NSDictionary *result = (NSDictionary *)responseObject;
        NSNumber *stateNum = [result objectForKey:@"state"];
        if (stateNum.intValue == 10000) {
            NSNumber *userId = [result objectForKey:@"userid"];
            [userdefault setObject:userId forKey:kUserId];
            NSString *userToken = [result objectForKey:@"usertoken"];
            [userdefault setObject:userToken forKey:kUserToken];
            [userdefault synchronize];
            
            NSLog(@"regist Success");
        }
        } error:^(NSError *e){
    
        }];
}

- (void)viewDidAppear:(BOOL)animated
{
//    NSNumber *isFirst = [userdefault objectForKey:@"isFirstLaunch"];
//    if (isFirst && !isFirst.boolValue) {
//        [self intentToRequest];
//    }else{
//        
//    }
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 200, 44)];
    titleLabel.text = @"Sign Up";
    titleLabel.font = fontWithSize(20);
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.textColor = [UIColor whiteColor];
    self.navigationItem.titleView = titleLabel;
    
//    NSString *token = [userdefault objectForKey:kiCloudToken];
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changeToken) name:NSUbiquityIdentityDidChangeNotification object:nil];
//    if (token) {
//        [self intentToRequest];
//    }else{
//        NSLog(@"token = %@",[[NSFileManager defaultManager] ubiquityIdentityToken]);
//        NSURL *url  = [[NSFileManager defaultManager] URLForUbiquityContainerIdentifier:nil];
//        NSLog(@"url String = %@",[NSString stringWithContentsOfURL:url encoding:NSDataBase64Encoding64CharacterLineLength error:nil]);
//        id ubiquity = [[NSFileManager defaultManager] ubiquityIdentityToken];
//        NSRange range = NSMakeRange(1,[[ubiquity description] length]-2);
//        NSString *string = [ubiquity description];
//        NSString *ubiquityToken = [string substringWithRange:range];
//        [userdefault setObject:ubiquityToken forKey:kiCloudToken];
//        [userdefault synchronize];
//    }
    
}


- (void)changeToken
{
    NSLog(@"change Token = %@",[[NSFileManager defaultManager] ubiquityIdentityToken]);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)alertPrivacy:(id)sender {
    [self intentToRequest];
   
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    switch (buttonIndex) {
        case 0:
        {
            TermsViewController *termsVC = [[TermsViewController alloc] init];
            [self.navigationController pushViewController:termsVC animated:YES];

        }
            break;
        case 1:
        {
            
        }
            break;
        default:
            break;
    }
   
}
- (IBAction)femaleButtonOnClicked:(id)sender {
    self.femaleButton.selected = !self.femaleButton.selected;
    if (self.femaleButton.selected) {
        self.gender = 0;
        self.maleButton.selected = NO;
        self.tipsLabel.hidden = NO;
        self.registerButton.hidden = NO;
    }else{
        
        self.tipsLabel.hidden = YES;
        self.registerButton.hidden = YES;
    }
}
- (IBAction)maleButtonOnClicked:(id)sender {
    self.maleButton.selected = !self.maleButton.selected;
    if (self.maleButton.selected) {
        self.gender = 1;
        self.femaleButton.selected = NO;
        self.tipsLabel.hidden = NO;
        self.registerButton.hidden = NO;
    }else{
        self.tipsLabel.hidden = YES;
        self.registerButton.hidden = YES;
    }
}

- (void)intentToRequest
{
    [self registUser];
    RequestViewController *rVC = [self.storyboard instantiateViewControllerWithIdentifier:@"RequestVC"];
//    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:rVC];
//    [self presentViewController:nav animated:NO completion:^{
    
//    }];
    [self.navigationController pushViewController:rVC animated:NO];
}
@end

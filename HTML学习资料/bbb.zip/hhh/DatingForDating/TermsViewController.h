//
//  TermsViewController.h
//  DatingForDating
//
//  Created by MAXToooNG on 16/3/28.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TermsViewController : UIViewController

@end

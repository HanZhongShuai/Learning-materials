//
//  LoadingAnimationView.h
//  DatingForDating
//
//  Created by MAXToooNG on 16/4/25.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoadingAnimationView : UIView

- (void)resume;
- (void)callSuperRemoveFromSuperview;
@end

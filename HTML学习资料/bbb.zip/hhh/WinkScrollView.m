//
//  WinkScrollView.m
//  DatingForDating
//
//  Created by MAXToooNG on 16/4/21.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import "WinkScrollView.h"

@implementation WinkScrollView
-(BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer {
    if (gestureRecognizer.state != 0) {
        return YES;
    } else {
        return NO;
    }
}

@end

//
//  BannedView.h
//  DatingForDating
//
//  Created by MAXToooNG on 16/4/27.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void(^LinkClicked)(void);
typedef void(^AppearClicked)(void);
@interface BannedView : UIView <UITextViewDelegate>
@property (nonatomic, copy) LinkClicked linkClicked;
@property (nonatomic, copy) AppearClicked apperaClicked;
@property (nonatomic, strong) UILabel *timeLabel;
@end

//
//  AdView.m
//  DatingForDating
//
//  Created by MAXToooNG on 16/4/28.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import "AdView.h"

@interface AdView ()
@property (nonatomic, strong) UIImageView *imageView;
@property (nonatomic, strong) UIScrollView *scrollView;
@property (nonatomic, strong) UIImageView *bottomView;
@end

@implementation AdView

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame: frame]) {
        [self initView];
    }
    return self;
}

- (void)initView
{
    self.backgroundColor = colorWithHexString(@"#181818");
    self.scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(25, 0, self.frame.size.width - 50, self.frame.size.height - 75)];
    self.scrollView.showsVerticalScrollIndicator = NO;
    self.scrollView.showsHorizontalScrollIndicator = NO;
    [self addSubview:self.scrollView];
    
    self.imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, self.scrollView.frame.size.width, self.scrollView.frame.size.width * 6.2)];
    self.imageView.image = [UIImage imageNamed:@"pay_pic.jpg"];
    self.imageView.contentMode = UIViewContentModeScaleAspectFit;
    [self.scrollView addSubview:self.imageView];
    [self.scrollView setContentSize:CGSizeMake(0, self.imageView.frame.size.height)];
    self.bottomView = [[UIImageView alloc] initWithFrame:CGRectMake(0,self.frame.size.height - 75, windowWidth(), 75)];
    self.bottomView.userInteractionEnabled = YES;
    self.bottomView.image = [UIImage imageNamed:@"pay_bg_bt"];
    [self addSubview:self.bottomView];
    
    self.buyBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    [self.buyBtn setTintColor:colorWithHexString(@"fa5b3a")];
    self.buyBtn.frame = CGRectMake(15, 18, windowWidth() - 30, 50);
    [self.buyBtn.layer setBorderWidth:1];
    [self.buyBtn.layer setBorderColor:colorWithHexString(@"#fa5b3a").CGColor];
    self.buyBtn.titleLabel.font = fontWithSize(16);
    [self.buyBtn setTitle:LocalizedString(@"free",nil) forState:UIControlStateNormal];
    [self.buyBtn addTarget:self action:@selector(buy:) forControlEvents:UIControlEventTouchUpInside];
    
    [self.bottomView addSubview:self.buyBtn];
}

- (void)buy:(UIButton *)btn
{
    self.buy();
}

@end

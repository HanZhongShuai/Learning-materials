//
//  BigImageViewController.m
//  DatingForDating
//
//  Created by MAXToooNG on 16/4/21.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import "BigImageViewController.h"
#import "UIImageView+WebCache.h"

@interface BigImageViewController ()
@property (nonatomic, strong) UIImageView *imageView;
@end

@implementation BigImageViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = colorWithHexString(@"#181818");
    self.imageView = [[UIImageView alloc] initWithFrame:self.view.bounds];
    [self.view addSubview:self.imageView];
    self.imageView.contentMode = UIViewContentModeScaleAspectFit;
    [self.imageView sd_setImageWithURL:self.imageUrl];
    self.imageView.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismiss:)];
    [self.imageView addGestureRecognizer:tap];

}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    UIButton *leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [leftBtn setImage:[UIImage imageNamed:@"title_ic_back_nor"] forState:UIControlStateNormal];
    [leftBtn setImage:[UIImage imageNamed:@"title_ic_back_pre"] forState:UIControlStateHighlighted];
    leftBtn.frame = CGRectMake(0, 0, 44, 44);
    [leftBtn addTarget:self action:@selector(back:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc] initWithCustomView:leftBtn];
    self.navigationItem.leftBarButtonItems = @[fixBarButtonItem(),leftItem];
}

- (void)back:(UIButton *)btn
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)dismiss:(UITapGestureRecognizer *)tap
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

@end

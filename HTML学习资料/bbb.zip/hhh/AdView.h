//
//  AdView.h
//  DatingForDating
//
//  Created by MAXToooNG on 16/4/28.
//  Copyright © 2016年 MaxToooNG. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void(^BuyClicked)(void);
@interface AdView : UIView
@property (nonatomic, strong) UIButton *buyBtn;
@property (nonatomic, strong) BuyClicked buy;
@end

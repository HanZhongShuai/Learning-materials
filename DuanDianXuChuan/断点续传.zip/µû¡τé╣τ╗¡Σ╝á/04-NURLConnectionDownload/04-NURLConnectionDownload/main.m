//
//  main.m
//  04-NURLConnectionDownload
//
//  Created by 夏婷 on 16/2/25.
//  Copyright © 2016年 夏婷. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}

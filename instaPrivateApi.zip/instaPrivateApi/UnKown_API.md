instaPrivateAPI      unkown  需要查找的API
===============

应用名称

instaReport

























不确定


POST 
http://i.instagram.com/api/v1/qe/expose/ HTTP/1.1" 200 - "-" "Instagram 6.0.1 (iPhone2,1; iPhone OS 6_1_6; en_SG; en) AppleWebKit/420+"

POST http://i.instagram.com/api/v1/qe/sync/ 

POST  http://i.instagram.com/api/v1/media/480626682060264604_416629532/delete/?media_type=1




instaPrivateAPI_______已经了解并且可以运用的私有API列表
===============

===========POST请求===========
1.    登录
https://i.instagram.com/api/v1/accounts/login/

2.    like
https://i.instagram.com/api/v1/media/mediaID/like/?d=0&src=timeline 

3.    follow
https://i.instagram.com/api/v1/friendships/create/userID/

4.    取消拉黑
https://i.instagram.com/api/v1/friendships/unblock/userID/

5.    拉黑某个用户
https://i.instagram.com/api/v1/friendships/block/1500496607/

6.    评论
https://i.instagram.com/api/v1/media/486557604074960602_261092508/comment/           key：comment_text
/*
@{@"_uuid":@"8E620E94-8CF1-4389-9360-CEDC7742C998",@"_uid":selfId,@"comment_text":@"good",@"_csfrtoken":@"db906fa9a02ee7f28dd510fa7ec3315b"};
*/

7.    设置为私有用户
https://i.instagram.com/api/v1/accounts/set_private/
/*
@{@"csrftoken":selfCsrftoken,@"ds_user":selfName,@"ds_user_id":selfId,@"igfl":selfName,@"is_starred_enabled":@"yes"}
*/

8.    设置为共有用户
https://i.instagram.com/api/v1/accounts/set_public/（同上）

9.    退出登陆
https://i.instagram.com/api/v1/accounts/logout/



===========GET请求===========


1.    按照用户名查找  (已经被移除,寻找替代方法)
http://i.instagram.com/api/v1/users/search?query=userName
http://i.instagram.com/api/v1/fbsearch/topsearch/?query=userName（可用）

2.    feed popular
http://i.instagram.com/api/v1/feed/popular/

3.    feed timeline
http://i.instagram.com/api/v1/feed/timeline/

4.    feed myMedia
http://i.instagram.com/api/v1/feed/user/1993037354/
http://i.instagram.com/api/v1/feed/user/194653826/?max_id=651831711473847775_194653826

5.    关注别人列表
http://i.instagram.com/api/v1/friendships/autocomplete_user_list/

6.    最近相互关注列表
https://i.instagram.com/api/v1/direct_share/recent_recipients/

7.    推荐关注人列表
http://i.instagram.com/api/v1/friendships/suggested/

8.    获取某个media的信息
http://i.instagram.com/api/v1/media/486557604074960602_261092508/info/

9     news 动态栏 正在关注页面
http://i.instagram.com/api/v1/news/

10     news 动态栏 自己信息
http://i.instagram.com/api/v1/news/inbox

11    feed tag
http://i.instagram.com/api/v1/feed/tag/tagName/

12    
http://i.instagram.com/api/v1/friendships/show/1037051608/

12    获取关注  
http://i.instagram.com/api/v1/friendships/following/

13    获取粉丝
http://i.instagram.com/api/v1/friendships/followers/

14    获取media的like
http://i.instagram.com/api/v1/media/1044798097628187013_49147161/likers/

15    获取media的comment
http://i.instagram.com/api/v1/media/1044798097628187013_49147161/comments/

16   获取和某个用户的关系（包括黑名单、私有用户等）
http://i.instagram.com/api/v1/friendships/show/227129706/

17.    userInfo  用户信息 可判断私有用户
https://i.instagram.com/api/v1/users/userID/info/

18.    最近我like过的media
https://i.instagram.com/api/v1/feed/liked/?max_id=1132403070820033211




















=======
8.    获取某个media的信息
http://i.instagram.com/api/v1/media/486557604074960602_261092508/info/
>>>>>>> 83fd74e0b72becb7275b28d93a1624262be88934

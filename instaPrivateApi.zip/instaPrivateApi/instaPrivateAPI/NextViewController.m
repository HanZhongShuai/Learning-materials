//
//  NextViewController.m
//  instaPrivateAPI
//
//  Created by RC on 15/12/7.
//  Copyright © 2015年 RC. All rights reserved.
//

#import "NextViewController.h"
#import "FBSig.h"

#define windowWidth [UIScreen mainScreen].bounds.size.width
#define windowHeight [UIScreen mainScreen].bounds.size.height
@interface NextViewController ()<UITableViewDataSource, UITableViewDelegate>
{
    NSString *kStringBoundary;
    NSString *kUserAgent;
    NSDictionary *headerDic;
    NSString *ig_key_version;
    NSString *ig_key;
    
    NSString *videoId;
}
@property (nonatomic, strong) UITableView *table;
@property (nonatomic, strong) NSMutableArray *dataArray;
@property (nonatomic, copy) NSString *userId;
@property (nonatomic, copy) NSString *userName;
@property (nonatomic, copy) NSString *userImage;
@property (nonatomic, copy) NSString *userToken;
@property (nonatomic, copy) NSString *userCsrftoken;
@property (nonatomic, copy) NSString *device_id;
@end

@implementation NextViewController
@synthesize userCsrftoken,userId,userImage,userName,userToken,dataArray,table;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor colorWithRed:0.9451 green:0.9451 blue:0.9451 alpha:1.0];
    [self initData];
    [self initViews];
}
- (void)initData
{
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    userId = [userDefaults objectForKey:kUserId];
    userName = [userDefaults objectForKey:kUsername];
    userImage = [userDefaults objectForKey:kPic];
    userCsrftoken = [userDefaults objectForKey:ctoken];
    
    dataArray = [[NSMutableArray alloc] initWithObjects:@"like",@"follow",@"拉黑",@"取消拉黑",@"评论",@"私有用户",@"最近我的like",@"feed myMedia",@"获取media的like",@"获取关注",@"media info",@"发送消息",@"add", nil];
    
    kStringBoundary = [NSString getUniqueStrByUUID];
    
    ig_key = [userDefault objectForKey:igkey];
    NSString *keyAgentVersion = [userDefault objectForKey:igversion];
    NSArray *keyArr = [keyAgentVersion componentsSeparatedByString:@"|"];
    ig_key_version = [keyArr firstObject];
    NSString *ig_agent = [keyArr lastObject];
    self.device_id = [userDefault objectForKey:deviceID];
    NSString *device_info = @"(15/4.0.4; 160dpi; 320x480; Sony; MiniPro; mango; semc; en_Us)";
    kUserAgent = [NSString stringWithFormat:@"%@%@", ig_agent,device_info];
    NSString* contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=%@", kStringBoundary];
    headerDic = @{@"User-Agent":kUserAgent, @"Content-Type":contentType, @"Accept-Language" : @"en;q=1, zh-Hans;q=0.9, ja;q=0.8, zh-Hant;q=0.7, fr;q=0.6, de;q=0.5"};
//    GET的
    NSMutableDictionary *cookieDic = [NSMutableDictionary dictionary];
    NSMutableString *cookieStr = [NSMutableString stringWithString:@""];

    NSArray *cookies = [[NSHTTPCookieStorage sharedHTTPCookieStorage] cookies];
    for (NSHTTPCookie *cookie in cookies) {
        [cookieDic setObject:cookie.value forKey:cookie.name];
        if (cookieStr.length > 0) {
            [cookieStr appendString:@";"];
        }
        NSString *str = [NSString stringWithFormat:@"%@=%@",cookie.name,cookie.value];
        [cookieStr appendString:str];
    }
    NSLog(@"cookies -- %@",cookieDic);
    
    headerDic = @{@"X-IG-Capabilities":@"nw==",@"Cookie":cookieStr,@"Connection":@"keep-alive",@"Proxy-Connection":@"keep-alive",@"Accept":@"*/*",@"User-Agent":kUserAgent,@"Accept-Language" : @"en;q=1, zh-Hans;q=0.9, ja;q=0.8, zh-Hant;q=0.7, fr;q=0.6, de;q=0.5",@"Accept-Encoding":@"gzip, deflate",@"X-IG-Connection-Type": @"WiFi"};
//    POST的
//    headerDic = @{@"X-IG-Capabilities":@"Nw==",@"User-Agent":kUserAgent,@"Proxy-Connection":@"keep-alive",@"X-IG-Connection-Type": @"WiFi", @"Content-Type":contentType, @"Accept-Language" : @"en;q=1, zh-Hans;q=0.9, ja;q=0.8, zh-Hant;q=0.7, fr;q=0.6, de;q=0.5"};
    self.device_id = [userDefault objectForKey:deviceID];
    
}

- (void)initViews
{
    UIButton *logOut = [UIButton buttonWithType:UIButtonTypeCustom];
    logOut.frame = CGRectMake(windowWidth - 50, 25, 50, 30);
    [logOut setTitle:@"退出" forState:UIControlStateNormal];
    [logOut setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [logOut addTarget:self action:@selector(pressLogOut:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:logOut];
    
    table = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, windowWidth, windowHeight - 64) style:UITableViewStylePlain];
    table.delegate = self;
    table.dataSource = self;
    table.backgroundColor = [UIColor colorWithRed:247/255.0 green:247/255.0 blue:247/255.0 alpha:1.0];
    table.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.view addSubview:table];
}
- (void)pressLogOut:(UIButton *)btn
{
    
    //https://i.instagram.com/api/v1/accounts/logout/
    NSDictionary *followParams = @{@"csrftoken":userCsrftoken,@"ds_user":userName,@"ds_user_id":userId,@"igfl":userName,@"is_starred_enabled":@"yes"};
    NSMutableData *bodyData = [NSMutableData generatePostBodyWithRequestBody:followParams Boundary:kStringBoundary];
    [[AFInstagramManager shareManager] likeRequestWithUrl:@"https://i.instagram.com/api/v1/accounts/logout/" header:headerDic body:bodyData timeoutInterVal:20 result:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSLog(@"退出登陆%@",responseObject);
        if ([[responseObject objectForKey:@"status"] isEqualToString:@"ok"]) {
            [userDefault setObject:[NSNumber numberWithInteger:0] forKey:kIsLogin];
            [userDefault synchronize];
            [self dismissViewControllerAnimated:YES completion:nil];
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"error:%@", operation.responseObject);
    }];
    
}
#pragma mark - UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    return 30;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *string = @"users";
    
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:string];
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:string];
    }
    cell.textLabel.text = dataArray[indexPath.row];
    return cell;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return dataArray.count;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    
    switch (indexPath.row) {
        case 0:
        {
//            @"like"
            
            NSString *mediaId = @"1261081403932509317_2903949064";
            NSDictionary *likeParams = @{@"photo_id":mediaId,@"_uuid":@"8E620E94-8CF1-4389-9360-CEDC7742C998"};
            NSString *sign_body = [self makeApiCallWithMethod:@"Like" Params:likeParams Ssl:NO Use_cookie:userCsrftoken];
            NSDictionary *requestBody = @{@"ig_sig_key_version" : ig_key_version, @"signed_body" : sign_body};
            NSMutableData *bodyData = [NSMutableData generatePostBodyWithRequestBody:requestBody Boundary:kStringBoundary];
            
            [[AFInstagramManager shareManager] likeRequestWithUrl:@"https://i.instagram.com/api/v1/media/mediaID/like/?d=0&src=timeline" header:headerDic body:bodyData timeoutInterVal:20 result:^(AFHTTPRequestOperation *operation, id responseObject) {
                NSLog(@"like -- %@",responseObject);
            } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                NSLog(@"like -- error:%@", operation.responseObject);
            }];
            
        }
            break;
        case 1:
        {
//            @"follow"
            
            NSDictionary *followParams = @{@"_uuid":@"8E620E94-8CF1-4389-9360-CEDC7742C998",@"_uid":userId,@"user_id":@"1500496607",@"_csfrtoken":@"db906fa9a02ee7f28dd510fa7ec3315b"};
            NSString *sign_body = [self makeApiCallWithMethod:@"Follow" Params:followParams Ssl:NO Use_cookie:userCsrftoken];
            NSDictionary *requestBody = @{@"ig_sig_key_version" : @"4", @"signed_body" : sign_body};
            NSMutableData *bodyData = [NSMutableData generatePostBodyWithRequestBody:requestBody Boundary:kStringBoundary];
            
            [[AFInstagramManager shareManager] followRequestWithUrl:[NSString stringWithFormat: @"https://i.instagram.com/api/v1/friendships/create/%@/", @"1993037354"] header:headerDic body:bodyData timeoutInterVal:20 result:^(AFHTTPRequestOperation *operation, id responseObject) {
                NSLog(@"follow -- %@",responseObject);
            } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                NSLog(@"follow -- %@",error);
                
            }];
        }
            break;
        case 2:
        {
//            ,@"拉黑",
            NSDictionary *followParams = @{@"_uuid":@"8E620E94-8CF1-4389-9360-CEDC7742C998",@"_uid":userId,@"user_id":@"1500496607",@"_csfrtoken":@"db906fa9a02ee7f28dd510fa7ec3315b"};
            NSString *sign_body = [self makeApiCallWithMethod:@"Follow" Params:followParams Ssl:NO Use_cookie:userCsrftoken];
            NSDictionary *requestBody = @{@"ig_sig_key_version" : @"4", @"signed_body" : sign_body};
            NSMutableData *bodyData = [NSMutableData generatePostBodyWithRequestBody:requestBody Boundary:kStringBoundary];
            
            [[AFInstagramManager shareManager] likeRequestWithUrl:[NSString stringWithFormat: @"https://i.instagram.com/api/v1/friendships/block/%@/", @"1500496607"] header:headerDic body:bodyData timeoutInterVal:20 result:^(AFHTTPRequestOperation *operation, id responseObject) {
                NSLog(@"拉黑--%@",responseObject);
            } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                NSLog(@"error:%@", operation.responseObject);
            }];
            
        }
            break;
        case 3:
        {
//            @"取消拉黑",
            NSDictionary *followParams = @{@"_uuid":@"8E620E94-8CF1-4389-9360-CEDC7742C998",@"_uid":userId,@"user_id":@"1500496607",@"_csfrtoken":@"db906fa9a02ee7f28dd510fa7ec3315b"};
            NSString *sign_body = [self makeApiCallWithMethod:@"Follow" Params:followParams Ssl:NO Use_cookie:userCsrftoken];
            NSDictionary *requestBody = @{@"ig_sig_key_version" : @"4", @"signed_body" : sign_body};
            NSMutableData *bodyData = [NSMutableData generatePostBodyWithRequestBody:requestBody Boundary:kStringBoundary];
            
            [[AFInstagramManager shareManager] likeRequestWithUrl:[NSString stringWithFormat: @"https://i.instagram.com/api/v1/friendships/unblock/%@/", @"1500496607"] header:headerDic body:bodyData timeoutInterVal:20 result:^(AFHTTPRequestOperation *operation, id responseObject) {
                NSLog(@"取消拉黑--%@",responseObject);
            } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                NSLog(@"error:%@", operation.responseObject);
            }];
            
        }
            break;
        case 4:
        {
//            @"评论",
            NSString *mediaId = @"1131725972998839868_2157047934";
            NSDictionary *followParams = @{@"_uuid":@"8E620E94-8CF1-4389-9360-CEDC7742C998",@"_uid":userId,@"comment_text":@"hahahah",@"_csfrtoken":@"db906fa9a02ee7f28dd510fa7ec3315b"};
            NSString *sign_body = [self makeApiCallWithMethod:@"Follow" Params:followParams Ssl:NO Use_cookie:userCsrftoken];
            NSDictionary *requestBody = @{@"ig_sig_key_version" : @"4", @"signed_body" : sign_body};
            NSMutableData *bodyData = [NSMutableData generatePostBodyWithRequestBody:requestBody Boundary:kStringBoundary];
            [[AFInstagramManager shareManager] likeRequestWithUrl:[NSString stringWithFormat: @"https://i.instagram.com/api/v1/media/%@/comment/", mediaId] header:headerDic body:bodyData timeoutInterVal:20 result:^(AFHTTPRequestOperation *operation, id responseObject) {
                NSLog(@"评论%@",responseObject);
            } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                NSLog(@"error:%@", operation.responseObject);
            }];
        }
            break;
        case 5:
        {
//            @"私有用户"
            NSDictionary *followParams = @{@"csrftoken":userCsrftoken,@"ds_user":userName,@"ds_user_id":userId,@"igfl":userName,@"is_starred_enabled":@"yes"};
            NSMutableData *bodyData = [NSMutableData generatePostBodyWithRequestBody:followParams Boundary:kStringBoundary];
            [[AFInstagramManager shareManager] likeRequestWithUrl:@"https://i.instagram.com/api/v1/accounts/set_private/" header:headerDic body:bodyData timeoutInterVal:20 result:^(AFHTTPRequestOperation *operation, id responseObject) {
                NSLog(@"私有用户%@",responseObject);
            } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                NSLog(@"error:%@", operation.responseObject);
            }];
        }
            break;
        case 6:
        {
            //            @"最近like"
            NSString *url = @"https://i.instagram.com/api/v1/feed/liked/";
            [[AFInstagramManager shareManager] requestDataWithFrontURL:url method:@"GET" parameter:nil header:headerDic body:nil timeoutInterval:10 result:^(AFHTTPRequestOperation *operation, id responseObject) {
                NSDictionary *resultDic = (NSDictionary *)responseObject;
                NSLog(@"%@",resultDic);
                NSNumber *num = [resultDic objectForKey:@"more_available"];
                if (num.integerValue > 0) {
                    NSDictionary *mediaDic = [[resultDic objectForKey:@"items"] lastObject];
                    NSString *url2 = [NSString stringWithFormat:@"https://i.instagram.com/api/v1/feed/liked/?max_id=%@",[mediaDic objectForKey:@"id"]];
                    [self requestNextWithUrl:url2];
                }
            } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                NSLog(@"%@",error);
            }];
        }
            break;
        case 7:
        {
//            @"feed myMedia",
            NSString *url = @"http://i.instagram.com/api/v1/feed/user/1089637582/";
            [[AFInstagramManager shareManager] requestDataWithFrontURL:url method:@"GET" parameter:nil header:headerDic body:nil timeoutInterval:10 result:^(AFHTTPRequestOperation *operation, id responseObject) {
                NSDictionary *resultDic = (NSDictionary *)responseObject;
                NSLog(@"%@",resultDic);
            } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                NSLog(@"%@",error);
            }];
        }
            break;
        case 8:
        {
//            @"获取media的like",
            NSString *url = @"http://i.instagram.com/api/v1/media/999781266448556188_1450349199/likers/";
            [[AFInstagramManager shareManager] requestDataWithFrontURL:url method:@"GET" parameter:nil header:headerDic body:nil timeoutInterval:10 result:^(AFHTTPRequestOperation *operation, id responseObject) {
                NSDictionary *resultDic = (NSDictionary *)responseObject;
                NSLog(@"%@",resultDic);
            } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                NSLog(@"%@",error);
            }];
        }
            break;
        case 9:
        {
//            @"获取关注"
            NSString *url = @"http://i.instagram.com/api/v1/friendships/following/";
            [[AFInstagramManager shareManager] requestDataWithFrontURL:url method:@"GET" parameter:nil header:headerDic body:nil timeoutInterval:10 result:^(AFHTTPRequestOperation *operation, id responseObject) {
                NSDictionary *resultDic = (NSDictionary *)responseObject;
                NSLog(@"%@",resultDic);
            } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                NSLog(@"%@",error);
            }];
            
            
        }
            break;
        case 10:
        {
//            @"media info"
            videoId = @"1289048618997041593_2157047934";
            NSString *url = [NSString stringWithFormat:@"https://i.instagram.com/api/v1/media/%@/info/",videoId];
            __weak NextViewController *weakSelf = self;
            [[AFInstagramManager shareManager] requestDataWithFrontURL:url method:@"GET" parameter:nil header:headerDic body:nil timeoutInterval:10 result:^(AFHTTPRequestOperation *operation, id responseObject) {
                NSDictionary *resultDic = (NSDictionary *)responseObject;
                NSLog(@"%@",resultDic);
                [weakSelf addPlayTimesWithDic:resultDic];
            } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                NSLog(@"responseObject - %@",operation.responseObject);
                NSLog(@"%@",error);
            }];
        }
            break;
        case 11:
        {
            //            @"发送消息"
            //https://i.instagram.com/api/v1/direct_v2/threads/broadcast/text/
            //  ,@"thread_ids":@"[\"39790511193223379958532271984\"]"
            NSString *clientStr = [NSString getUniqueStrByUUID];
//            NSDictionary *requestBody = @{@"simple_format":@"1",@"client_context":clientStr,@"recipient_users":@"[[\"2157047934\"]]",@"itext":@"han"};
//            NSMutableData *bodyData = [NSMutableData generatePostBodyWithRequestBody:requestBody Boundary:kStringBoundary];
            NSString *requ = [NSString stringWithFormat:@"simple_format=1&client_context=%@&recipient_users=%@&text=%@",clientStr,@"[[\"2157047934\",\"3027225484\"]]",@"http://www.baidu.com"];
            NSData *dd = [requ dataUsingEncoding:NSUTF8StringEncoding];
            NSMutableData *bodyData = [NSMutableData dataWithData:dd];
            [[AFInstagramManager shareManager] likeRequestWithUrl:@"https://i.instagram.com/api/v1/direct_v2/threads/broadcast/text/" header:headerDic body:bodyData timeoutInterVal:20 result:^(AFHTTPRequestOperation *operation, id responseObject) {
                NSLog(@"发送消息%@",responseObject);
            } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                NSLog(@"error:%@", operation.responseObject);
            }];
        }
            break;
        default:
            break;
    }
}

- (void)addPlayTimesWithDic:(NSDictionary *)dic
{
//    NSString *path = [[NSBundle mainBundle] pathForResource:@"videoPlay" ofType:@"plist"];
//    if (path == nil) {
//        return;
//    }
//    NSDictionary *plistDic = [[NSDictionary alloc] initWithContentsOfFile:path];
    //1458016189.562723
//    NSDate *dd = [NSDate dateWithTimeIntervalSince1970:1458016189.562723];
    
    NSString *a_pk = [[[[dic objectForKey:@"items"] objectAtIndex:0] objectForKey:@"user"] objectForKey:@"pk"];
    NSString *tracking_token = [[[dic objectForKey:@"items"] objectAtIndex:0] objectForKey:@"organic_tracking_token"];
    NSString *pk = @"34825004";
    NSNumber *mtsNum = [[[dic objectForKey:@"items"] objectAtIndex:0] objectForKey:@"taken_at"];
    NSString *m_ts = [mtsNum stringValue];
    NSString *m_pk = videoId;
    
    NSArray *dataArr = [self getMediaPlayDataArrWithM_ts:m_ts m_pk:m_pk tracking_token:tracking_token a_pk:a_pk pk:pk];
    
    NSDate *date = [NSDate date];
    NSTimeInterval timeInterval = date.timeIntervalSince1970;
    NSNumber *time = [NSNumber numberWithDouble:timeInterval];
    NSString *idfv = [[[UIDevice currentDevice] identifierForVendor] UUIDString];
    NSString *sessionId = [NSString getUniqueStrByUUID];
    NSDictionary *videoDic = @{@"app_id" : @"124024574287414",@"uid" : @"0",@"app_ver" : @"7.17.1 (23947683)",@"time" : time , @"device_id" : idfv , @"data" : dataArr , @"session_id" : sessionId , @"log_type":@"client_event",@"seq":@0};
    
    NSString *videoDicStr = [NSString sbJsonRecoverDic:videoDic];
    NSDictionary *requestDic = @{@"message" : videoDicStr, @"method" : @"logging.clientevent", @"api_key" : @"124024574287414", @"ios" : @"sdk", @"format" : @"json"};

    NSString *sig = nil;
    sig = [FBSig generateSigWithParams:requestDic andUseSecret:YES];
    NSLog(@"sig = %@",sig);
    requestDic = @{@"sig" : sig, @"message" : videoDicStr, @"method" : @"logging.clientevent", @"api_key" : @"124024574287414", @"ios" : @"sdk", @"format" : @"json"};
    
    
    AFJSONRequestSerializer *requestSerializer = [AFJSONRequestSerializer serializer];
    
    [requestSerializer setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [requestSerializer setValue:@"application/json" forHTTPHeaderField:@"Accept"];
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [manager POST:@"https://logger.instagram.com/method/logging.clientevent" parameters:requestDic success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSLog(@"result %@",responseObject);
        NSArray *arr = [responseObject objectForKey:@"request_args"];
        NSString *str = [NSString stringWithFormat:@"%@",arr];
        NSLog(@"%@",str);
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"error : %@",error);
    }];
}

- (NSArray *)getMediaPlayDataArrWithM_ts:(NSString *)m_ts m_pk:(NSString *)m_pk tracking_token:(NSString *)tracking_token a_pk:(NSString *)a_pk pk:(NSString *)pk
{
    NSDictionary *video_displayed = [self getMediaPlayDicWithName:@"video_displayed" m_ts:m_ts m_pk:m_pk tracking_token:tracking_token a_pk:a_pk pk:pk];
    
    NSDictionary *instagram_organic_impression = [self getMediaPlayDicWithName:@"instagram_organic_impression" m_ts:m_ts m_pk:m_pk tracking_token:tracking_token a_pk:a_pk pk:pk];
    
    NSDictionary *video_should_start = [self getMediaPlayDicWithName:@"video_should_start" m_ts:m_ts m_pk:m_pk tracking_token:tracking_token a_pk:a_pk pk:pk];
    
    NSDictionary *video_started_playing = [self getMediaPlayDicWithName:@"video_started_playing" m_ts:m_ts m_pk:m_pk tracking_token:tracking_token a_pk:a_pk pk:pk];
    
    NSDictionary *video_paused = [self getMediaPlayDicWithName:@"video_paused" m_ts:m_ts m_pk:m_pk tracking_token:tracking_token a_pk:a_pk pk:pk];
    NSArray *arr = @[video_displayed,instagram_organic_impression,video_should_start,video_started_playing,video_paused];
    return arr;
}

- (NSDictionary *)getMediaPlayDicWithName:(NSString *)name m_ts:(NSString *)m_ts m_pk:(NSString *)m_pk tracking_token:(NSString *)tracking_token a_pk:(NSString *)a_pk pk:(NSString *)pk
{
    NSDictionary *dic = nil;
    NSDate *date = [NSDate date];
    NSTimeInterval timeInterval = date.timeIntervalSince1970;
    NSNumber *time = [NSNumber numberWithDouble:timeInterval];
    if ([name isEqualToString:@"video_displayed"]) {
        dic = @{@"module":@"single_feed",@"name":@"video_displayed",@"time":time,@"extra":@{@"a_i":@"organic",@"tracking_token":tracking_token,@"pk":pk,@"m_pk":m_pk,@"a_pk":a_pk,@"m_ts":m_ts}};
    }
    else if ([name isEqualToString:@"instagram_organic_impression"]){
        dic = @{@"module":@"single_feed",@"name":@"instagram_organic_impression",@"time":time,@"extra":@{@"pk":pk,@"m_t":@2,@"m_ix":@0,@"source_of_action":@"profile",@"a_pk":a_pk,@"m_pk":m_pk,@"follow_status":@"not_following",@"tracking_token":tracking_token}};
    }
    else if ([name isEqualToString:@"video_should_start"]){
        dic = @{@"module":@"single_feed",@"name":@"video_should_start",@"time":time,@"extra":@{@"pk":pk,@"m_t":@2,@"m_ix":@0,@"source_of_action":@"profile",@"a_pk":a_pk,@"m_pk":m_pk,@"follow_status":@"not_following",@"tracking_token":tracking_token}};
    }
    else if ([name isEqualToString:@"video_started_playing"]){
        dic = @{@"module":@"single_feed",@"name":@"video_started_playing",@"time":time,@"extra":@{@"start_delay":@0,@"m_ts":m_ts,@"playing_audio":@false,@"a_i":@"organic",@"m_pk":m_pk,@"device_muted":@0,@"system_volume":@0.2099999997764826,@"tracking_token":tracking_token,@"a_pk":a_pk,@"reason":@"autoplay",@"audio_detected":@true,@"pk":pk}};
    }
    else if ([name isEqualToString:@"video_paused"]){
        dic = @{@"module":@"single_feed",@"name":@"video_paused",@"time":time,@"extra":@{@"m_ts":m_ts,@"playing_audio":@false,@"timeAsPercent":@0.01924600079655647,@"lsp":@0,@"a_i":@"organic",@"m_pk":m_pk,@"device_muted":@0,@"time":@0.1277479976415634,@"system_volume":@0.2099999997764826,@"tracking_token":tracking_token,@"a_pk":a_pk,@"reason":@"scroll",@"audio_detected":@true,@"pk":pk,@"duration":@4.310000038146972,@"original_start_reason":@"autoplay",@"loop_count":@1.019246000796556}};
    }
    return dic;
}

- (void)requestNextWithUrl:(NSString *)url
{
    [[AFInstagramManager shareManager] requestDataWithFrontURL:url method:@"GET" parameter:nil header:headerDic body:nil timeoutInterval:10 result:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *resultDic = (NSDictionary *)responseObject;
        NSLog(@"%@",resultDic);
        NSNumber *num = [resultDic objectForKey:@"more_available"];
        if (num.integerValue > 0) {
            NSDictionary *mediaDic = [[resultDic objectForKey:@"items"] lastObject];
            NSString *url2 = [NSString stringWithFormat:@"https://i.instagram.com/api/v1/feed/liked/?max_id=%@",[mediaDic objectForKey:@"id"]];
            [self requestNextWithUrl:url2];
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"%@",error);
    }];
}

- (NSString *)makeApiCallWithMethod:(NSString *)method Params:(NSDictionary *)params Ssl:(BOOL)ssl Use_cookie:(NSString *)user_cookie
{
    
    NSMutableDictionary *defaultRequestBody = [NSMutableDictionary dictionaryWithDictionary:params];
    
    
    if ([method isEqualToString:@"Login"]) {
        [defaultRequestBody setObject:self.device_id forKey:@"device_id"];
        [defaultRequestBody setObject:self.device_id forKey:@"_uuid"];
    }
    
    if ([method isEqualToString:@"Like"]) {
        [defaultRequestBody setObject:self.device_id forKey:@"_uuid"];
        [defaultRequestBody setObject:user_cookie forKey:@"_csrftoken"];
    }
    
    if ([method isEqualToString:@"Follow"]) {
        [defaultRequestBody setObject:self.device_id forKey:@"_uuid"];
        [defaultRequestBody setObject:user_cookie forKey:@"_csrftoken"];
    }
    NSString *sig = nil;
    NSString *sign_body = nil;
    if (defaultRequestBody != nil) {
        NSString *sbJsonStr = [NSString sbJsonRecoverDic:defaultRequestBody];
        sig = [NSString signWithKey:ig_key usingData:sbJsonStr];
        sign_body = [NSString stringWithFormat:@"%@.%@", sig, sbJsonStr];
    }
    return sign_body;
}

#pragma mark - MD5破解

- (void)md5PoJie
{
    NSString *path = [[NSBundle mainBundle] pathForResource:@"MD5" ofType:@"plist"];
    NSDictionary *dic = [NSDictionary dictionaryWithContentsOfFile:path];
    NSLog(@"plist - %@",dic);
    NSString *resultStr = [FBSig generateSigWithParams:dic andUseSecret:YES];
    if ([resultStr isEqualToString:@"3ad2cfd411ac1d9dbffc6bb11628c05b"]) {
        NSLog(@"%@",resultStr);
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

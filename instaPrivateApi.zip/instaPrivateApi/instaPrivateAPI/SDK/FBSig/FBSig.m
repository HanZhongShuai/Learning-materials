//
//  FBSig.m
//  instaPrivateAPI
//
//  Created by RC on 16/6/6.
//  Copyright © 2016年 RC. All rights reserved.
//

#import "FBSig.h"
#import <CommonCrypto/CommonDigest.h>

static NSString* kSecretForIns = @"84a456d620314b6e92a16d8ff1c792dc";

@implementation FBSig

+ (NSString*)md5HexDigest:(NSString*)input {
    const char* str = [input UTF8String];
    unsigned char result[CC_MD5_DIGEST_LENGTH];
    CC_MD5(str, strlen(str), result);
    
    NSMutableString *ret = [NSMutableString stringWithCapacity:CC_MD5_DIGEST_LENGTH*2];
    for(int i = 0; i<CC_MD5_DIGEST_LENGTH; i++) {
        [ret appendFormat:@"%02x",result[i]];
    }
    return ret;
}

+ (NSString*)generateCallId {
    return [NSString stringWithFormat:@"%.0f", [[NSDate date] timeIntervalSince1970]];
}

+ (NSString*)generateSigWithParams:(NSDictionary *)params andUseSecret:(BOOL)canUse {
    if (params == nil) {
        return @"";
    }
    NSMutableString* joined = [NSMutableString string];
    
    NSArray* keys = [params.allKeys sortedArrayUsingSelector:@selector(caseInsensitiveCompare:)];
    for (id obj in [keys objectEnumerator]) {
        id value = [params valueForKey:obj];
        if ([value isKindOfClass:[NSString class]]) {
            [joined appendString:obj];
            [joined appendString:@"="];
            [joined appendString:value];
        }
    }
    
    if (canUse) {
        [joined appendString:kSecretForIns];
    }
    
    return [FBSig md5HexDigest:joined];
}

@end

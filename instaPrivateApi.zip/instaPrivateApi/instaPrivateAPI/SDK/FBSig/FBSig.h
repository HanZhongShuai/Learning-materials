//
//  FBSig.h
//  instaPrivateAPI
//
//  Created by RC on 16/6/6.
//  Copyright © 2016年 RC. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FBSig : NSObject

+ (NSString*)generateSigWithParams:(NSDictionary *)params andUseSecret:(BOOL)canUse;
+ (NSString*)generateCallId;

@end

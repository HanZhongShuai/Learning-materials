//
//  NextViewController.h
//  instaPrivateAPI
//
//  Created by RC on 15/12/7.
//  Copyright © 2015年 RC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NextViewController : UIViewController

@end

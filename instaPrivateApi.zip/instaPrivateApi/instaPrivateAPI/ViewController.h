//
//  ViewController.h
//  instaPrivateAPI
//
//  Created by Blues on 15/12/1.
//  Copyright © 2015年 RC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end


//
//  ViewController.m
//  instaPrivateAPI
//
//  Created by Blues on 15/12/1.
//  Copyright © 2015年 RC. All rights reserved.
//

#import "ViewController.h"
#import "NextViewController.h"

#define windowWidth [UIScreen mainScreen].bounds.size.width
#define windowHeight [UIScreen mainScreen].bounds.size.height
@interface ViewController ()<UITextFieldDelegate>
{
    NSString *kStringBoundary;
    NSDictionary *headerDic;
    
    NSString *kUserAgent;
    NSString *ig_key_version;
    NSString *ig_key;
}
@property (nonatomic, strong) UITextField *nameTextField;
@property (nonatomic, strong) UITextField *passwordTextField;
@property (nonatomic, strong) NSString *device_id;

@end

@implementation ViewController
@synthesize nameTextField, passwordTextField;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.view.backgroundColor = [UIColor colorWithRed:0.1137 green:0.502 blue:0.8078 alpha:1.0];
    [self initView];
}
- (void)initView
{
    nameTextField = [[UITextField alloc] initWithFrame:CGRectMake(0, 70, 243, 40)];
    nameTextField.center = CGPointMake(windowWidth / 2, 90);
    nameTextField.backgroundColor = [UIColor colorWithRed:1.0 green:1.0 blue:1.0 alpha:0.22];
    nameTextField.delegate = self;
    nameTextField.textColor = [UIColor whiteColor];
    nameTextField.placeholder = @"Username";
    nameTextField.autocorrectionType = UITextAutocorrectionTypeNo;
    [nameTextField setValue:[UIColor colorWithRed:1.0 green:1.0 blue:1.0 alpha:0.48] forKeyPath:@"_placeholderLabel.textColor"];
    [self.view addSubview:nameTextField];
    
    passwordTextField = [[UITextField alloc] initWithFrame:CGRectMake(0, 130, 243, 40)];
    passwordTextField.center = CGPointMake(windowWidth / 2, 130 + 20);
    passwordTextField.backgroundColor = [UIColor colorWithRed:1.0 green:1.0 blue:1.0 alpha:0.22];
    passwordTextField.delegate = self;
    passwordTextField.leftViewMode = UITextFieldViewModeAlways;
    passwordTextField.textColor = [UIColor whiteColor];
    passwordTextField.placeholder = @"Password";
    passwordTextField.autocorrectionType = UITextAutocorrectionTypeNo;
    [passwordTextField setValue:[UIColor colorWithRed:1.0 green:1.0 blue:1.0 alpha:0.48] forKeyPath:@"_placeholderLabel.textColor"];
    passwordTextField.secureTextEntry = YES;
    [self.view addSubview:passwordTextField];
    
    UIButton *loginBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    loginBtn.frame = CGRectMake(windowWidth / 2 - 50, 200, 100, 30);
    [loginBtn setTitle:@"登陆" forState:UIControlStateNormal];
    [loginBtn addTarget:self action:@selector(pressLoginBtn:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:loginBtn];
    
}
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self getBaseParam];
}
- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    NSNumber *loginNum = [userDefaults objectForKey:kIsLogin];
    if (loginNum.integerValue > 0) {
        [self succeedToPresent];
    }
}
- (void)pressLoginBtn:(UIButton *)btn
{
    if ([userDefault objectForKey:igkey] == nil) {
        
        [userDefault setObject:@"584a812c16ad3a5dfa47df9319eea7327a11ac44e55eba3dc4ceeb4de1bab522" forKey:igkey];
        [userDefault setObject:@"5|Instagram 7.17.1" forKey:igversion];
        if(![userDefault objectForKey:deviceID]){
            [userDefault setObject:[NSString getUniqueStrByUUID] forKey:deviceID];
        }
    }
    
    ig_key = [userDefault objectForKey:igkey];
    NSString *keyAgentVersion = [userDefault objectForKey:igversion];
    NSArray *keyArr = [keyAgentVersion componentsSeparatedByString:@"|"];
    ig_key_version = [keyArr firstObject];
    NSString *ig_agent = [keyArr lastObject];
    self.device_id = [userDefault objectForKey:deviceID];
    NSString *device_info = getDeviceInfoForInstagram();
    kUserAgent = [NSString stringWithFormat:@"%@ %@", ig_agent,device_info];
    NSString* contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=%@", kStringBoundary];
    headerDic = @{@"User-Agent":kUserAgent, @"Content-Type":contentType, @"Accept-Language" : @"en;q=1, zh-Hans;q=0.9, ja;q=0.8, zh-Hant;q=0.7, fr;q=0.6, de;q=0.5"};
    self.device_id = [userDefault objectForKey:deviceID];
    [self InsLogin];
}

- (void)InsLogin{
    [self resignTextFieldFirstResponder];
    if (nameTextField.text.length == 0 || passwordTextField.text == 0) {
        return;
    }
    [userDefault setObject:nameTextField.text forKey:kUsername];
    [userDefault setObject:passwordTextField.text forKey:kPassword];
    [userDefault synchronize];
    [self deleteCookieWithKey];
    
//    NSDictionary *params = @{@"username":nameTextField.text,@"password":passwordTextField.text,@"_uuid":self.device_id,@"device_id":self.device_id,@"login_attempt_count":@"0",@"_csrftoken":@"missing"};
    NSDictionary *params = @{@"username":nameTextField.text,@"from_reg":@"false",@"password":passwordTextField.text};
    NSString *sign_body = [self makeApiCallWithMethod:@"Login" Params:params Ssl:NO Use_cookie:nil];
    NSDictionary *requestBody = @{@"ig_sig_key_version" : ig_key_version, @"signed_body" : sign_body};
    NSMutableData *bodyData = [NSMutableData generatePostBodyWithRequestBody:requestBody Boundary:kStringBoundary];
    NSMutableDictionary *cookieDic = [NSMutableDictionary dictionary];
    
    
    [[AFInstagramManager shareManager] loginRequestWithHeader:headerDic body:bodyData timeoutInterVal:30.0 result:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        //做一下sever的登录
        NSLog(@"%@", responseObject);
        if ([[responseObject objectForKey:@"status"] isEqual:@"ok"]) {
            
            //            [userDefault removeObjectForKey:ErrorBreak];
            NSString *userID = [[responseObject objectForKey:@"logged_in_user"] objectForKey:@"pk"];
            if (userID != nil) {
                
            }
            NSArray *cookies = [[NSHTTPCookieStorage sharedHTTPCookieStorage] cookies];
            for (NSHTTPCookie *cookie in cookies) {
                [cookieDic setObject:cookie.value forKey:cookie.name];
            }
            
            NSString *csrftoken = [cookieDic objectForKey:@"csrftoken"];
            if (csrftoken != nil) {
                [userDefault setObject:csrftoken forKey:ctoken];
                NSString *userID = [[responseObject objectForKey:@"logged_in_user"] objectForKey:@"pk"];
                NSString *picUrl = [[responseObject objectForKey:@"logged_in_user"] objectForKey:@"profile_pic_url"];
                [userDefault setObject:userID forKey:kUserId];
                [userDefault setObject:picUrl forKey:kPic];
                [userDefault synchronize];
                [self succeedToPresent];
            }
            else
            {
                NSLog(@"失败");
            }
            [userDefault synchronize];
        } else {
            NSLog(@"失败");
        }
        
        
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"%@",error);
    }];
    
}
- (void)succeedToPresent
{
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    [userDefaults setObject:[NSNumber numberWithInteger:1] forKey:kIsLogin];
    [userDefaults synchronize];
    NextViewController *next = [[NextViewController alloc] init];
    [self presentViewController:next animated:YES completion:nil];
}

- (void)getBaseParam
{
    
    NSDictionary *dic = @{@"plat": @1 , @"appid" : SeverAppID};
    [[RC_RequestManager shareInstance] requestForBaseParm:dic success:^(id responseObject) {
        NSDictionary *parmDic = [NSDictionary dictionaryWithDictionary:responseObject];
        
        if (parmDic) {
            if ([parmDic objectForKey:@"autoFollowerSpeed"]) {
                [userDefault setObject:[parmDic objectForKey:@"autoFollowerSpeed"] forKey:autoFollowerSpeed];
            } else {
                [userDefault setObject:@0 forKey:autoFollowerSpeed];
            }
            
            if ([parmDic objectForKey:@"autoFollowerSwitch"]) {
                [userDefault setObject:[parmDic objectForKey:@"autoFollowerSwitch"] forKey:autoFollowerSwitch];
            } else {
                [userDefault setObject:@0 forKey:autoFollowerSwitch];
            }
            if ([parmDic objectForKey:@"autoLikeSpeed"]) {
                [userDefault setObject:[parmDic objectForKey:@"autoLikeSpeed"] forKey:autoLikeSpeed];
            } else {
                [userDefault setObject:@0 forKey:autoLikeSpeed];
            }
            if ([parmDic objectForKey:@"autoLikeSwitch"]) {
                [userDefault setObject:[parmDic objectForKey:@"autoLikeSwitch"] forKey:autoLikeSwitch];
            } else {
                [userDefault setObject:@0 forKey:autoLikeSwitch];
            }
            if ([parmDic objectForKey:@"manualFollowerSpeed"]) {
                [userDefault setObject:[parmDic objectForKey:@"manualFollowerSpeed"] forKey:manualFollowerSpeed];
            } else {
                [userDefault setObject:@50 forKey:manualFollowerSpeed];
            }
            if ([parmDic objectForKey:@"manualFollowerStealNum"]) {
                [userDefault setObject:[parmDic objectForKey:@"manualFollowerStealNum"] forKey:manualFollowerStealNum];
            } else {
                [userDefault setObject:@0 forKey:manualFollowerStealNum];
            }
            if ([parmDic objectForKey:@"manualLikeSpeed"] ) {
                [userDefault setObject:[parmDic objectForKey:@"manualLikeSpeed"] forKey:manualLikeSpeed];
            } else {
                [userDefault setObject:@60 forKey:manualLikeSpeed];
            }
            if ([parmDic objectForKey:@"manualLikeStealNum"]) {
                [userDefault setObject:[parmDic objectForKey:@"manualLikeStealNum"] forKey:manualLikeStealNum];
            } else {
                [userDefault setObject:@0 forKey:manualLikeStealNum];
            }
            if ([parmDic objectForKey:@"scoreFlag"]) {
                [userDefault setObject:[parmDic objectForKey:@"scoreFlag"] forKey:scoreFlag];
            } else {
                [userDefault setObject:@0 forKey:scoreFlag];
            }
            if ([parmDic objectForKey:@"scoresendgold"]) {
                [userDefault setObject:[parmDic objectForKey:@"scoresendgold"] forKey:scoresendgold];
            } else {
                [userDefault setObject:@10 forKey:scoresendgold];
            }
            if ([parmDic objectForKey:@"stoptime"]) {
                [userDefault setObject:[parmDic objectForKey:@"stoptime"] forKey:stoptime];
            } else {
                [userDefault setObject:@15 forKey:stoptime];
            }
            if ([parmDic objectForKey:@"igkey"]) {
//                [userDefault setObject:[parmDic objectForKey:@"igkey"] forKey:igkey];
                [userDefault setObject:@"584a812c16ad3a5dfa47df9319eea7327a11ac44e55eba3dc4ceeb4de1bab522" forKey:igkey];
            } else {
                [userDefault setObject:@"584a812c16ad3a5dfa47df9319eea7327a11ac44e55eba3dc4ceeb4de1bab522" forKey:igkey];
            }
            if ([parmDic objectForKey:@"igversion"]) {
//                [userDefault setObject:[parmDic objectForKey:@"igversion"] forKey:igversion];
                [userDefault setObject:@"5|Instagram 7.17.1" forKey:igversion];
            } else {
                [userDefault setObject:@"5|Instagram 7.17.1" forKey:igversion];
            }
            if(![userDefault objectForKey:deviceID]){
                [userDefault setObject:[NSString getUniqueStrByUUID] forKey:deviceID];
            }
            [userDefault synchronize];
        } else {
            [userDefault setObject:@0 forKey:autoFollowerSpeed];
            [userDefault setObject:@0 forKey:autoFollowerSwitch];
            [userDefault setObject:@0 forKey:autoLikeSpeed];
            [userDefault setObject:@0 forKey:autoLikeSwitch];
            [userDefault setObject:@50 forKey:manualFollowerSpeed];
            [userDefault setObject:@0 forKey:manualFollowerStealNum];
            [userDefault setObject:@60 forKey:manualLikeSpeed];
            [userDefault setObject:@0 forKey:manualLikeStealNum];
            [userDefault setObject:@0 forKey:scoreFlag];
            [userDefault setObject:@10 forKey:scoresendgold];
            [userDefault setObject:@15 forKey:stoptime];
            [userDefault setObject:@"584a812c16ad3a5dfa47df9319eea7327a11ac44e55eba3dc4ceeb4de1bab522" forKey:igkey];
            [userDefault setObject:@"5|Instagram 7.17.1" forKey:igversion];
            if(![userDefault objectForKey:deviceID]){
                [userDefault setObject:[NSString getUniqueStrByUUID] forKey:deviceID];
            }
            [userDefault synchronize];
        }
    } andFailed:^(NSError *error) {
        [userDefault setObject:@0 forKey:autoFollowerSpeed];
        [userDefault setObject:@0 forKey:autoFollowerSwitch];
        [userDefault setObject:@0 forKey:autoLikeSpeed];
        [userDefault setObject:@0 forKey:autoLikeSwitch];
        [userDefault setObject:@50 forKey:manualFollowerSpeed];
        [userDefault setObject:@0 forKey:manualFollowerStealNum];
        [userDefault setObject:@60 forKey:manualLikeSpeed];
        [userDefault setObject:@0 forKey:manualLikeStealNum];
        [userDefault setObject:@0 forKey:scoreFlag];
        [userDefault setObject:@0 forKey:scoresendgold];
        [userDefault setObject:@15 forKey:stoptime];
        [userDefault setObject:@"584a812c16ad3a5dfa47df9319eea7327a11ac44e55eba3dc4ceeb4de1bab522" forKey:igkey];
        [userDefault setObject:@"5|Instagram 7.17.1" forKey:igversion];
        if(![userDefault objectForKey:deviceID]){
            [userDefault setObject:[NSString getUniqueStrByUUID] forKey:deviceID];
        }
        [userDefault synchronize];
    }];
    
}

- (void)deleteCookieWithKey
{
    NSHTTPCookieStorage *cookieJar = [NSHTTPCookieStorage sharedHTTPCookieStorage];
    NSArray *cookies = [NSArray arrayWithArray:[cookieJar cookies]];
    for (NSHTTPCookie *cookie in cookies) {
        [cookieJar deleteCookie:cookie];
    }
}
- (NSString *)makeApiCallWithMethod:(NSString *)method Params:(NSDictionary *)params Ssl:(BOOL)ssl Use_cookie:(NSString *)user_cookie
{
    
    NSMutableDictionary *defaultRequestBody = [NSMutableDictionary dictionaryWithDictionary:params];
    
    
    if ([method isEqualToString:@"Login"]) {
        [defaultRequestBody setObject:self.device_id forKey:@"device_id"];
        [defaultRequestBody setObject:self.device_id forKey:@"_uuid"];
    }
    
    if ([method isEqualToString:@"Like"]) {
        [defaultRequestBody setObject:self.device_id forKey:@"_uuid"];
        [defaultRequestBody setObject:user_cookie forKey:@"_csrftoken"];
    }
    
    if ([method isEqualToString:@"Follow"]) {
        [defaultRequestBody setObject:self.device_id forKey:@"_uuid"];
        [defaultRequestBody setObject:user_cookie forKey:@"_csrftoken"];
    }
    
    
    NSString *sig = nil;
    NSString *sign_body = nil;
    
    if (defaultRequestBody != nil) {
        NSString *sbJsonStr = [NSString sbJsonRecoverDic:defaultRequestBody];
        sig = [NSString signWithKey:ig_key usingData:sbJsonStr];
        sign_body = [NSString stringWithFormat:@"%@.%@", sig, sbJsonStr];
    }
    
    return sign_body;
    
    
}


#pragma mark - UITextFieldDelegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self resignTextFieldFirstResponder];
}
- (void)resignTextFieldFirstResponder
{
    if ([nameTextField isFirstResponder]) {
        [nameTextField resignFirstResponder];
    }
    if ([passwordTextField isFirstResponder]) {
        [passwordTextField resignFirstResponder];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

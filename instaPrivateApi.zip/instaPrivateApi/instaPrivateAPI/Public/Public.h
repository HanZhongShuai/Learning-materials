//
//  Public.h
//  InstaShot
//
//  Created by TCH on 14-8-5.
//  Copyright (c) 2014年 com.rcplatformhk. All rights reserved.
//

#ifndef InstaShot_Public_h
#define InstaShot_Public_h

#define SeverAppID @"80020"
#define PlatFlag @1
#define defaultDevID @"f5c1bed4c1de0cbd1c63e8bf011162e8"

//用户当前的语言环境
#define CURR_LANG   ([[NSLocale preferredLanguages] objectAtIndex:0])


#define theApp ((AppDelegate *)[[UIApplication sharedApplication] delegate])

#define MY_USERINFO_KEY @"my_userInfo"


///判断是否是ios7
#define isIOS7 (DeviceSystemMajorVersion()< 7 ? NO:YES)
///判断是否是ios8
#define isIOS8 (DeviceSystemMajorVersion()< 8 ? NO:YES)

#define HomeImagePath [NSHomeDirectory() stringByAppendingPathComponent:@"/Documents/Images/"]
#define HomeAudioPath [NSHomeDirectory() stringByAppendingPathComponent:@"/Documents/Audios/"]


#define NAVIGATION_TITLE_FONT         [UIFont boldSystemFontOfSize:17.f]
#define SEARCH_BG_COLOR [UIColor colorWithRed:239/255.0 green:239/255.0 blue:244/255.0 alpha:1]


#define kProductsLoadedNotification         @"ProductsLoaded"
#define kProductPurchasedNotificationStore       @"ProductPurchasedCoinsStore"
#define kProductPurchasedNotificationEarn      @"ProductPurchasedSpecialEarn"


#define kProductPurchaseFailedNotification  @"ProductPurchaseFailed"

#define userDefault     [NSUserDefaults standardUserDefaults]


/// 基础参数

#define autoFollowerSpeed               @"autoFollowerSpeed"
#define autoFollowerSwitch              @"autoFollowerSwitch"
#define autoLikeSpeed                   @"autoLikeSpeed"
#define autoLikeSwitch                  @"autoLikeSwitch"
#define manualFollowerSpeed             @"manualFollowerSpeed"
#define manualFollowerStealNum          @"manualFollowerStealNum"
#define manualLikeSpeed                 @"manualLikeSpeed"
#define manualLikeStealNum              @"manualLikeStealNum"
#define scoreFlag                       @"scoreFlag"
#define scoresendgold                   @"scoresendgold"
#define stoptime                        @"stoptime"
#define igkey                           @"igkey"
#define igversion                       @"igversion"
#define ctoken                          @"csrftoken"
#define deviceID                        @"deviceID"


#define kIgkey                           @"igkey"
#define kIgversion                       @"igversion"

#define LimitTimeKey @"LimitTimeKey"
#define LimitTimeInterval 3600


#define ErrorBreak   @"errorBreak"



#endif

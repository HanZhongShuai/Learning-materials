//
//  RC_PrivateInstagramManager.m
//  iOSLikeFollow
//
//  Created by TCH on 15/12/15.
//  Copyright © 2015年 TCH. All rights reserved.
//

#import "RC_PrivateInstagramManager.h"
#import "NSString+SigString.h"
#import "NSMutableData+generatePostBody.h"

#define kCsrfToken @"csrftoken"

#pragma mark - postURL

static NSString *LoginURL = @"https://i.instagram.com/api/v1/accounts/login/";
static NSString *LikeMediaURL = @"https://i.instagram.com/api/v1/media/%@/like/?d=0&src=timeline";
static NSString *FollowURL = @"https://i.instagram.com/api/v1/friendships/create/%@/";
static NSString *CancleFollowURL = @"https://i.instagram.com/api/v1/friendships/destroy/%@/";
static NSString *BlockURL = @"https://i.instagram.com/api/v1/friendships/block/%@/";
static NSString *UnBlockURL = @"https://i.instagram.com/api/v1/friendships/unblock/%@/";
static NSString *PrivateURL = @"https://i.instagram.com/api/v1/accounts/set_private/";
static NSString *PublicURL = @"https://i.instagram.com/api/v1/accounts/set_public/";
static NSString *CommentURL = @"https://i.instagram.com/api/v1/media/%@/comment/";
static NSString *LogoutURL = @"https://i.instagram.com/api/v1/accounts/logout/";

#pragma mark - getURL

static NSString *UserInfoURL = @"https://i.instagram.com/api/v1/users/%@/info/";
static NSString *UserFeedMediaURL = @"https://i.instagram.com/api/v1/feed/user/%@/";
static NSString *UserFeedMediaURLContainsMaxId = @"https://i.instagram.com/api/v1/feed/user/%@/?max_id=%@";
static NSString *FollowingURL = @"https://i.instagram.com/api/v1/friendships/following/";
static NSString *FollowingURLContainsMaxId = @"https://i.instagram.com/api/v1/friendships/following/?max_id=%@";
static NSString *FollowersURL = @"https://i.instagram.com/api/v1/friendships/followers/";
static NSString *FollowersURLContainsMaxId = @"https://i.instagram.com/api/v1/friendships/followers/?max_id=%@";

#pragma mark - default Value

#define DEFAULT_IG_KEY @"25a0afd75ed57c6840f9b15dc61f1126a7ce18124df77d7154e7756aaaa4fce4"
#define DEFAULT_IG_KEY_VERSIONAGENT @"4|Instagram 6.9.1 Android"
#define DETAULT_IG_DEVICEINFO @"(15/4.0.4; 160dpi; 320x480; Sony; MiniPro; mango; semc; en_Us)"
#define DEFAULT_IG_ACCEPTLANGUAGE @"en;q=1, zh-Hans;q=0.9, ja;q=0.8, zh-Hant;q=0.7, fr;q=0.6, de;q=0.5"

@interface RC_PrivateInstagramManager()

@property (nonatomic, strong) NSOperationQueue *operationQueue;

@property (nonatomic, strong) NSString *ig_key;
@property (nonatomic, strong) NSString *ig_key_version;

@end

@implementation RC_PrivateInstagramManager

+ (RC_PrivateInstagramManager *)shareManager
{
    static RC_PrivateInstagramManager *__singletion;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        __singletion = [[self alloc] init];
        
    });
    return __singletion;
}

- (id)init
{
    self = [super init];
    if (self) {
        self.operationQueue = [[NSOperationQueue alloc] init];
        [self.operationQueue setMaxConcurrentOperationCount:3];
        [self.operationQueue setSuspended:NO];
        if(![userDefault objectForKey:deviceID]){
            [userDefault setObject:[NSString getUniqueStrByUUID] forKey:deviceID];
        }
    }
    return self;
}

- (NSDictionary *)getHeaderWithStringBoundary:(NSString *)stringBoundary
{
    self.ig_key = [userDefault objectForKey:kIgkey];
    if (!_ig_key) {
        self.ig_key = DEFAULT_IG_KEY;
    }
    NSString *agentVersion = [userDefault objectForKey:kIgversion];
    if (!agentVersion) {
        agentVersion = DEFAULT_IG_KEY_VERSIONAGENT;
    }
    NSArray *keyArr = [agentVersion componentsSeparatedByString:@"|"];
    self.ig_key_version = [keyArr firstObject];
    NSString *ig_agent = [keyArr lastObject];
    
    NSString *device_info = DETAULT_IG_DEVICEINFO;
    NSString *userAgent = [NSString stringWithFormat:@"%@%@", ig_agent,device_info];
    
    NSString* contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=%@", stringBoundary];
//    NSDictionary *headerDic = @{@"User-Agent":userAgent, @"Content-Type":contentType, @"Accept-Language":DEFAULT_IG_ACCEPTLANGUAGE};
    NSDictionary *headerDic = @{@"User-Agent":userAgent, @"Content-Type":contentType, @"Accept-Language":DEFAULT_IG_ACCEPTLANGUAGE,@"X-IG-Capabilities":@"Fw==",@"X-IG-Connection-Type":@"WiFi"};
    
    return headerDic;
}

#pragma mark - login

- (void)loginInstagramWithUserName:(NSString *)userName Password:(NSString *)password timeoutInterVal:(NSTimeInterval)timeoutInterval success:(void (^)(AFHTTPRequestOperation *operation, id responseObject))success failure:(void (^)(AFHTTPRequestOperation *operation, NSError *error))failure
{
    [self deleteCookieWithKey];
    
    NSString *stringBoundary = [NSString getUniqueStrByUUID];
    NSDictionary *headerDic = [self getHeaderWithStringBoundary:stringBoundary];
    
    NSString *device_id = [userDefault objectForKey:deviceID];
    
    NSDictionary *params = @{@"username":userName,@"from_reg":@"false",@"password":password,@"device_id":device_id,@"_uuid":device_id};
    NSString *sign_body = [self getSignBodyWithParams:params];
    NSDictionary *requestBody = @{@"ig_sig_key_version" : _ig_key_version, @"signed_body" : sign_body};
    
    NSMutableData *bodyData = [NSMutableData generatePostBodyWithRequestBody:requestBody Boundary:stringBoundary];
    
    AFHTTPRequestOperation *operation = [self postRequesWithURL:LoginURL header:headerDic body:bodyData timeoutInterVal:timeoutInterval success:^(AFHTTPRequestOperation *operation, id responseObject) {
        if (success) {
            success(operation,responseObject);
        }
        if ([[responseObject objectForKey:@"status"] isEqual:@"ok"]) {
            
            NSMutableDictionary *cookieDic = [NSMutableDictionary dictionary];
            NSArray *cookies = [[NSHTTPCookieStorage sharedHTTPCookieStorage] cookies];
            for (NSHTTPCookie *cookie in cookies) {
                [cookieDic setObject:cookie.value forKey:cookie.name];
            }
            NSData *cookiesData = [NSKeyedArchiver archivedDataWithRootObject: [[NSHTTPCookieStorage sharedHTTPCookieStorage] cookies]];
            [userDefault setObject:cookiesData forKey: @"sessionCookies"];
            [userDefault setObject:[cookieDic objectForKey:@"csrftoken"] forKey:kCsrfToken];
            
            NSString *userID = [[responseObject objectForKey:@"logged_in_user"] objectForKey:@"pk"];
            [userDefault setObject:userID forKey:kUserId];
            [userDefault synchronize];
            
        } else {
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        if (failure) {
            failure(operation,error);
        }
    }];
    
    [self.operationQueue addOperation:operation];
}

#pragma mark - Logout

- (void)logoutWithTimeoutInterVal:(NSTimeInterval)timeoutInterval success:(void (^)(AFHTTPRequestOperation *operation, id responseObject))success failure:(void (^)(AFHTTPRequestOperation *operation, NSError *error))failure
{
    NSString *stringBoundary = [NSString getUniqueStrByUUID];
    NSDictionary *headerDic = [self getHeaderWithStringBoundary:stringBoundary];
    NSString *requestURL = LogoutURL;
    AFHTTPRequestOperation *operation = [self getRequesWithURL:requestURL header:headerDic timeoutInterVal:timeoutInterval success:^(AFHTTPRequestOperation *operation, id responseObject) {
        if (success) {
            success(operation, responseObject);
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        if (failure) {
            failure(operation, error);
        }
    }];
    [self.operationQueue addOperation:operation];
}

#pragma mark - LikeMedia

- (void)likeMediaWithMediaId:(NSString *)mediaId timeoutInterVal:(NSTimeInterval)timeoutInterval success:(void (^)(AFHTTPRequestOperation *operation, id responseObject))success failure:(void (^)(AFHTTPRequestOperation *operation, NSError *error))failure
{
    NSString *stringBoundary = [NSString getUniqueStrByUUID];
    NSDictionary *headerDic = [self getHeaderWithStringBoundary:stringBoundary];
    
    NSString *device_id = [userDefault objectForKey:deviceID];
    NSString *csrftoken = [userDefault objectForKey:kCsrfToken];
    NSString *userId = [userDefault objectForKey:kUserId];
    NSDictionary *params = @{@"media_id":mediaId,@"_uid":userId,@"_csrftoken":csrftoken,@"_uuid":device_id,@"src":@"profile"};
    NSString *sign_body = [self getSignBodyWithParams:params];
    NSDictionary *requestBody = @{@"ig_sig_key_version" : _ig_key_version, @"signed_body" : sign_body};
    
    NSMutableData *bodyData = [NSMutableData generatePostBodyWithRequestBody:requestBody Boundary:stringBoundary];

    NSString *requestURL = [NSString stringWithFormat:LikeMediaURL,mediaId];

    AFHTTPRequestOperation *operation = [self postRequesWithURL:requestURL header:headerDic body:bodyData timeoutInterVal:timeoutInterval success:^(AFHTTPRequestOperation *operation, id responseObject) {
        if (success) {
            success(operation,responseObject);
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        if (failure) {
            failure(operation,error);
        }
    }];
    
    [self.operationQueue addOperation:operation];
}

#pragma mark - follow/cancleFollow

- (void)changeRelationshipWithTargetUserID:(NSString *)targetUserId isCreate:(BOOL)create timeoutInterVal:(NSTimeInterval)timeoutInterval success:(void (^)(AFHTTPRequestOperation *operation, id responseObject))success failure:(void (^)(AFHTTPRequestOperation *operation, NSError *error))failure
{
    NSString *stringBoundary = [NSString getUniqueStrByUUID];
    NSDictionary *headerDic = [self getHeaderWithStringBoundary:stringBoundary];
    
    NSString *device_id = [userDefault objectForKey:deviceID];
    NSString *csrftoken = [userDefault objectForKey:kCsrfToken];
    NSString *userId = [userDefault objectForKey:kUserId];
    NSDictionary *params = @{@"user_id":targetUserId,@"_uid":userId,@"_csrftoken":csrftoken,@"_uuid":device_id};
    NSString *sign_body = [self getSignBodyWithParams:params];
    NSDictionary *requestBody = @{@"ig_sig_key_version" : _ig_key_version, @"signed_body" : sign_body};
    
    NSMutableData *bodyData = [NSMutableData generatePostBodyWithRequestBody:requestBody Boundary:stringBoundary];
    
    NSString *requestURL;
    if (create) {
        requestURL = [NSString stringWithFormat:FollowURL,targetUserId];
    }
    else
    {
        requestURL = [NSString stringWithFormat:CancleFollowURL,targetUserId];
    }
    
    AFHTTPRequestOperation *operation = [self postRequesWithURL:requestURL header:headerDic body:bodyData timeoutInterVal:timeoutInterval success:^(AFHTTPRequestOperation *operation, id responseObject) {
        if (success) {
            success(operation,responseObject);
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        if (failure) {
            failure(operation,error);
        }
    }];
    
    [self.operationQueue addOperation:operation];
}

#pragma mark - block/unblock

- (void)changeRelationshipWithTargetUserID:(NSString *)targetUserId isBlock:(BOOL)block timeoutInterVal:(NSTimeInterval)timeoutInterval success:(void (^)(AFHTTPRequestOperation *operation, id responseObject))success failure:(void (^)(AFHTTPRequestOperation *operation, NSError *error))failure
{
    NSString *stringBoundary = [NSString getUniqueStrByUUID];
    NSDictionary *headerDic = [self getHeaderWithStringBoundary:stringBoundary];
    
    NSString *device_id = [userDefault objectForKey:deviceID];
    NSString *csrftoken = [userDefault objectForKey:kCsrfToken];
    NSString *userId = [userDefault objectForKey:kUserId];
    NSDictionary *params = @{@"user_id":targetUserId,@"_uid":userId,@"_csrftoken":csrftoken,@"_uuid":device_id};
    NSString *sign_body = [self getSignBodyWithParams:params];
    NSDictionary *requestBody = @{@"ig_sig_key_version" : _ig_key_version, @"signed_body" : sign_body};
    
    NSMutableData *bodyData = [NSMutableData generatePostBodyWithRequestBody:requestBody Boundary:stringBoundary];
    
    NSString *requestURL;
    if (block) {
        requestURL = [NSString stringWithFormat:BlockURL,targetUserId];
    }
    else
    {
        requestURL = [NSString stringWithFormat:UnBlockURL,targetUserId];
    }
    
    AFHTTPRequestOperation *operation = [self postRequesWithURL:requestURL header:headerDic body:bodyData timeoutInterVal:timeoutInterval success:^(AFHTTPRequestOperation *operation, id responseObject) {
        if (success) {
            success(operation,responseObject);
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        if (failure) {
            failure(operation,error);
        }
    }];
    
    [self.operationQueue addOperation:operation];
}

#pragma mark - set private/public

- (void)setAccountPrivate:(BOOL)private timeoutInterVal:(NSTimeInterval)timeoutInterval success:(void (^)(AFHTTPRequestOperation *operation, id responseObject))success failure:(void (^)(AFHTTPRequestOperation *operation, NSError *error))failure
{
    NSString *stringBoundary = [NSString getUniqueStrByUUID];
    NSDictionary *headerDic = [self getHeaderWithStringBoundary:stringBoundary];
    
    NSString *requestURL;
    if (private) {
        requestURL = PrivateURL;
    }
    else
    {
        requestURL = PublicURL;
    }
    
    AFHTTPRequestOperation *operation = [self postRequesWithURL:requestURL header:headerDic body:nil timeoutInterVal:timeoutInterval success:^(AFHTTPRequestOperation *operation, id responseObject) {
        if (success) {
            success(operation,responseObject);
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        if (failure) {
            failure(operation,error);
        }
    }];
    
    [self.operationQueue addOperation:operation];
}

#pragma mark - comment

- (void)commentWithMediaID:(NSString *)mediaId commentText:(NSString *)commentText timeoutInterVal:(NSTimeInterval)timeoutInterval success:(void (^)(AFHTTPRequestOperation *operation, id responseObject))success failure:(void (^)(AFHTTPRequestOperation *operation, NSError *error))failure
{
    NSString *stringBoundary = [NSString getUniqueStrByUUID];
    NSDictionary *headerDic = [self getHeaderWithStringBoundary:stringBoundary];
    
    NSString *device_id = [userDefault objectForKey:deviceID];
    NSString *csrftoken = [userDefault objectForKey:kCsrfToken];
    NSString *userId = [userDefault objectForKey:kUserId];
    NSDictionary *params = @{@"comment_text":commentText,@"_uid":userId,@"_csrftoken":csrftoken,@"_uuid":device_id};
    NSString *sign_body = [self getSignBodyWithParams:params];
    NSDictionary *requestBody = @{@"ig_sig_key_version" : _ig_key_version, @"signed_body" : sign_body};
    
    NSMutableData *bodyData = [NSMutableData generatePostBodyWithRequestBody:requestBody Boundary:stringBoundary];
    
    NSString *requestURL = [NSString stringWithFormat:CommentURL,mediaId];
    
    AFHTTPRequestOperation *operation = [self postRequesWithURL:requestURL header:headerDic body:bodyData timeoutInterVal:timeoutInterval success:^(AFHTTPRequestOperation *operation, id responseObject) {
        if (success) {
            success(operation,responseObject);
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        if (failure) {
            failure(operation,error);
        }
    }];
    
    [self.operationQueue addOperation:operation];
}

#pragma mark - get user Info

- (void)getUserInfoWithUserId:(NSString *)userId timeoutInterVal:(NSTimeInterval)timeoutInterval success:(void (^)(AFHTTPRequestOperation *operation, id responseObject))success failure:(void (^)(AFHTTPRequestOperation *operation, NSError *error))failure
{
    NSString *stringBoundary = [NSString getUniqueStrByUUID];
    NSDictionary *headerDic = [self getHeaderWithStringBoundary:stringBoundary];
    
    NSString *requestURL = [NSString stringWithFormat:UserInfoURL,userId];
    
    AFHTTPRequestOperation *operation = [self getRequesWithURL:requestURL header:headerDic timeoutInterVal:timeoutInterval success:^(AFHTTPRequestOperation *operation, id responseObject) {
        if (success) {
            success(operation, responseObject);
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        if (failure) {
            failure(operation, error);
        }
    }];
    [self.operationQueue addOperation:operation];
}

#pragma mark - get user media

- (void)getUserMediaWithUserId:(NSString *)userId maxId:(NSString *)maxId timeoutInterVal:(NSTimeInterval)timeoutInterval success:(void (^)(AFHTTPRequestOperation *operation, id responseObject))success failure:(void (^)(AFHTTPRequestOperation *operation, NSError *error))failure
{
    NSString *stringBoundary = [NSString getUniqueStrByUUID];
    NSDictionary *headerDic = [self getHeaderWithStringBoundary:stringBoundary];
    NSString *requestURL;
    if (maxId) {
        requestURL = [NSString stringWithFormat:UserFeedMediaURLContainsMaxId,userId,maxId];
    }
    else
    {
        requestURL = [NSString stringWithFormat:UserFeedMediaURL,userId];
    }
    AFHTTPRequestOperation *operation = [self getRequesWithURL:requestURL header:headerDic timeoutInterVal:timeoutInterval success:^(AFHTTPRequestOperation *operation, id responseObject) {
        if (success) {
            success(operation, responseObject);
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        if (failure) {
            failure(operation, error);
        }
    }];
    [self.operationQueue addOperation:operation];
}

#pragma mark - get following

- (void)getFollowingWithMaxId:(NSString *)maxId timeoutInterVal:(NSTimeInterval)timeoutInterval success:(void (^)(AFHTTPRequestOperation *operation, id responseObject))success failure:(void (^)(AFHTTPRequestOperation *operation, NSError *error))failure
{
    NSString *stringBoundary = [NSString getUniqueStrByUUID];
    NSDictionary *headerDic = [self getHeaderWithStringBoundary:stringBoundary];
    NSString *requestURL;
    if (maxId) {
        requestURL = [NSString stringWithFormat:FollowingURLContainsMaxId,maxId];
    }
    else
    {
        requestURL = FollowingURL;
    }
    AFHTTPRequestOperation *operation = [self getRequesWithURL:requestURL header:headerDic timeoutInterVal:timeoutInterval success:^(AFHTTPRequestOperation *operation, id responseObject) {
        if (success) {
            success(operation, responseObject);
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        if (failure) {
            failure(operation, error);
        }
    }];
    [self.operationQueue addOperation:operation];
}

#pragma mark - get Followers

- (void)getFollowersWithMaxId:(NSString *)maxId timeoutInterVal:(NSTimeInterval)timeoutInterval success:(void (^)(AFHTTPRequestOperation *operation, id responseObject))success failure:(void (^)(AFHTTPRequestOperation *operation, NSError *error))failure
{
    NSString *stringBoundary = [NSString getUniqueStrByUUID];
    NSDictionary *headerDic = [self getHeaderWithStringBoundary:stringBoundary];
    NSString *requestURL;
    if (maxId) {
        requestURL = [NSString stringWithFormat:FollowersURLContainsMaxId,maxId];
    }
    else
    {
        requestURL = FollowersURL;
    }
    AFHTTPRequestOperation *operation = [self getRequesWithURL:requestURL header:headerDic timeoutInterVal:timeoutInterval success:^(AFHTTPRequestOperation *operation, id responseObject) {
        if (success) {
            success(operation, responseObject);
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        if (failure) {
            failure(operation, error);
        }
    }];
    [self.operationQueue addOperation:operation];
}

#pragma mark - post请求

- (AFHTTPRequestOperation *)postRequesWithURL:(NSString *)requestUrl header:(NSDictionary *)header body:(NSMutableData *)body timeoutInterVal:(NSTimeInterval)timeoutInterval success:(void (^)(AFHTTPRequestOperation *operation, id responseObject))success failure:(void (^)(AFHTTPRequestOperation *operation, NSError *error))failure
{
    // 1.初始化
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:requestUrl] cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:timeoutInterval];
    // 2.设置请求类型
    request.HTTPMethod = @"POST";
    // 4.设置消息头
    if (header) {
        for (NSString *key in [header allKeys]) {
            [request setValue:[header objectForKey:key] forHTTPHeaderField:key];
        }
    }
    // 5.设置消息体
    if (body) {
        request.HTTPBody = body;
    }
    // 6.请求
    AFHTTPRequestOperation *operation = [[AFHTTPRequestOperation alloc] initWithRequest:request];
    
    AFSecurityPolicy *securityPolicy = [AFSecurityPolicy defaultPolicy];
    securityPolicy.allowInvalidCertificates = YES;
    operation.securityPolicy = securityPolicy;
    operation.responseSerializer =[AFJSONResponseSerializer serializer];
    operation.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"application/json"];
    //        request.HTTPShouldHandleCookies = YES;
    
    [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
        success(operation, responseObject);
        // 关闭状态栏菊花
        [self close];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        failure(operation, error);
        // 关闭状态栏菊花
        [self close];
        
    }];
    
    return operation;
}

#pragma mark - get请求

- (AFHTTPRequestOperation *)getRequesWithURL:(NSString *)requestUrl header:(NSDictionary *)header timeoutInterVal:(NSTimeInterval)timeoutInterval success:(void (^)(AFHTTPRequestOperation *operation, id responseObject))success failure:(void (^)(AFHTTPRequestOperation *operation, NSError *error))failure
{
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:requestUrl] cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:timeoutInterval];
    // 设置消息头
    if (header) {
        for (NSString *key in [header allKeys]) {
            [request setValue:[header objectForKey:key] forHTTPHeaderField:key];
        }
    }
    //设置cookies
    NSData *cookiesdata = [[NSUserDefaults standardUserDefaults] objectForKey:@"sessionCookies"];
    if([cookiesdata length]) {
        NSArray *cookies = [NSKeyedUnarchiver unarchiveObjectWithData:cookiesdata];
        NSHTTPCookie *cookie;
        for (cookie in cookies) {
            [[NSHTTPCookieStorage sharedHTTPCookieStorage] setCookie:cookie];
        }
    }
    AFHTTPRequestOperation *getOperation = [[AFHTTPRequestOperation alloc] initWithRequest:request];
    AFSecurityPolicy *securityPolicy = [AFSecurityPolicy defaultPolicy];
    securityPolicy.allowInvalidCertificates = YES;
    getOperation.securityPolicy = securityPolicy;
    getOperation.responseSerializer =[AFJSONResponseSerializer serializer];
    getOperation.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"application/json"];
    
    [getOperation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
        success(operation, responseObject);
        [self close];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        failure(operation, error);
        [self close];
    }];
    return getOperation;
}

// 请求网络数据
- (void)requestDataWithFrontURL:(NSString *)frontURL method:(NSString *)method parameter:(NSDictionary *)parameter header:(NSDictionary *)header body:(NSMutableData *)body timeoutInterval:(NSTimeInterval)timeoutInterval result:(void (^)(AFHTTPRequestOperation *operation, id responseObject))success failure:(void (^)(AFHTTPRequestOperation *operation, NSError *error))failure{
    
    // 开启状态栏菊花
    [self open];
    // GET方法单独特殊处理 =================================================================================
    if ([method isEqualToString:@"GET"])
    {
        NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:frontURL] cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:timeoutInterval];
        
        
        // 4.设置消息头
        
        if (header) {
            
            for (NSString *key in [header allKeys]) {
                
                [request setValue:[header objectForKey:key] forHTTPHeaderField:key];
                
            }
            
        }
        //设置cookies
        
        NSData *cookiesdata = [[NSUserDefaults standardUserDefaults] objectForKey:@"sessionCookies"];
        if([cookiesdata length]) {
            NSArray *cookies = [NSKeyedUnarchiver unarchiveObjectWithData:cookiesdata];
            NSHTTPCookie *cookie;
            for (cookie in cookies) {
                [[NSHTTPCookieStorage sharedHTTPCookieStorage] setCookie:cookie];
            }
        }
        AFHTTPRequestOperation *getOperation = [[AFHTTPRequestOperation alloc] initWithRequest:request];
        AFSecurityPolicy *securityPolicy = [AFSecurityPolicy defaultPolicy];
        securityPolicy.allowInvalidCertificates = YES;
        getOperation.securityPolicy = securityPolicy;
        getOperation.responseSerializer =[AFJSONResponseSerializer serializer];
        getOperation.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"application/json"];
        
        [getOperation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
            success(operation, responseObject);
            [self close];
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            // 超时
            failure(operation, error);
            // 关闭状态栏菊花
            [self close];
        }];
        [getOperation start];
    }
    // POST, PUT方法通用处理 =================================================================================
    if ([method isEqualToString:@"POST"] || [method isEqualToString:@"PUT"])
    {
        // 0. 拼接完整的URL地址
        NSMutableArray *laterArr = [NSMutableArray array];
        for (NSString *key in [parameter allKeys]) {
            NSString *keyValue = [key stringByAppendingFormat:@"=%@",[parameter objectForKey:key]];
            [laterArr addObject:keyValue];
        }
        
        // 1.初始化
        NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:frontURL] cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:timeoutInterval];
        
        // 2.设置请求类型
        request.HTTPMethod = method;
        
        // 3.设置超时时间
        request.timeoutInterval = timeoutInterval;
        
        // 4.设置消息头
        if (header) {
            for (NSString *key in [header allKeys]) {
                [request setValue:[header objectForKey:key] forHTTPHeaderField:key];
            }
        }
        // 5.设置消息体
        
        if (body) {
            request.HTTPBody = body;
        }
        // 6.请求
        
        AFHTTPRequestOperation *operation = [[AFHTTPRequestOperation alloc] initWithRequest:request];
        
        AFSecurityPolicy *securityPolicy = [AFSecurityPolicy defaultPolicy];
        securityPolicy.allowInvalidCertificates = YES;
        operation.securityPolicy = securityPolicy;
        operation.responseSerializer =[AFJSONResponseSerializer serializer];
        operation.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"application/json"];
        //        request.HTTPShouldHandleCookies = YES;
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
            // 成功
            success(operation, responseObject);
            // 关闭状态栏菊花
            [self close];
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            // 超时
            failure(operation, error);
            // 关闭状态栏菊花
            [self close];
        }];
        [operation start];
    }
}

- (NSString *)getSignBodyWithParams:(NSDictionary *)params
{
    NSString *sig = nil;
    NSString *sign_body = nil;
    if (params != nil) {
        NSString *sbJsonStr = [NSString sbJsonRecoverDic:params];
        sig = [NSString signWithKey:self.ig_key usingData:sbJsonStr];
        sign_body = [NSString stringWithFormat:@"%@.%@", sig, sbJsonStr];
    }
    return sign_body;
}

//- (NSString *)makeApiCallWithMethod:(NSString *)method Params:(NSDictionary *)params Ssl:(BOOL)ssl Use_cookie:(NSString *)user_cookie
//{
//    
//    NSMutableDictionary *defaultRequestBody = [NSMutableDictionary dictionaryWithDictionary:params];
//    
//    if ([method isEqualToString:@"Login"]) {
//        [defaultRequestBody setObject:self.device_id forKey:@"device_id"];
//        [defaultRequestBody setObject:self.device_id forKey:@"_uuid"];
//    }
//    
//    if ([method isEqualToString:@"Like"]) {
//        [defaultRequestBody setObject:self.device_id forKey:@"_uuid"];
//        [defaultRequestBody setObject:user_cookie forKey:@"_csrftoken"];
//    }
//    
//    if ([method isEqualToString:@"Follow"]) {
//        [defaultRequestBody setObject:self.device_id forKey:@"_uuid"];
//        [defaultRequestBody setObject:user_cookie forKey:@"_csrftoken"];
//    }
//    
//    NSString *sig = nil;
//    NSString *sign_body = nil;
//    
//    if (defaultRequestBody != nil) {
//        NSString *sbJsonStr = [NSString sbJsonRecoverDic:defaultRequestBody];
//        sig = [NSString signWithKey:ig_key usingData:sbJsonStr];
//        sign_body = [NSString stringWithFormat:@"%@.%@", sig, sbJsonStr];
//    }
//    
//    return sign_body;
//}

#pragma mark - private methods

// 开启状态栏菊花
- (void)open

{
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
}

// 关闭状态栏菊花
- (void)close

{
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
}

- (void)deleteCookieWithKey
{
    NSHTTPCookieStorage *cookieJar = [NSHTTPCookieStorage sharedHTTPCookieStorage];
    NSArray *cookies = [NSArray arrayWithArray:[cookieJar cookies]];
    for (NSHTTPCookie *cookie in cookies) {
        [cookieJar deleteCookie:cookie];
    }
}

#pragma mark - cancelAllOperations

-(void)cancelAllOperations
{
    [self.operationQueue cancelAllOperations];
}

@end

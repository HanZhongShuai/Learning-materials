//
//  RC_PrivateInstagramManager.h
//  iOSLikeFollow
//
//  Created by TCH on 15/12/15.
//  Copyright © 2015年 TCH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RC_PrivateInstagramManager : NSObject

+ (RC_PrivateInstagramManager *)shareManager;

- (void)cancelAllOperations;

#pragma mark - post

- (void)loginInstagramWithUserName:(NSString *)userName Password:(NSString *)password timeoutInterVal:(NSTimeInterval)timeoutInterval success:(void (^)(AFHTTPRequestOperation *operation, id responseObject))success failure:(void (^)(AFHTTPRequestOperation *operation, NSError *error))failure;

- (void)logoutWithTimeoutInterVal:(NSTimeInterval)timeoutInterval success:(void (^)(AFHTTPRequestOperation *operation, id responseObject))success failure:(void (^)(AFHTTPRequestOperation *operation, NSError *error))failure;

- (void)likeMediaWithMediaId:(NSString *)mediaId timeoutInterVal:(NSTimeInterval)timeoutInterval success:(void (^)(AFHTTPRequestOperation *operation, id responseObject))success failure:(void (^)(AFHTTPRequestOperation *operation, NSError *error))failure;

- (void)changeRelationshipWithTargetUserID:(NSString *)targetUserId isCreate:(BOOL)create timeoutInterVal:(NSTimeInterval)timeoutInterval success:(void (^)(AFHTTPRequestOperation *operation, id responseObject))success failure:(void (^)(AFHTTPRequestOperation *operation, NSError *error))failure;

- (void)changeRelationshipWithTargetUserID:(NSString *)targetUserId isBlock:(BOOL)block timeoutInterVal:(NSTimeInterval)timeoutInterval success:(void (^)(AFHTTPRequestOperation *operation, id responseObject))success failure:(void (^)(AFHTTPRequestOperation *operation, NSError *error))failure;

- (void)setAccountPrivate:(BOOL)private timeoutInterVal:(NSTimeInterval)timeoutInterval success:(void (^)(AFHTTPRequestOperation *operation, id responseObject))success failure:(void (^)(AFHTTPRequestOperation *operation, NSError *error))failure;

- (void)commentWithMediaID:(NSString *)mediaId commentText:(NSString *)commentText timeoutInterVal:(NSTimeInterval)timeoutInterval success:(void (^)(AFHTTPRequestOperation *operation, id responseObject))success failure:(void (^)(AFHTTPRequestOperation *operation, NSError *error))failure;

#pragma mark - get

- (void)getUserInfoWithUserId:(NSString *)userId timeoutInterVal:(NSTimeInterval)timeoutInterval success:(void (^)(AFHTTPRequestOperation *operation, id responseObject))success failure:(void (^)(AFHTTPRequestOperation *operation, NSError *error))failure;

- (void)getUserMediaWithUserId:(NSString *)userId maxId:(NSString *)maxId timeoutInterVal:(NSTimeInterval)timeoutInterval success:(void (^)(AFHTTPRequestOperation *operation, id responseObject))success failure:(void (^)(AFHTTPRequestOperation *operation, NSError *error))failure;

- (void)getFollowingWithMaxId:(NSString *)maxId timeoutInterVal:(NSTimeInterval)timeoutInterval success:(void (^)(AFHTTPRequestOperation *operation, id responseObject))success failure:(void (^)(AFHTTPRequestOperation *operation, NSError *error))failure;

- (void)getFollowersWithMaxId:(NSString *)maxId timeoutInterVal:(NSTimeInterval)timeoutInterval success:(void (^)(AFHTTPRequestOperation *operation, id responseObject))success failure:(void (^)(AFHTTPRequestOperation *operation, NSError *error))failure;

#pragma mark - 原方法

- (void)requestDataWithFrontURL:(NSString *)frontURL method:(NSString *)method parameter:(NSDictionary *)parameter header:(NSDictionary *)header body:(NSMutableData *)body timeoutInterval:(NSTimeInterval)timeoutInterval result:(void (^)(AFHTTPRequestOperation *operation, id responseObject))success failure:(void (^)(AFHTTPRequestOperation *operation, NSError *error))failure;

@end

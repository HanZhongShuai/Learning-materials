//
//  UserInfo.m
//  iOSGetFollow
//
//  Created by TCH on 15/6/4.
//  Copyright (c) 2015年 com.rcplatform. All rights reserved.
//

#import "UserInfo.h"

@implementation UserInfo

//===========================================================
// dealloc
//===========================================================
- (void)dealloc
{
    self.strProfile_picture = nil;
    self.strId = nil;
    self.strUserName = nil;
    self.strWebsite = nil;
    self.strBio  =nil;
    self.strMediaCount = nil;
    self.strFollowingCount = nil;
    self.strFollowersCount = nil;
    self.strFullName = nil;
}

//===========================================================
//  Keyed Archiving
//
//===========================================================
- (void)encodeWithCoder:(NSCoder *)encoder
{
    [encoder encodeObject:self.strId forKey:@"strId"];
    [encoder encodeObject:self.strUserName forKey:@"strUserName"];
    [encoder encodeObject:self.strBio forKey:@"strBio"];
    [encoder encodeObject:self.strProfile_picture forKey:@"strProfile_picture"];
    [encoder encodeObject:self.strFollowersCount forKey:@"strFollowersCount"];
    [encoder encodeObject:self.strFollowingCount forKey:@"strFollowingCount"];
    [encoder encodeObject:self.strMediaCount forKey:@"strMediaCount"];
    [encoder encodeObject:self.strWebsite forKey:@"strWebsite"];
    [encoder encodeObject:self.strFullName forKey:@"strFullNmae"];
}

- (id)initWithCoder:(NSCoder *)decoder
{
    self = [super init];
    if (self) {
        self.strId = [decoder decodeObjectForKey:@"strId"];
        self.strUserName = [decoder decodeObjectForKey:@"strUserName"];
        self.strBio = [decoder decodeObjectForKey:@"strBio"];
        self.strProfile_picture = [decoder decodeObjectForKey:@"strProfile_picture"];
        self.strFollowersCount = [decoder decodeObjectForKey:@"strFollowersCount"];
        self.strFollowingCount = [decoder decodeObjectForKey:@"strFollowingCount"];
        self.strMediaCount = [decoder decodeObjectForKey:@"strMediaCount"];
        self.strWebsite = [decoder decodeObjectForKey:@"strWebsite"];
        self.strFullName = [decoder decodeObjectForKey:@"strFullNmae"];
        
    }
    return self;
}

@end

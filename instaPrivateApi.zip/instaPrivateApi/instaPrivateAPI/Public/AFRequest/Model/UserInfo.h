//
//  UserInfo.h
//  iOSGetFollow
//
//  Created by TCH on 15/6/4.
//  Copyright (c) 2015年 com.rcplatform. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UserInfo : NSObject

@property (nonatomic, copy) NSString *strId;
@property (nonatomic, copy) NSString *strUserName;
@property (nonatomic, copy) NSString *strProfile_picture;
@property (nonatomic, copy) NSString *strWebsite;
@property (nonatomic, copy) NSString *strBio;
@property (nonatomic, copy) NSString *strFullName;

@property (nonatomic, copy) NSString *strFollowersCount; //
@property (nonatomic, copy) NSString *strFollowingCount;  //正在关注
@property (nonatomic, copy) NSString *strMediaCount;

@end

//
//  RC_LocalDataManager.h
//  FacebookHealth
//
//  Created by TCH on 15/5/13.
//  Copyright (c) 2015年 com.rcplatform. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "UserInfo.h"

@interface RC_LocalDataManager : NSObject

+ (RC_LocalDataManager *)shareInstance;
+ (UserInfo*)readUnarchiveMyUserInfo;
+ (void)archiveMyUserInfo:(UserInfo*)userInfo;

@end

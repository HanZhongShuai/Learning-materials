//
//  RC_LocalDataManager.m
//  FacebookHealth
//
//  Created by TCH on 15/5/13.
//  Copyright (c) 2015年 com.rcplatform. All rights reserved.
//

#import "RC_LocalDataManager.h"

@implementation RC_LocalDataManager

static RC_LocalDataManager *localDataManager = nil;

+ (RC_LocalDataManager *)shareInstance
{
    static dispatch_once_t predicate;
    dispatch_once(&predicate, ^{
        localDataManager = [[RC_LocalDataManager alloc]init];
    });
    return localDataManager;
}

+ (UserInfo*)readUnarchiveMyUserInfo
{
    NSData *data = [[NSUserDefaults standardUserDefaults] objectForKey:MY_USERINFO_KEY];
    NSKeyedUnarchiver *myKeyedUnarchiver = [[NSKeyedUnarchiver alloc] initForReadingWithData:data];
    UserInfo *uVO = [myKeyedUnarchiver decodeObject];
    return uVO;
}

+ (void)archiveMyUserInfo:(UserInfo*)userInfo;
{
    if (userInfo) {
        NSMutableData *mData = [[NSMutableData alloc] init];
        NSKeyedArchiver *myKeyedArchiver = [[NSKeyedArchiver alloc] initForWritingWithMutableData:mData];
        [myKeyedArchiver encodeObject:userInfo];
        [myKeyedArchiver finishEncoding];
        
        [[NSUserDefaults standardUserDefaults] setObject:mData forKey:MY_USERINFO_KEY];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
}

@end

//
//  ViewController.h
//  LSUnusedResources
//
//  Created by lslin on 15/8/31.
//  Copyright (c) 2015年 lessfun.com. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface MainViewController : NSViewController


@end

